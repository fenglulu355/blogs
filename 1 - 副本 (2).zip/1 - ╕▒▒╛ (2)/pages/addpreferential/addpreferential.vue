<template>
	<view class="addpre">
		<div class='addpreul'>
			<div class='addpreli'>
				<div class='addpreleft'>优惠类型</div>
				<div class='addpreMiddle' style='color:#000000'>{{classification[classifcaid]}}</div>
				<div class='addpreright'><img src="../../static/images/right.png" alt=""></div>
			</div>
			<div class='addpreli'>
				<div class='addpreleft'>优惠金额</div>
				<div class='addpreMiddle'><input type="text" placeholder="请填写优惠金额"></div>
				<div class='addpreright'></div>
			</div>
			<div class='addpreli'>
				<div class='addpreleft'>满减金额</div>
				<div class='addpreMiddle'><input type="text" placeholder="请填写满减金额"></div>
				<div class='addpreright'></div>
			</div>
			<div class='addpreli'>
				<div class='addpreleft'>适用类目</div>
				<div class='addpreMiddle'>可多选分类</div>
				<div class='addpreright'><img src="../../static/images/right.png" alt=""></div>
			</div>
			<div class='addpreli'>
				<div class='addpreleft'>适用日期</div>
				<div class='addpreMiddle'>开始日期 至 结束日期</div>
				<div class='addpreright'><img src="../../static/images/right.png" alt=""></div>
			</div>
		</div>
		<div class='confirm'>确认添加</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				classification: ['满减商品券', '折扣商品券', '满减外卖券', '折扣外卖券'],
				classifcaid: '0'
			}
		},
		methods: {

		},
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
			this.classifcaid = option.pid;
			console.log(option.pid); //打印出上个页面传递的参数。
		}
	}
</script>

<style>
	page {
		height: 100%;
	}

	.addpre .confirm {
		width: 250rpx;
		height: 70rpx;
		background-color: #f5bc32;
		box-shadow: 0rpx 5rpx 20rpx 0rpx #daa015;
		border-radius: 35rpx;
		margin: 0 auto;
		margin-top: 40rpx;
		font-family: PingFang-SC-Bold;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 70rpx;
	}

	.addpre .addpreul .addpreli .addpreright img {
		width: 100%;
		height: 100%;
	}

	.addpre .addpreul .addpreli .addpreright {
		width: 28rpx;
		height: 34rpx;
		margin: auto 0;
	}

	.addpre .addpreul .addpreli .addpreleft {
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #bbbbbb;
		margin: auto 0;
	}

	.addpre .addpreul .addpreli .addpreMiddle {
		flex: 1;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #999999;
		margin: auto 0;
		margin-left: 20rpx;
	}

	.addpre .addpreul .addpreli:last-child {
		border: none;
	}

	.addpre .addpreul .addpreli {
		height: 98rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.addpre .addpreul {
		margin: 0 auto;
		margin-top: 20rpx;
		width: 670rpx;
		background-color: #ffffff;
		border-radius: 5rpx;
		padding: 0 22rpx;
	}

	.addpre {
		height: 100%;
		background-color: #F8F8F8;
		display: flex;
		flex-direction: column;
	}
</style>
