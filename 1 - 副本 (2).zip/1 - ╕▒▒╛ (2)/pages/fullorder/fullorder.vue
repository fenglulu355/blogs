<template>
	<view class="fullorderpage">
		<Navigation></Navigation>
		<view class="fullorder">
			<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
			<view class="fulltype">
				<div>商品</div>
				<div>外卖</div>
			</view>
			<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
				<swiper-item id="1">
					<view class="swiperorder" v-for="item in 15" @click="orderdetail">
						<view class="swiperone">
							<view class="swipeleft">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>嘎嘎鸭桐梓林店 </div>
								<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
							</view>
							<view class="swiperight">
								交易成功
							</view>
						</view>
						<view class="swipertow">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<view class="swipetowright">
								<view class="ones">
									<div>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</div>
									<div>
										<p>￥9.90</p>
										<p>x1</p>
									</div>
								</view>
							</view>
						</view>
						<view class="swiperthree">
							共1件商品 合计:￥9.90
						</view>
						<view class="swiperfour">
							<view class="foura">

							</view>
							<view class="fourb">
								<div>删除订单</div>
								<div>再次购买</div>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="2">
					<view class="swiperorder" v-for="item in 15">
						<view class="swiperone">
							<view class="swipeleft">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>嘎嘎鸭桐梓林店 </div>
								<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
							</view>
							<view class="swiperight">
								交易成功
							</view>
						</view>
						<view class="swipertow">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<view class="swipetowright">
								<view class="ones">
									<div>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</div>
									<div>
										<p>￥9.90</p>
										<p>x1</p>
									</div>
								</view>
							</view>
						</view>
						<view class="swiperthree">
							共1件商品 合计:￥9.90
						</view>
						<view class="swiperfour">
							<view class="foura">

							</view>
							<view class="fourb">
								<div>删除订单</div>
								<div>再次购买</div>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="3">
					<view class="swiperorder" v-for="item in 15">
						<view class="swiperone">
							<view class="swipeleft">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>嘎嘎鸭桐梓林店 </div>
								<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
							</view>
							<view class="swiperight">
								交易成功
							</view>
						</view>
						<view class="swipertow">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<view class="swipetowright">
								<view class="ones">
									<div>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</div>
									<div>
										<p>￥9.90</p>
										<p>x1</p>
									</div>
								</view>
							</view>
						</view>
						<view class="swiperthree">
							共1件商品 合计:￥9.90
						</view>
						<view class="swiperfour">
							<view class="foura">

							</view>
							<view class="fourb">
								<div>删除订单</div>
								<div>再次购买</div>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="4">
					<view class="swiperorder" v-for="item in 15">
						<view class="swiperone">
							<view class="swipeleft">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>嘎嘎鸭桐梓林店 </div>
								<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
							</view>
							<view class="swiperight">
								交易成功
							</view>
						</view>
						<view class="swipertow">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<view class="swipetowright">
								<view class="ones">
									<div>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</div>
									<div>
										<p>￥9.90</p>
										<p>x1</p>
									</div>
								</view>
							</view>
						</view>
						<view class="swiperthree">
							共1件商品 合计:￥9.90
						</view>
						<view class="swiperfour">
							<view class="foura">

							</view>
							<view class="fourb">
								<div>删除订单</div>
								<div>再次购买</div>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="5">
					<view class="swiperorder">
						<view class="swiperone">
							<view class="swipeleft">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>嘎嘎鸭桐梓林店 </div>
								<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
							</view>
							<view class="swiperight">
								订单完成
							</view>
						</view>
						<view class="swipertow">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<view class="swipetowright">
								<view class="ones">
									<div>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</div>
									<div>
										<p>￥9.90</p>
										<p>x1</p>
									</div>
								</view>
							</view>
						</view>
						<view class="swiperthree">
							共1件商品 合计:￥9.90
						</view>
						<view class="swiperfour">
							<view class="foura">

							</view>
							<view class="fourb">
								<div>删除订单</div>
								<div @click="replace">申请售后</div>
								<div @click="Takeaway(0)">评价商品</div>
							</view>
						</view>
					</view>
					<view class="swiperorder" v-for="item in 5">
						<view class="swiperone">
							<view class="swipeleft">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>嘎嘎鸭桐梓林店 </div>
								<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
							</view>
							<view class="swiperight">
								订单完成
							</view>
						</view>
						<view class="swipertow">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<view class="swipetowright">
								<view class="ones">
									<div>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</div>
									<div>
										<p>￥9.90</p>
										<p>x1</p>
									</div>
								</view>
							</view>
						</view>
						<view class="swiperthree">
							共1件商品 合计:￥9.90
						</view>
						<view class="swiperfour">
							<view class="foura">

							</view>
							<view class="fourb">
								<div>删除订单</div>
								<div @click="replace">申请售后</div>
								<div @click="Takeaway(1)">评价商品</div>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="6">
					<view class="swiperorder" v-for="item in 15">
						<view class="swiperone">
							<view class="swipeleft">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>嘎嘎鸭桐梓林店 </div>
								<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
							</view>
							<view class="swiperight">
								申请换货中
							</view>
						</view>
						<view class="swipertow">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<view class="swipetowright">
								<view class="ones">
									<div>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</div>
									<div>
										<p>￥9.90</p>
										<p>x1</p>
									</div>
								</view>
							</view>
						</view>
						<view class="swiperborder">

						</view>
						<view class="swiperfour">
							<view class="foura">
								当前进度：商家确认中
							</view>
							<view class="fourb">
								<div @click="withdraw">取消申请</div>
								<div>查看详情</div>
							</view>
						</view>
					</view>
				</swiper-item>
			</swiper>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	export default {
		data() {
			return {
				TabCur: 0,
				tabList: [{
						name: '全部'
					}, {
						name: '待付款'
					},
					{
						name: '待发货'
					},
					{
						name: '待收货'
					},
					{
						name: '已完成'
					},
					{
						name: '退换货'
					}
				],
			}
		},
		methods: {
			tabChange(index) {
				this.TabCur = index;
			},
			swiperChange(e) {
				this.tabChange(e.detail.current)
			},
			replace: function() {
				uni.navigateTo({
					url: '../Replacement/Replacement'
				});
			},
			withdraw: function() {
				uni.navigateTo({
					url: '../withdraw/withdraw'
				});
			},
			orderdetail: function() {
				uni.navigateTo({
					url: '../Orderdetails/Orderdetails'
				});
			},
			Takeaway: function(e) {
				//外卖评价
				if (e == 0) {
					uni.navigateTo({
						url: '../Takeawayevaluation/Takeawayevaluation'
					});
				} else {
					uni.navigateTo({
						url: '../TakeawayComments/TakeawayComments'
					});
				}

			}
		},
		components: {
			Navigation,
			Iconfonts,
			WucTab
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.swiperborder {
		height: 1rpx;
		background-color: #f8f8f8;
	}

	.swiperorder .swiperfour .foura {
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}

	.swiperorder .swiperfour .fourb {
		display: flex;
	}

	.swiperorder .swiperfour div:last-child {
		border: solid 1rpx rgba(255, 104, 58, 0.5);
		color: #ff683a;
	}

	.swiperorder .swiperfour div {
		width: 150rpx;
		height: 50rpx;
		border-radius: 25rpx;
		border: solid 1rpx #dddddd;
		text-align: center;
		line-height: 50rpx;
		color: #222222;
		font-size: 24rpx;
		margin-left: 20rpx;
	}

	.swiperorder .swiperfour {
		display: flex;
		justify-content: space-between;
	}

	.swiperorder .swiperthree {
		text-align: right;
		color: #222222;
		font-size: 20rpx;
	}

	.swiperorder .swipertow .swipetowright .ones div:last-child p:last-child {
		color: #666666;
		font-size: 24rpx;
	}

	.swiperorder .swipertow .swipetowright .ones div:last-child p {
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
		text-align: right;
	}

	.swiperorder .swipertow .swipetowright .ones div:first-child {
		margin-right: 35rpx;
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
	}

	.swiperorder .swipertow .swipetowright .ones {
		display: flex;
		justify-content: space-between;
	}

	.swiperorder .swipertow .swipetowright {
		flex: 1;
	}

	.swiperorder .swipertow image {
		width: 160rpx;
		height: 160rpx;
		background-color: #222222;
		border-radius: 5rpx;
		margin-right: 20rpx;
		flex-shrink: 0;
	}

	.swiperorder .swipertow {
		display: flex;
	}

	.swiperorder .swiperone .swiperight {
		margin: auto 0;
		color: #ff683a;
		font-size: 24rpx;
	}

	.swiperorder .swiperone .swipeleft Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.swiperorder .swiperone .swipeleft div {
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
		margin-right: 20rpx;
	}

	.swiperorder .swiperone .swipeleft image {
		width: 32rpx;
		height: 32rpx;
		background-color: #ffc528;
		border-radius: 2rpx;
		flex-shrink: 0;
		margin: auto 0;
		margin-right: 10rpx;
	}

	.swiperorder .swiperone .swipeleft {
		display: flex;
	}

	.swiperorder .swiperone {
		display: flex;
		justify-content: space-between;
	}

	.swiperorder {
		background-color: #ffffff;
		height: 346rpx;
		padding: 18rpx;
		margin-bottom: 18rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		flex-shrink: 0;
	}

	swiper-item {
		overflow: auto;
		display: flex;
		flex-direction: column;
	}

	.fullorder .swip {
		flex: 1;
	}

	.fullorder .fulltype div:last-child {
		background-color: #fff;
		margin-left: 24rpx;
	}

	.fullorder .fulltype div {
		width: 165rpx;
		height: 54rpx;
		background-color: #f5bc32;
		border-radius: 27rpx;
		text-align: center;
		line-height: 54rpx;
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}

	.fullorder .fulltype {
		height: 90rpx;
		padding: 0 18rpx;
		display: flex;
	}

	.fullorder {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.fullorderpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.wuc-tab {
		background-color: #fff;
	}
</style>
