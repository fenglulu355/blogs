<template>
	<view class="boardpage">
		<Navigation></Navigation>
		<view class="boardlod">
			<view class="boardlodlb">
				<swiper class="swiper" autoplay="true" interval="3000" duration="300" circular>
					<swiper-item v-for="item in 5">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</swiper-item>
				</swiper>
				<view class="indicator">
					<Iconfonts name="icon-xiangji" size="28rpx" colors="#bbbbbb" />
					<div>40张</div>
				</view>
			</view>
			<view class="boardshop">
				<view class="shoptitle">
					<view class="shoptitleleft">
						<view class="shoptop">
							<view class="titles">
								{{shopxq.store_name}}
							</view>
							<div>订</div>
						</view>
						<view class="shopbottom">
							<view class="xinxins">
								<Iconfonts name="icon-xingxing" size="22rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="22rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="22rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="22rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="22rpx" colors="#ffdc28" />
							</view>
							<view class="fen">
								4.0
							</view>
							<view class="ren">
								人均￥{{shopxq.rj_price}}   菜场
							</view>
						</view>
					</view>
					<view class="shoptitleright">
						<view class="share">
							<Iconfonts name="icon-fenxiang" size="38rpx" colors="#dddddd" />
							<div>分享</div>
						</view>
						<view class="share">
							<Iconfonts name="icon-xingxing" size="38rpx" colors="#dddddd" />
							<div>收藏</div>
						</view>
					</view>
				</view>
				<view class="shoptime" @click="qualifica">
					<view class="time">
						<Iconfonts name="icon-shijian" size="25rpx" colors="#dddddd" />
						<div>营业时间 {{shopxq.yytime}}</div>
					</view>
					<view class="Licence">
						<div>营业许可证资质</div>
						<Iconfonts name="icon-you" size="25rpx" colors="#999999" />
					</view>
				</view>
				<view class="shopaddr">
					<view class="addr">
						<Iconfonts name="icon-dizhi" size="25rpx" colors="#dddddd" />
						<div>{{shopxq.address}}</div>
					</view>
					<Iconfonts name="icon-daohang-" size="50rpx" colors="#f5bc32" />
				</view>
				<view class="Discount">
					<view class="discountleft">
						<div>满减</div>
						<div>满200减30，满100减20，满50减10</div>
					</view>
					<view class="discountright">
						<div>3个优惠</div>
						<Iconfonts name="icon-xia" size="20rpx" colors="#cccccc" />
					</view>
				</view>
			</view>
			<view class="boardphone">
				<view class="phoneleft">
					<Iconfonts name="icon-biaoqian" size="25rpx" colors="#dddddd" />
					<div>电话订座<span>（今日已订1083）</span></div>
				</view>
				<view class="phoneright">
					<Iconfonts name="icon-dianhua" size="50rpx" colors="#23c88c" />
				</view>
			</view>
			<view class="boardphone">
				<view class="phoneleft">
					<Iconfonts name="icon-qianbao-gra" size="30rpx" colors="#f5bc32" />
					<div>手机买单<span>（优惠有惊喜）</span></div>
				</view>
				<view class="phoneright">
					<div>买单</div>
				</view>
			</view>
			<view class="Recommend">
				<view class="recommendtitle" @click="recommend">
					<div>商家推荐<span>(12)</span></div>
					<Iconfonts name="icon-you" size="25rpx" colors="#999999" />
				</view>
				<view class="recommendcontent">
					<view class="recommendli" v-for="item in 10">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<div>休闲卤味风味鸭头</div>
					</view>
				</view>
			</view>
			<view class="boardcomment">
				<view class="commenttitle" @click="allcomment">
					<div>用户评论</div>
					<div>全部评论（ 145 条）</div>
				</view>
				<view class="commentlabol">
					<div v-for="item in 5">晒图评价 99</div>
				</view>
				<view class="commentall">
					<view class="commentone" v-for="item in 5">
						<view class="commentlift">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						</view>
						<view class="commentright">
							<view class="commentname">
								<div>流沙包</div>
								<div>2019.03.16</div>
							</view>
							<view class="commentxinxin">
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
							</view>
							<view class="commentext">
								<view class="text">味道非常好，好吃得快飞起来了！</view>
								<view class="images">
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="Suctionbottom">
				<view class="suctionleft" @click="menu">
					<Iconfonts name="icon-caidan" size="35rpx" colors="#ffffff" />
					<div>菜单</div>
				</view>
				<view class="suctionleft" style="background-color: #ff643a" @click="takeout">
					<Iconfonts name="icon-waimai" size="40rpx" colors="#ffffff" />
					<div>外卖<span>(休息中)</span></div>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				bashurl:'',
				shopxqid:''
			}
		},
		onShow: function() {
			
		},
		computed: {
			...mapState(['shopxq'])
		},
		onLoad:function(option){
			// console.log(option.id);
			this.shopxqid = option.id
			// console.log(option.id); //打印出上个页面传递的参数。
			// setTimeout(() => {
			// 	this.getshopxq();
			// },500)
			this.getshopxq({id:option.id})
		},
		methods: {
			...mapActions(['getshopxq']),
			...mapMutations(['settypeclass']),
			qualifica:function(){
				uni.navigateTo({
					url: '../qualification/qualification'
				});
			},
			recommend:function(){
				uni.navigateTo({
					url: '../Recommend/Recommend'
				});
			},
			allcomment:function(){
				uni.navigateTo({
					url: '../allcomment/allcomment'
				});
			},
			menu:function(){
				uni.navigateTo({
					url: '../shopmenu/shopmenu'
				});
			},
			takeout:function(){
				uni.navigateTo({
					url: '../Takeoutfood/Takeoutfood'
				});
			}
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	
	.Suctionbottom .suctionleft Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 15rpx;
	}
	.Suctionbottom .suctionleft div span{
		font-size: 24rpx;
	}
	.Suctionbottom .suctionleft div{
		margin: auto 0;
		color: #ffffff;
		font-size: 32rpx;
	}
	.Suctionbottom .suctionleft{
		width: 50%;
		background-color: #23c88c;
		display: flex;
		justify-content: center;
	}
	
	.Suctionbottom{
		width: 100%;
		height: 100rpx;
		display: flex;
		position: fixed;
		bottom: 0;
	}

	.boardpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext .images image{
		width: 141rpx;
		height: 141rpx;
		background-color: #ffdc28;
		border-radius: 10rpx;
		margin-right: 10rpx;
		
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext .images{
		display: flex;
		flex-wrap: wrap;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext .text{
		color: #2d2d2d;
		font-size: 24rpx;
		margin: 12rpx 0;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext{
		margin: 30rpx 0;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentxinxin Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 5rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentxinxin{
		display: flex;
		margin: 12rpx 0;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentname div:last-child{
		color: #b3b3b3;
		font-size: 24rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentname div:first-child{
		color: #2d2d2d;
		font-size: 28rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentname{
		display: flex;
		justify-content: space-between;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright{
		display: flex;
		flex-direction: column;
		border-bottom: 1rpx solid #f2f2f2;
		flex: 1;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentlift image{
		width: 82rpx;
		height: 82rpx;
		border: solid 1rpx #f5f5f5;
		border-radius: 50%;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentlift{
		margin-right: 20rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone{
		display: flex;
		margin-bottom: 30rpx;
	}
	
	.boardlod .boardcomment .commentlabol div{
		margin: 12rpx 0;
		padding: 0 25rpx;
		height: 50rpx;
		border-radius: 25rpx;
		border: solid 1rpx #cccccc;
		margin-right: 20rpx;
		text-align: center;
		line-height: 50rpx;
		color: #666666;
		font-size: 24rpx;
	}
	
	.boardlod .boardcomment .commentlabol{
		display: flex;
		flex-wrap: wrap;
		margin-bottom: 25rpx;
	}
	
	.boardlod .boardcomment .commenttitle div:last-child{
		color: #999999;
		font-size: 24rpx;
		margin: auto 0;
	}
	
	.boardlod .boardcomment .commenttitle div:first-child{
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
		margin: auto 0;
	}
	
	.boardlod .boardcomment .commenttitle{
		height: 84rpx;
		display: flex;
		justify-content: space-between;
	}
	
	.boardlod .boardcomment{
		padding: 0 18rpx;
		background-color: #fff;
		margin-bottom: 100rpx;
	}
	
	.boardlod .Recommend .recommendcontent .recommendli div{
		color: #222222;
		font-size: 24rpx;
		margin: 14rpx 0;
		width: 200rpx;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
	}
	
	.boardlod .Recommend .recommendcontent .recommendli image{
		width: 200rpx;
		height: 200rpx;
		background-color: #222222;
		border-radius: 5rpx;
	}
	
	.boardlod .Recommend .recommendcontent .recommendli:last-child{
		margin: 0;
	}
	
	.boardlod .Recommend .recommendcontent .recommendli{
		margin-right: 20rpx;
	}
	
	.boardlod .Recommend .recommendcontent{
		display: flex;
		overflow: auto;
	}
	
	.boardlod .Recommend .recommendtitle Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .Recommend .recommendtitle div span{
		color: #999999;
		font-size: 24rpx;
	}
	
	.boardlod .Recommend .recommendtitle div{
		margin: auto 0;
		color: #222222;
		font-size: 28rpx;
	}
	
	.boardlod .Recommend .recommendtitle{
		display: flex;
		justify-content: space-between;
		height: 84rpx;
	}
	
	.boardlod .Recommend{
		height: 354rpx;
		background-color: #ffffff;
		padding: 0 18rpx;
		margin-bottom: 18rpx;
	}
	
	.boardlod .boardphone .phoneright div{
		width: 80rpx;
		height: 44rpx;
		background-color: #f5bc32;
		border-radius: 5rpx;
		margin: auto 0;
		line-height: 44rpx;
		text-align: center;
		color: #ffffff;
		font-size: 28rpx;
	}
	
	.boardlod .boardphone .phoneright Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .boardphone .phoneright{
		margin: auto 0;
	}
	
	.boardlod .boardphone .phoneleft div span{
		color: #999999;
	}
	
	.boardlod .boardphone .phoneleft div{
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}
	
	.boardlod .boardphone .phoneleft Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 12rpx;
	}
	
	.boardlod .boardphone .phoneleft{
		display: flex;
		margin: auto 0;
	}
	
	.boardlod .boardphone{
		margin-bottom: 18rpx;
		height: 80rpx;
		background-color: #ffffff;
		padding: 0 18rpx;
		display: flex;
		justify-content: space-between;
	}
	
	.boardlod .boardshop .Discount .discountright Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-left: 12rpx;
	}
	
	.boardlod .boardshop .Discount .discountright div{
		margin: auto 0;
		color: #666666;
		font-size: 24rpx;
	}
	
	.boardlod .boardshop .Discount .discountright{
		margin: auto 0;
		display: flex;
	}
	
	.boardlod .boardshop .Discount .discountleft div:last-child{
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}
	
	.boardlod .boardshop .Discount .discountleft div:first-child{
		width: 48rpx;
		height: 24rpx;
		background-color: #ff643a;
		border-radius: 3rpx;
		text-align: center;
		line-height: 24rpx;
		color: #ffffff;
		font-size: 20rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}
	
	.boardlod .boardshop .Discount .discountleft{
		margin: auto 0;
		display: flex;
	}
	
	.boardlod .boardshop .Discount{
		height: 82rpx;
		display: flex;
		justify-content: space-between;
		padding: 0 18rpx;
	}
	
	.boardlod .boardshop .shopaddr Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .boardshop .shopaddr .addr Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .boardshop .shopaddr .addr div{
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
		margin-left: 12rpx;
	}
	
	.boardlod .boardshop .shopaddr .addr{
		display: flex;
	}
	
	.boardlod .boardshop .shopaddr{
		height: 82rpx;
		border-bottom: 1rpx solid #f8f8f8;
		display: flex;
		justify-content: space-between;
		padding: 0 18rpx;
	}
	
	.boardlod .boardshop .shoptime .Licence div{
		color: #666666;
		font-size: 24rpx;
		margin: auto 0;
		margin-right: 14rpx;
	}
	
	.boardlod .boardshop .shoptime .Licence Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .boardshop .shoptime .Licence{
		display: flex;
		margin: auto 0;
	}
	
	.boardlod .boardshop .shoptime .time div{
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
		margin-left: 12rpx;
	}
	
	.boardlod .boardshop .shoptime .time Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .boardshop .shoptime .time{
		margin: auto 0;
		display: flex;
	}
	
	.boardlod .boardshop .shoptime{
		border-bottom: 1rpx solid #f8f8f8;
		height: 82rpx;
		padding: 0 18rpx;
		display: flex;
		justify-content: space-between;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleright .share Iconfonts{
		margin: 0 auto;
		display: flex;
		justify-content: center;
		margin-bottom: 12rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleright .share div{
		text-align: center;
		color: #666666;
		font-size: 22rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleright .share{
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-left: 35rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleright{
		display: flex;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shopbottom .ren{
		color: #222222;
		font-size: 22rpx;
		margin: auto 0;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shopbottom .fen{
		color: #666666;
		font-size: 22rpx;
		margin: auto 0;
		margin-right: 18rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shopbottom .xinxins Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 5rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shopbottom .xinxins{
		display: flex;
		margin-right: 15rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shopbottom{
		display: flex;
		margin-top: 15rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shoptop div{
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #23c88c;
		color: #23c88c;
		text-align: center;
		line-height: 34rpx;
		margin-right: 10rpx;
		font-size: 24rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shoptop .titles{
		color: #222222;
		font-size: 32rpx;
		margin-right: 28rpx;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft .shoptop{
		display: flex;
	}
	
	.boardlod .boardshop .shoptitle .shoptitleleft{
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		flex: 1;
	}
	
	.boardlod .boardshop .shoptitle{
		/* height: 70rpx; */
		border-bottom: 1rpx solid #f8f8f8;
		display: flex;
		justify-content: space-between;
		padding: 25rpx 18rpx;
	}
	
	.boardlod .boardshop{
		display: flex;
		flex-direction: column;
		background-color: #fff;
		margin-bottom: 18rpx;
	}
	
	.boardlod .boardlodlb .indicator div{
		color: #bbbbbb;
		font-size: 24rpx;
		margin: auto 0;
		margin-left: 10rpx;
	}
	
	.boardlod .boardlodlb .indicator Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .boardlodlb .indicator{
		width: 140rpx;
		height: 50rpx;
		background-color: rgba(0,0,0,0.5);
		border-radius: 25rpx;
		position: absolute;
		bottom: 18rpx;
		right: 18rpx;
		display: flex;
		justify-content: center;
	}
	
	.boardlod .boardlodlb .swiper image{
		width: 100%;
	}
	
	.boardlod .boardlodlb .swiper{
		height: 100%;
	}

	.boardlod .boardlodlb {
		height: 350rpx;
		position: relative;
	}

	.boardlod {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
	}
</style>
