<template>
	<view class="housingpages">
		<Navigation></Navigation>
		<view class="housings">
			<view class="housingstitle">
				<view class="housingstops">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<view class="titles">
						<view class="one">豪华大床房</view>
						<view class="tow">不含早餐、有wifi</view>
						<view class="three">
							<span>{{startime.month}}月{{startime.day}}日-{{endtime.month}}月{{endtime.day}}日</span>
							<span>共{{day}}晚 </span>
							<span>1间</span>
						</view>
					</view>
					<view></view>
				</view>
				<view class="policy">
					<div>!</div>
					<div> 根据酒店政策，6月26日18点前可免费取消，逾期不可取消/变更，如未入住，酒店将扣除全部房费房间整晚保留，14：00前到店可能需要等房</div>
				</view>
			</view>
			<view class="housingsli">
				<view class="housingslis">
					<div>房间数</div>
					<div class="towdiv">1间</div>
					<Iconfonts name="icon-you" size="25rpx" colors="#a6a6a6" />
				</view>
				<view class="housingslis">
					<div>入住人</div>
					<div class="towdiv">YY</div>
				</view>
				<view class="housingslis">
					<div>联系手机</div>
					<div class="towdiv">156  6666  6666</div>
				</view>
				<view class="housingslis">
					<div>预计到店</div>
					<div class="towdiv">14:00</div>
					<Iconfonts name="icon-you" size="25rpx" colors="#a6a6a6" />
				</view>
			</view>
			<view class="housingsli">
				<view class="housingslis">
					<div>优惠券</div>
					<div class="towdiv">暂无可用优惠券</div>
					<Iconfonts name="icon-you" size="25rpx" colors="#a6a6a6" />
				</view>
				<view class="housingslis">
					<div>发票</div>
					<div class="towdiv">请在前台索取</div>
				</view>
			</view>
		</view>
		<view class="Suction">
			<view class="sucleft">
				<view class="sucone">
					<div>总价<p>￥</p><span>299</span></div>
					<div>已优惠￥0</div>
				</view>
				<view class="suctow" @click="setmask">
					<div>明细</div>
					<Iconfonts name="icon-xiala" size="25rpx" colors="#dddddd" />
				</view>
			</view>
			<view class="sucright" @click="outmask">提交订单</view>
		</view>
		<view class="Mask" :style="'display:'+dis">
			<view class="hei" @click="outmask">
				
			</view>
			<view class="masknei">
				<view class="masktitle">
					明细
				</view>
				<view class="Theroomrate">
					<div>
						<span>房费</span><span>￥129</span>
					</div>
					<div>
						<span>2019-06-28不含早</span><span>1x￥129</span>
					</div>
				</view>
				<view class="Theroomrate">
					<div>
						<span>优惠</span><span>-￥0</span>
					</div>
					<div>
						<span>减0元</span><span>-￥0</span>
					</div>
				</view>
				<view class="total">
					<div>总价</div>
					<div>200</div>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				startime:'',
				endtime:'',
				day:'0',
				dis:'none'
			}
		},
		onShow:function(){
			this.startime = getApp().globalData.startime;
			this.endtime = getApp().globalData.endtime;
			this.day = getApp().globalData.day;
			console.log(this.startime,this.endtime,this.day);
		},
		methods: {
			setmask:function(){
				this.dis = 'flex'
			},
			outmask:function(e){
				this.dis = 'none'
			}
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	.Mask .masknei .total div{
		color: #222222;
		font-size: 24rpx;
		margin-top: 35rpx;
	}
	.hei{
		flex: 1;
	}
	.Mask .masknei .total{
		display: flex;
		justify-content: space-between;
	}
	.Mask .masknei .Theroomrate div:last-child span{
		color: #999999;
		font-size: 24rpx;
	}
	.Mask .masknei .Theroomrate div:first-child span:last-child{
		color: #222222;
		font-size: 24rpx;
	}
	.Mask .masknei .Theroomrate div:first-child span:first-child{
		color: #222222;
		font-size: 24rpx;
	}
	.Mask .masknei .Theroomrate div{
		display: flex;
		justify-content: space-between;
	}
	.Mask .masknei .Theroomrate{
		margin-bottom: 35rpx;
	}
	.Mask .masknei .masktitle{
		margin: 30rpx 0;
		color: #222222;
		font-size: 24rpx;
	}
	.Mask .masknei{
		height: 400rpx;
		background-color: #ffffff;
		padding: 0 18rpx;
		display: flex;
		flex-direction: column;
	}
	.Mask{
		background-color: rgba(0,0,0,0.5);
		width: 100%;
		position: fixed;
		bottom: 100rpx;
		top: 150rpx;
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
	}
	.Suction .sucleft .suctow Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.Suction .sucleft .suctow div{
		margin: auto 0;
		color: #999999;
		font-size: 18rpx;
		margin-right: 12rpx;
	}
	.Suction .sucleft .suctow{
		display: flex;
		margin: auto 0;
	}
	.Suction .sucleft .sucone div:last-child{
		color: #999999;
		font-size: 18rpx;
	}
	.Suction .sucleft .sucone div:first-child p{
		color: #ff643a;
	}
	.Suction .sucleft .sucone div:first-child span{
		color: #ff643a;
		font-size: 32rpx;
		font-weight: bold;
	}
	.Suction .sucleft .sucone div:first-child{
		color: #666666;
		font-size: 24rpx;
		display: flex;
		align-items: flex-end;
	}
	.Suction .sucleft .sucone{
		margin: auto 0;
	}
	.Suction .sucleft{
		flex: 1;
		background-color: #fff;
		padding: 0 18rpx;
		display: flex;
		justify-content: space-between;
	}
	.Suction .sucright{
		width: 50%;
		background-color: #23c88c;
		text-align: center;
		line-height: 100rpx;
		color: #ffffff;
		font-size: 32rpx;
	}
	.Suction{
		width: 100%;
		height: 100rpx;
		position: fixed;
		bottom: 0;
		display: flex;
	}
page{
	height: 100vh;
}
.housings .housingsli .housingslis Iconfonts{
	margin: auto 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
}
.housings .housingsli .housingslis .towdiv{
	color: #151515;
	font-size: 24rpx;
	margin: auto 0;
	flex: 1;
}
.housings .housingsli .housingslis div:first-child{
	width: 165rpx;
	margin: auto 0;
	color: #636363;
	font-size: 24rpx;
}
.housings .housingsli .housingslis{
	height: 80rpx;
	display: flex;
	justify-content: space-between;
	border-bottom: 1rpx solid #f8f8f8;
	box-sizing: border-box;
}
.housings .housingsli{
	background-color: #FFF;
	padding: 0 18rpx;
	margin-bottom: 18rpx;
}
.housingpages{
	height: 100%;
	display: flex;
	flex-direction: column;
}
.housings .policy div:last-child{
	color: #999999;
	font-size: 24rpx;
}
.housings .policy div:first-child{
	width: 23rpx;
	height: 23rpx;
	border-radius: 50%;
	border: 1rpx solid #ff9900;
	text-align: center;
	line-height: 23rpx;
	color: #ff9900;
	font-size: 20rpx;
	flex-shrink: 0;
	margin: auto 0;
	margin-right: 10rpx;
}
.housings .policy{
	padding: 30rpx 0;
	display: flex;
}
.housings .housingstitle .housingstops .titles .three span{
	margin-right: 10rpx;
}
.housings .housingstitle .housingstops .titles .three{
	color: #23c88c;
	font-size: 24rpx;
}
.housings .housingstitle .housingstops .titles .tow{
	color: #999999;
	font-size: 24rpx;
	margin-bottom: 12rpx;
}
.housings .housingstitle .housingstops .titles .one{
	color: #222222;
	font-weight: bold;
	font-size: 28rpx;
	margin-bottom: 12rpx;
}
.housings .housingstitle .housingstops .titles{
	flex: 1;
	margin-left: 18rpx;
}
.housings .housingstitle .housingstops image{
	width: 120rpx;
	height: 120rpx;
	border-radius: 6rpx;
}
.housings .housingstitle .housingstops{
	padding: 30rpx 0;
	border-bottom: 1rpx solid #f2f2f2;
	display: flex;
}
.housings .housingstitle{
	padding: 0 18rpx;
	background-color: #fff;
	margin-bottom: 18rpx;
}
.housings{
	flex: 1;
	background-color: #f8f8f8;
	overflow: auto;
}
</style>
