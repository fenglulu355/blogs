<template>
	<view class="takeapage">
		<Navigation></Navigation>
		<view class="takeawaye">
			<view class="evaluation">
				<view class="Stars">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<view class="starsli">
						<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
						<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
						<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
						<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
						<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
					</view>
					<view class="takeastate">
						质量不好
					</view>
				</view>
				<view class="evaluatxt">
					<textarea maxlength="50" placeholder-style="color:#999999" placeholder="商品还符合您的预期吗？（至少要写10个字哦~）…" />
					</view>
				<view class="evaluaimg">
					<view class="imgli">
						<div class="addimg" @click="addimg"><image mode="widthFix" src="../../static/images/jia.png"></image></div>
						<div class="imageli" v-for="item in images"><image mode="widthFix" :src="item"></image></div>
					</view>
					<view class="imgtxt">最多上传5张</view>
				</view>
			</view>
			<view class="score">
				<view class="Business">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<div>商家评分</div>
				</view>
				<view class="scoreStars">
					<view class="wuliu">
						<view class="wuliutitle">物流服务</view>
						<view class="wuliuli">
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
						</view>
					</view>
					<view class="wuliu">
						<view class="wuliutitle">服务态度</view>
						<view class="wuliuli">
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
							<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
						</view>
					</view>
				</view>
			</view>
			<view class="pinglun">
				评论
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				images:[]
			}
		},
		methods: {
			addimg:function(){
				uni.chooseImage({
				    count: 5, //默认9
				    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				    sourceType: ['album'], //从相册选择
				    success:(res)=> {
						this.images = res.tempFilePaths
				        console.log(JSON.stringify(res.tempFilePaths));
				    }
				});
			}
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.pinglun{
	margin: 40rpx auto;
	width: 400rpx;
	height: 80rpx;
	background-color: #f5bc32;
	border-radius: 40rpx;
	text-align: center;
	line-height: 80rpx;
	color: #222222;
	font-size: 28rpx;
}
.takeapage{
	height: 100%;
	display: flex;
	flex-direction: column;
} 
.takeawaye .score .scoreStars .wuliu .wuliuli Iconfonts{
	margin: auto 0;
	margin-right: 15rpx;
	display: flex;
	flex-direction: column;
	justify-content: center;
}
.takeawaye .score .scoreStars .wuliu .wuliuli{
	display: flex;
}
.takeawaye .score .scoreStars .wuliu .wuliutitle{
	color: #666666;
	font-size: 24rpx;
	margin: auto 0;
	margin-right: 40rpx;
}
.takeawaye .score .scoreStars .wuliu:last-child{
	margin: 0;
}
.takeawaye .score .scoreStars .wuliu{
	display: flex;
	margin-bottom: 30rpx;
}
.takeawaye .score .scoreStars{
	margin: 40rpx 0;
}
.takeawaye .score .Business div{
	color: #222222;
	font-size: 24rpx;
	margin: auto 0;
}
.takeawaye .score .Business image{
	width: 70rpx;
	height: 70rpx;
	background-color: #ffffff;
	border-radius: 5rpx;
	margin-right: 16rpx;
}
.takeawaye .score .Business{
	margin-top: 30rpx;
	display: flex;
}
.takeawaye .score{
	width: 678rpx;
	height: 270rpx;
	background-color: #ffffff;
	border-radius: 10rpx;
	padding: 0 18rpx;
	display: flex;
	margin: 18rpx auto;
	flex-direction: column;
}
.takeawaye .evaluation .evaluaimg .imgtxt{
	color: #999999;
	font-size: 24rpx;
	margin-top: 20rpx;
}
.takeawaye .evaluation .evaluaimg .imgli .imageli image{
	width: 100%;
}
.takeawaye .evaluation .evaluaimg .imgli .imageli{
	width: 101rpx;
	height: 100rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
	margin: 0 5rpx;
	overflow: hidden;
	flex-shrink: 0;
}
.takeawaye .evaluation .evaluaimg .imgli .addimg image{
	width: 100%;
}
.takeawaye .evaluation .evaluaimg .imgli .addimg{
	width: 101rpx;
	height: 100rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
	flex-shrink: 0;
}
.takeawaye .evaluation .evaluaimg .imgli{
	display: flex;
}
.takeawaye .evaluation .evaluaimg{
	height: 220rpx;
	display: flex;
	flex-direction: column;
	justify-content: center;
}
.takeawaye .evaluation .evaluatxt textarea{
	width: 100%;
	height: 100%;
	font-size: 24rpx;
}
.takeawaye .evaluation .evaluatxt{
	width: 622rpx;
	height: 178rpx;
	background-color: #f9f9f9;
	border-radius: 10rpx;
	margin: 0 auto;
	padding: 22rpx;
	font-size: 24rpx;
	position: relative;
}
.takeawaye .evaluation .Stars .takeastate{
	margin: auto 0;
	color: #999999;
	font-size: 24rpx;
}
.takeawaye .evaluation .Stars .starsli Iconfonts{
	margin: auto 10rpx;
	display: flex;
	flex-direction: column;
	justify-content: center;
}
.takeawaye .evaluation .Stars .starsli{
	margin: auto 25rpx;
	display: flex;
}
.takeawaye .evaluation .Stars image{
	width: 70rpx;
	height: 70rpx;
	background-color: #ffffff;
	border-radius: 5rpx;
	margin: auto 0;
	margin-right: 25rpx;
}
.takeawaye .evaluation .Stars{
	height: 130rpx;
	display: flex;
}
.takeawaye .evaluation{
	width: 678rpx;
	height: 550rpx;
	background-color: #ffffff;
	border-radius: 10rpx;
	margin: 18rpx auto;
	padding: 0 18rpx;
}
.takeawaye{
	flex: 1;
	background-color: #f8f8f8;
	overflow: auto;
	display: flex;
	flex-direction: column;
}
</style>
