<template>
	<view class="logisticpage">
		<Navigation></Navigation>
		<view class="logisticsdetails">
			<view class="Logisticsstatus">
				<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				<view class="logisticright">
					<div>已签收</div>
					<div>
						<p>顺丰快递：4546448558888</p>
						<p>客服电话：95500</p>
					</div>
				</view>
			</view>
			<view class="Technological">
				<view class="technotitle">
					物流跟踪
				</view>
				<view class="technoli">
					<view class="technos">
						<view class="yuan"></view>
						<view class="technosright">
							<view class="technosdiv">
								派送中，桐梓林分流点派件员，杨杨杨正在派件
							</view>
							<view class="technostime">
								2016-06-16  12:20:30
							</view>
						</view>
					</view>
					<view class="technos">
						<view class="yuan"></view>
						<view class="technosright">
							<view class="technosdiv">
								派送中，桐梓林分流点派件员，杨杨杨正在派件
							</view>
							<view class="technostime">
								2016-06-16  12:20:30
							</view>
						</view>
					</view>
					<view class="technos">
						<view class="yuan"></view>
						<view class="technosright">
							<view class="technosdiv">
								派送中，桐梓林分流点派件员，杨杨杨正在派件
							</view>
							<view class="technostime">
								2016-06-16  12:20:30
							</view>
						</view>
					</view>
					<view class="technos">
						<view class="yuan"></view>
						<view class="technosright">
							<view class="technosdiv">
								派送中，桐梓林分流点派件员，杨杨杨正在派件
							</view>
							<view class="technostime">
								2016-06-16  12:20:30
							</view>
						</view>
					</view>
					<view class="technos">
						<view class="yuan"></view>
						<view class="technosright">
							<view class="technosdiv">
								派送中，桐梓林分流点派件员，杨杨杨正在派件
							</view>
							<view class="technostime">
								2016-06-16  12:20:30
							</view>
						</view>
					</view>
					<view class="technos">
						<view class="yuan"></view>
						<view class="technosright">
							<view class="technosdiv">
								派送中，桐梓林分流点派件员，杨杨杨正在派件
							</view>
							<view class="technostime">
								2016-06-16  12:20:30
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		components: {
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	

	.logisticpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.logisticsdetails .Technological .technoli .technos .technosright .technostime{
		color: #cccccc;
		font-size: 24rpx;
	}
	
	.logisticsdetails .Technological .technoli .technos .technosright .technosdiv{
		color: #888888;
		font-size: 24rpx;
		margin-bottom: 15rpx;
	}
	
	.logisticsdetails .Technological .technoli .technos .yuan{
		width: 18rpx;
		height: 18rpx;
		background-color: #dddddd;
		border-radius: 50%;
		margin-left: -11rpx;
		margin-right: 35rpx;
		margin-top: 10rpx;
	}
	
	.logisticsdetails .Technological .technoli .technos:first-child .technosright .technosdiv{
		color: #F5BC32;
	}
	
	.logisticsdetails .Technological .technoli .technos:first-child .yuan{
		background-color: #F5BC32;
	}
	
	.logisticsdetails .Technological .technoli .technos:last-child{
		height: auto;
	}
	
	.logisticsdetails .Technological .technoli .technos{
		height: 145rpx;
		border-left: 4rpx solid #dddddd;
		display: flex;
		align-items: flex-start;
	}

	
	.logisticsdetails .Technological .technoli {
		padding: 50rpx 35rpx;
	}

	.logisticsdetails .Technological .technotitle {
		border-bottom: 1rpx solid #f2f2f2;
		height: 89rpx;
		line-height: 89rpx;
		padding: 0 18rpx;
		color: #999999;
		font-size: 28rpx;
	}

	.logisticsdetails .Technological {
		margin-top: 18rpx;
		background-color: #fff;
	}

	.logisticsdetails .Logisticsstatus .logisticright div:last-child p {
		color: #222222;
		font-size: 24rpx;
	}

	.logisticsdetails .Logisticsstatus .logisticright div:first-child {
		color: #f5bc32;
		font-size: 30rpx;
	}

	.logisticsdetails .Logisticsstatus .logisticright {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.logisticsdetails .Logisticsstatus image {
		width: 140rpx;
		height: 140rpx;
		background-color: #ffffff;
		border-radius: 5rpx;
		margin-right: 20rpx;
	}

	.logisticsdetails .Logisticsstatus {
		background-color: #ffffff;
		padding: 30rpx 18rpx;
		display: flex;
		margin: 18rpx 0;
	}

	.logisticsdetails {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
	}
</style>
