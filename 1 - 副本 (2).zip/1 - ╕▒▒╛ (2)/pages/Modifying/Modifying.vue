<template>
	<view class="business">
		<div class='head'></div>
		<div class='introduction'>
			<div class='introne'>
				<div class='intrtop'>
					<div class='intrimg'>
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<div class='abso'>封面</div>
					</div>
					<div class='addimg' @click='addimage'>
						<image mode="widthFix" src="../../static/images/xiangji.png"></image>
						<div>添加图片</div>
					</div>
				</div>
				<div class='intrbottom'>最多上传50张</div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>商品名称</div>
				<div class='intrlitow' style='color: #222222;'><input type="text" placeholder="精品纱纺女装上衣" placeholder-style="color:#222222"></div>
				<div class='intrlithree'></div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>商品说明</div>
				<div class='intrlitow'><input type="text" placeholder="请输入商品说明"></div>
				<div class='intrlithree'></div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>商品分类</div>
				<div class='intrlitow'>请选择商品分类</div>
				<div class='intrlithree'>
					<image mode="widthFix" src="../../static/images/right.png"></image>
				</div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>规格价格</div>
				<div class='intrlitow'><span>请设定商品规格价格</span>
					<div>+</div>
				</div>
				<div class='intrlithree'>
					<image mode="widthFix" src="../../static/images/right.png"></image>
				</div>
			</div>
			<div class='intrlis'>
				<div class='int'>商品描述</div>
				<div class='shopdescribe'><input type="text" value="" placeholder="描述商品详情" /></div>
			</div>
		</div>
		<div class='Recommend'>预览商品</div>
		<div class='Preservation'>发布商品</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			addimage:function(){
				uni.chooseImage({
					count: 9, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album', 'camera'], //从相册选择
					success: function(res) {
						console.log(JSON.stringify(res.tempFilePaths));
					}
				});
			}
		}
	}
</script>

<style>
	page {
		height: 100%;
		background-color: #f8f8f8;
	}

	.business .Recommend {
		width: 250rpx;
		height: 70rpx;
		background-color: #ffffff;
		border-radius: 35rpx;
		border: solid 1rpx #eeeeee;
		margin: 30rpx auto;
		text-align: center;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 70rpx;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.business .introduction .intrlis .shopdescribe input {
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.business .introduction .intrlis .shopdescribe {
		width: 626rpx;
		height: 100rpx;
		background-color: #f8f8f8;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-bottom: 30rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		padding: 0 20rpx;
	}

	.business .introduction .intrlis .int {
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 96rpx;
		letter-spacing: 0rpx;
		color: #bbbbbb;
	}

	.business .Preservation {
		width: 100%;
		height: 100rpx;
		background-color: #f5bc32;
		text-align: center;
		line-height: 100rpx;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		position: fixed;
		bottom: 0;
	}

	.business .introduction .intrclass div:first-child {
		width: auto;
		background-color: #FFFFFF;
		border: none;
	}

	.business .introduction .intrclass div {
		width: 150rpx;
		height: 50rpx;
		border-radius: 25rpx;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #bbbbbb;
		text-align: center;
		line-height: 50rpx;
		margin: auto 0;
		border: solid 1rpx #eeeeee;
	}

	.business .introduction .intrclass {
		height: 98rpx;
		display: flex;
		justify-content: space-between;
	}

	.business .introduction .intrli .intrlithree image {
		width: 100%;
	}

	.business .introduction .intrli .intrlithree {
		width: 28rpx;
		margin: auto 0;
	}

	.business .introduction .intrli .intrlitow div {
		width: 38rpx;
		height: 38rpx;
		border: solid 2rpx #222222;
		border-radius: 50%;
		color: #f5bc32;
		font-size: 32rpx;
		font-weight: bold;
		margin: auto 0;
		margin-right: 28rpx;
		text-align: center;
		line-height: 38rpx;
	}

	.business .introduction .intrli .intrlitow span {
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
		margin: auto 0;
	}

	.business .introduction .intrli .intrlitow {
		flex: 1;
		margin: auto 0;
		margin-left: 20rpx;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #999999;
		display: flex;
		justify-content: space-between;
	}

	.business .introduction .intrli .intrlione {
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #bbbbbb;
		margin: auto 0;
	}

	.business .introduction .intrli {
		height: 98rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.business .introduction .introne .intrbottom {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #999999;
		line-height: 60rpx;
	}

	.business .introduction .introne .intrtop .addimg div {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin: 0 auto;
	}

	.business .introduction .introne .intrtop .addimg image {
		width: 61rpx;
		margin: 0 auto;
	}

	.business .introduction .introne .intrtop .addimg {
		width: 120rpx;
		height: 120rpx;
		background-color: #f8f8f8;
		border-radius: 5rpx;
		margin-left: 14rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.business .introduction .introne .intrtop .intrimg .abso {
		width: 100%;
		height: 40rpx;
		background-color: #3c9cff;
		opacity: 0.8;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #fffbfb;
		position: absolute;
		text-align: center;
		line-height: 40rpx;
		bottom: 0;
	}

	.business .introduction .introne .intrtop .intrimg image {
		width: 100%;
	}

	.business .introduction .introne .intrtop .intrimg {
		width: 120rpx;
		height: 120rpx;
		background-color: #f8f8f8;
		border-radius: 5rpx;
		position: relative;
	}

	.business .introduction .introne .intrtop {
		display: flex;
	}

	.business .introduction .introne {
		border-bottom: 1rpx solid #f2f2f2;
		padding-bottom: 20rpx;
		padding-top: 30rpx;
	}

	.business .introduction {
		width: 670rpx;
		padding: 0 22rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: -70rpx;
	}

	.business .head {
		height: 70rpx;
		background-color: #ffc528;
	}

	.business {
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}
</style>
