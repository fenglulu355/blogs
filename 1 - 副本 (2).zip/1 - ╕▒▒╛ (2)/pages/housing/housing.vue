<template>
	<view class="boardpage">
		<Navigation></Navigation>
		<view class="boardlod">
			<view class="boardlodlb">
				<swiper class="swiper" autoplay="true" interval="3000" duration="300" circular>
					<swiper-item v-for="item in 5">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</swiper-item>
				</swiper>
				<view class="indicator">
					<Iconfonts name="icon-xiangji" size="28rpx" colors="#bbbbbb" />
					<div>40张</div>
				</view>
			</view>
			<view class="boardtitle">
				<view class="boardnames">
					<view class="boardnamesleft">
						<view class="boardnameslefttop">
							<view class="names">
								成都锦江之星饭店
							</view>
							<view class="namelabol">
								<div>订</div>
							</view>
						</view>
						<view class="boardnamesleftbottom">
							<view class="xxlabol">
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
							</view>
							<view class="xxscore">
								4.0
							</view>
						</view>
					</view>
					<view class="boardnamesroght">
						<view class="boardnamesroghtli">
							<Iconfonts name="icon-fenxiang" size="37rpx" colors="#dddddd" />
							<div>分享</div>
						</view>
						<view class="boardnamesroghtli">
							<Iconfonts name="icon-xingxing" size="37rpx" colors="#dddddd" />
							<div>分享</div>
						</view>
					</view>
				</view>
				<view class="Matching">
					<div>
						<Iconfonts name="icon-wifi" size="27rpx" colors="#dddddd" />
						<p>无线上网</p>
					</div>
					<div>
						<Iconfonts name="icon-tingche" size="27rpx" colors="#dddddd" />
						<p>免费停车</p>
					</div>
					<div>
						<Iconfonts name="icon-knife-fork" size="27rpx" colors="#dddddd" />
						<p>免费早餐</p>
					</div>
					<div>
						<Iconfonts name="icon-chuang" size="27rpx" colors="#dddddd" />
						<p>超级大床</p>
					</div>
				</view>
				<view class="boardtimes">
					<div>
						<Iconfonts name="icon-shijian" size="25rpx" colors="#dddddd" />
						<p>营业时间 0:00-24:00</p>
					</div>
					<div>
						<p>营业许可证资质</p>
						<Iconfonts name="icon-you" size="25rpx" colors="#dddddd" />
					</div>
				</view>
				<view class="boardaddr">
					<div>
						<Iconfonts name="icon-dizhi" size="25rpx" colors="#dddddd" />
						<p>人民南路北段新希望大厦1楼B区</p>
					</div>
					<Iconfonts name="icon-daohang-" size="50rpx" colors="#ffdc28" />
				</view>
				<view class="boardaddr">
					<div>
						<Iconfonts name="icon-biaoqian" size="25rpx" colors="#dddddd" />
						<p>电话订房 <p1 style="color: #999999;">（今日已订1083）</p1></p>
					</div>
					<Iconfonts name="icon-dianhua" size="50rpx" colors="#23c88c" />
				</view>
				<view class="Fullreduction">
					<view class="fullabol">满减</view>
					<view class="fulltxt">满200减30，满100减20，满50减10</view>
					<view class="fullDiscount">
						<div>3个优惠</div>
						<Iconfonts name="icon-xia" size="25rpx" colors="#cccccc" />
					</view>
				</view>
			</view>
			<view class="boardbytime">
				<view class="tiames">
					<view class="timeleft">
						<view class="starttime">06月12日<span>今天入住</span></view>
						<view class="xian"></view>
						<view class="starttime">06月12日<span>今天入住</span></view>
					</view>
					<view class="timeright">
						<div>共3晚</div>
						<Iconfonts name="icon-you" size="25rpx" colors="#23c88c" />
					</view>
				</view>
				<view class="Specifications">
					<div>含早</div>
					<div>大床</div>
					<div>双床</div>
					<div>可取消</div>
				</view>
			</view>
			<view class="allRoom">
				<view class="allRoomtitle">
					所有房间
				</view>
				<view class="allRoomli">
					<view class="allRoomlis" v-for="item in 4" @click="housingxq">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<view class="allRoomtxt">
							<view class="allRoomtype">
								<view class="allRoomname">
									高级大床房
								</view>
								<view class="allRoomlabol">
									<div>不含早</div>
									<div>35m²</div>
									<div>大床</div>
									<div>有窗</div>
								</view>
								<view class="allRoomtimes">
									6月26日12点前可以免费取消
								</view>
							</view>
							<view class="num">￥<span>99</span></view>
						</view>
						<view class="allRoombook">
							<div>订</div>
							<div>在线预订</div>
						</view>
					</view>
					<view class="Viewmore">
						<div>查看剩余4个房型</div>
						<Iconfonts name="icon-xiala" size="25rpx" colors="#dddddd" />
					</view>
				</view>
			</view>
			<view class="boardcomment">
				<view class="commenttitle" @click="allcomment">
					<div>用户评论</div>
					<div>全部评论（ 145 条）</div>
				</view>
				<view class="commentlabol">
					<div v-for="item in 5">晒图评价 99</div>
				</view>
				<view class="commentall">
					<view class="commentone" v-for="item in 5">
						<view class="commentlift">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						</view>
						<view class="commentright">
							<view class="commentname">
								<div>流沙包</div>
								<div>2019.03.16</div>
							</view>
							<view class="commentxinxin">
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
							</view>
							<view class="commentext">
								<view class="text">味道非常好，好吃得快飞起来了！</view>
								<view class="images">
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="Suctionbottom">
				<div>最新预定1分钟前</div>
				<div>查看房型</div>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {

			}
		},
		methods: {
			allcomment:function(){
				uni.navigateTo({
					url: '../allcomment/allcomment'
				});
			},
			housingxq:function(){
				uni.navigateTo({
					url: '../housingxq/housingxq'
				});
			}
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	.boardlod .boardbytime .Specifications div{
		width: 165rpx;
		height: 50rpx;
		background-color: #e9f9f3;
		border-radius: 5rpx;
		text-align: center;
		line-height: 50rpx;
		color: #23c88c;
		font-size: 24rpx;
	}
	.boardlod .boardbytime .Specifications{
		display: flex;
		justify-content: space-between;
	}
	.boardlod .boardbytime .tiames .timeright Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.boardlod .boardbytime .tiames .timeright div{
		margin-right: 12rpx;
		color: #23c88c;
		font-size: 24rpx;
		margin: auto 0;
	}
	.boardlod .boardbytime .tiames .timeright{
		display: flex;
	}
	.boardlod .boardbytime .tiames .timeleft .xian{
		width: 40rpx;
		height: 2rpx;
		margin: auto 30rpx;
		background-color: #f8f8f8;
	}
	.boardlod .boardbytime .tiames .timeleft .starttime span{
		color: #999999;
		font-size: 24rpx;
	}
	.boardlod .boardbytime .tiames .timeleft .starttime{
		margin: auto 0;
		color: #222222;
		font-size: 32rpx;
	}
	.boardlod .boardbytime .tiames .timeleft{
		flex: 1;
		display: flex;
	}
	.boardlod .boardbytime .tiames{
		display: flex;
		margin-bottom: 25rpx;
	}
	.boardlod .boardbytime{
		margin-bottom: 18rpx;
		padding: 25rpx 18rpx;
		background-color: #fff;
		display: flex;
		flex-direction: column;
	}
	.boardlod .allRoom .allRoomli .Viewmore Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.boardlod .allRoom .allRoomli .Viewmore div{
		margin: auto 0;
		margin-right: 10rpx;
		color: #222222;
		font-size: 24rpx;
	}
	.boardlod .allRoom .allRoomli .Viewmore{
		height: 77rpx;
		display: flex;
		justify-content: center;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoombook div:last-child{
		text-align: center;
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: center;
		color: #23c88c;
		font-size: 22rpx;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoombook div:first-child{
		height: 60rpx;
		background-color: #23c88c;
		color: #ffffff;
		font-size: 32rpx;
		text-align: center;
		line-height: 60rpx;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoombook{
		margin: auto 0;
		width: 100rpx;
		height: 100rpx;
		border-radius: 5rpx;
		border: solid 1rpx #23c88c;
		display: flex;
		flex-direction: column;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoomtxt .num span{
		color: #ff643a;
		font-size: 32rpx;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoomtxt .num{
		color: #ff643a;
		font-size: 22rpx;
		font-weight: bold;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoomtxt .allRoomtype .allRoomtimes{
		color: #23c88c;
		font-size: 22rpx;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoomtxt .allRoomtype .allRoomlabol div{
		margin-right: 16rpx;
		color: #999999;
		font-size: 22rpx;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoomtxt .allRoomtype .allRoomlabol{
		display: flex;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoomtxt .allRoomtype .allRoomname{
		color: #222222;
		font-size: 24rpx;
	}
	.boardlod .allRoom .allRoomli .allRoomlis .allRoomtxt{
		flex: 1;
		margin: 0 18rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	} 
	.boardlod .allRoom .allRoomli .allRoomlis image{
		width: 160rpx;
		height: 160rpx;
		border-radius: 5rpx;
	}
	.boardlod .allRoom .allRoomli .allRoomlis:first-child{
		padding-top: 0;
	}
	.boardlod .allRoom .allRoomli .allRoomlis{
		padding: 30rpx 0;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
	}
	.boardlod .allRoom .allRoomli{
		display: flex;
		flex-direction: column;
	}
	.boardlod .allRoom .allRoomtitle{
		height: 86rpx;
		line-height: 86rpx;
		color: #222222;
		font-size: 28rpx;
	}
	.boardlod .allRoom{
		margin-bottom: 20rpx;
		padding: 0 18rpx;
		background-color: #fff;
	}
	.boardlod .boardtitle .Fullreduction .fullDiscount Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.boardlod .boardtitle .Fullreduction .fullDiscount div{
		margin: auto 0;
		color: #666666;
		font-size: 24rpx;
		margin-right: 12rpx;
	}
	.boardlod .boardtitle .Fullreduction .fullDiscount{
		display: flex;
		margin: auto 0;
	}
	.boardlod .boardtitle .Fullreduction .fulltxt{
		flex: 1;
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}
	.boardlod .boardtitle .Fullreduction .fullabol{
		width: 48rpx;
		height: 24rpx;
		background-color: #ff643a;
		border-radius: 3rpx;
		text-align: center;
		line-height: 24rpx;
		color: #ffffff;
		font-size: 20rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}
	.boardlod .boardtitle .Fullreduction{
		height: 80rpx;
		display: flex;
		justify-content: space-between;
	}
	.boardlod .boardtitle .boardaddr div p{
		margin: auto 0;
		margin-left: 15rpx;
		color: #222222;
		font-size: 24rpx;
	}
	.boardlod .boardtitle .boardaddr div{
		margin: auto 0;
		display: flex;
	}
	.boardlod .boardtitle .boardaddr Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.boardlod .boardtitle .boardaddr{
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		border-bottom: 1rpx solid #f2f2f2;
	}
	.boardlod .boardtitle .boardtimes div:last-child p{
		color: #666666;
		font-size: 24rpx;
		margin: auto 0;
	}
	.boardlod .boardtitle .boardtimes div:last-child Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-left: 15rpx;
	}
	.boardlod .boardtitle .boardtimes div:last-child{
		display: flex;
		margin: auto 0;
	}
	.boardlod .boardtitle .boardtimes div:first-child p{
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}
	.boardlod .boardtitle .boardtimes div:first-child Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 15rpx;
	}
	.boardlod .boardtitle .boardtimes div:first-child{
		display: flex;
		margin: auto 0;
	}
	.boardlod .boardtitle .boardtimes{
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		border-bottom: 1rpx solid #f2f2f2;
	}
	.boardlod .boardtitle .Matching div p{
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
		margin-left: 10rpx;
	}
	.boardlod .boardtitle .Matching div Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.boardlod .boardtitle .Matching div{
		display: flex;
		margin: auto 0;
		margin-right: 25rpx;
	}
	.boardlod .boardtitle .Matching{
		display: flex;
		height: 65rpx;
		border-bottom: 1rpx solid #f2f2f2;
	}
	.boardlod .boardtitle .boardnames .boardnamesroght .boardnamesroghtli div{
		margin: 0 auto;
		color: #666666;
		font-size: 22rpx;
	}
	.boardlod .boardtitle .boardnames .boardnamesroght .boardnamesroghtli Iconfonts{
		margin: 0 auto;
		display: flex;
		justify-content: center;
	}
	.boardlod .boardtitle .boardnames .boardnamesroght .boardnamesroghtli:last-child{
		margin: 0;
	}
	.boardlod .boardtitle .boardnames .boardnamesroght .boardnamesroghtli{
		display: flex;
		flex-direction: column;
		margin-right: 40rpx;
	}
	.boardlod .boardtitle .boardnames .boardnamesroght{
		display: flex;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnamesleftbottom .xxscore{
		color: #666666;
		font-size: 22rpx;
		margin: auto 0;
		margin-left: 20rpx;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnamesleftbottom .xxlabol Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnamesleftbottom .xxlabol{
		display: flex;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnamesleftbottom{
		display: flex;
	}
	
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnameslefttop .namelabol div{
		width: 34rpx;
		height: 34rpx;
		border-radius: 3px;
		border: solid 1rpx #23c88c;
		text-align: center;
		line-height: 34rpx;
		color: #23c88c;
		font-size: 24rpx;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnameslefttop .namelabol{
		display: flex;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnameslefttop .names{
		color: #222222;
		font-size: 32rpx;
		margin: auto 0;
		margin-right: 20rpx;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft .boardnameslefttop{
		display: flex;
	}
	.boardlod .boardtitle .boardnames .boardnamesleft{
		display: flex;
		flex-direction: column;
	}
	.boardlod .boardtitle .boardnames{
		display: flex;
		justify-content: space-between;
		padding: 25rpx 0;
	}
	.boardlod .boardtitle{
		padding: 0 18rpx;
		background-color: #fff;
		margin-bottom: 20rpx;
	}
	.Suctionbottom div:last-child{
		background-color: #23c88c;
		color: #ffffff;
		font-size: 32rpx;
	}
	.Suctionbottom div:first-child{
		background-color: #fff;
		color: #222222;
		font-size: 24rpx;
	}
	.Suctionbottom div{
		width: 50%;
		text-align: center;
		line-height: 100rpx;
	}
	
	.Suctionbottom{
		width: 100%;
		height: 100rpx;
		display: flex;
		position: fixed;
		bottom: 0;
	}

	.boardpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext .images image{
		width: 141rpx;
		height: 141rpx;
		background-color: #ffdc28;
		border-radius: 10rpx;
		margin-right: 10rpx;
		
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext .images{
		display: flex;
		flex-wrap: wrap;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext .text{
		color: #2d2d2d;
		font-size: 24rpx;
		margin: 12rpx 0;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentext{
		margin: 30rpx 0;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentxinxin Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 5rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentxinxin{
		display: flex;
		margin: 12rpx 0;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentname div:last-child{
		color: #b3b3b3;
		font-size: 24rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentname div:first-child{
		color: #2d2d2d;
		font-size: 28rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright .commentname{
		display: flex;
		justify-content: space-between;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentright{
		display: flex;
		flex-direction: column;
		border-bottom: 1rpx solid #f2f2f2;
		flex: 1;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentlift image{
		width: 82rpx;
		height: 82rpx;
		border: solid 1rpx #f5f5f5;
		border-radius: 50%;
	}
	
	.boardlod .boardcomment .commentall .commentone .commentlift{
		margin-right: 20rpx;
	}
	
	.boardlod .boardcomment .commentall .commentone{
		display: flex;
		margin-bottom: 30rpx;
	}
	
	.boardlod .boardcomment .commentlabol div{
		margin: 12rpx 0;
		padding: 0 25rpx;
		height: 50rpx;
		border-radius: 25rpx;
		border: solid 1rpx #cccccc;
		margin-right: 20rpx;
		text-align: center;
		line-height: 50rpx;
		color: #666666;
		font-size: 24rpx;
	}
	
	.boardlod .boardcomment .commentlabol{
		display: flex;
		flex-wrap: wrap;
		margin-bottom: 25rpx;
	}
	
	.boardlod .boardcomment .commenttitle div:last-child{
		color: #999999;
		font-size: 24rpx;
		margin: auto 0;
	}
	
	.boardlod .boardcomment .commenttitle div:first-child{
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
		margin: auto 0;
	}
	
	.boardlod .boardcomment .commenttitle{
		height: 84rpx;
		display: flex;
		justify-content: space-between;
	}
	
	.boardlod .boardcomment{
		padding: 0 18rpx;
		background-color: #fff;
		margin-bottom: 100rpx;
	}

	.boardlod .boardlodlb .indicator div{
		color: #bbbbbb;
		font-size: 24rpx;
		margin: auto 0;
		margin-left: 10rpx;
	}
	
	.boardlod .boardlodlb .indicator Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.boardlod .boardlodlb .indicator{
		width: 140rpx;
		height: 50rpx;
		background-color: rgba(0,0,0,0.5);
		border-radius: 25rpx;
		position: absolute;
		bottom: 18rpx;
		right: 18rpx;
		display: flex;
		justify-content: center;
	}
	
	.boardlod .boardlodlb .swiper image{
		width: 100%;
	}
	
	.boardlod .boardlodlb .swiper{
		height: 100%;
	}

	.boardlod .boardlodlb {
		height: 350rpx;
		position: relative;
	}

	.boardlod {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
	}
</style>