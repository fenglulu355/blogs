<template>
	<view class='classified'>
		<div class='classifleft'>
			<div class='classleftli' v-for="(item,index) in oneclass" :style="item.sty" @click="changesty(index)">{{item.name}}</div>
		</div>
		<div class='classifright'>
			<div class='onecommod' v-for="item in 9" :key="item" @click="details">
				<div class='comimg'>
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				</div>
				<div class='comtitle'>酸辣土豆丝</div>
				<div class='comnum'>月售55</div>
				<div class='comtotal'><span>￥</span>10.6</div>
			</div>
		</div>
		<div class='Reset'>
			<div>修改商品</div>
			<div>添加商品</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				oneclass: [{
						name: '热门推荐',
						sty: 'border-left:2rpx solid #f5bc32;background-color:#fff',
						isinp: true
					}, {
						name: '精品小炒',
						sty: 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4',
						isinp: true
					},
					{
						name: '特色硬菜',
						sty: 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4',
						isinp: true
					},
					{
						name: '酒水饮料',
						sty: 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4',
						isinp: true
					}
				]
			}
		},
		methods: {
			changesty: function(e) {
				let arr1 = this.oneclass;
				for (let i in arr1) {
					arr1[i].sty = 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4'
				}
				arr1[e].sty = 'border-left:2rpx solid #f5bc32;background-color:#fff';
				this.oneclass = arr1;
			},
			details:function(){
				uni.navigateTo({
					url: '../comdetails/comdetails'
				});
			}
		}
	}
</script>

<style>
	page {
		height: 100%;
		background-color: #f8f8f8;
	}

	.classified .Reset div:last-child {
		background-color: #f5bc32;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.classified .Reset div:first-child {
		background-color: #222222;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.classified .Reset div {
		width: 50%;
		line-height: 100rpx;
		text-align: center;
	}

	.classified .Reset {
		width: 530rpx;
		height: 100rpx;
		position: fixed;
		bottom: 0;
		right: 0;
		display: flex;
	}

	.classified .classifright .onecommod .comtotal span {
		font-size: 22rpx;
	}

	.classified .classifright .onecommod .comtotal {
		font-family: San-Francisco-Display-Medium;
		font-size: 3r2px;
		font-weight: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
		margin-top: 24rpx;
	}

	.classified .classifright .onecommod .comnum {
		font-family: PingFang-SC-Medium;
		font-size: 22rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.classified .classifright .onecommod .comtitle {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.classified .classifright .onecommod .comimg image {
		width: 100%;
	}

	.classified .classifright .onecommod .comimg {
		width: 100%;
		border-radius: 5rpx;
	}

	.classified .classifright .onecommod {
		width: 212rpx;
		float: left;
		margin: 14rpx;
	}

	.classified .classifright {
		flex: 1;
		height: auto;
		padding: 30rpx;
		padding-bottom: 130rpx;
		margin-left: 220rpx;
		/* display: flex;
		flex-wrap: wrap; */
	}

	.classified .classifleft .classleftli {
		height: 100rpx;
		border-bottom: 1rpx solid #fff;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 2rpx;
		color: #222222;
		line-height: 100rpx;
		text-align: center;
	}

	.classified .classifleft {
		width: 220rpx;
		height: 100%;
		background-color: #f4f4f4;
		position: fixed;
		left: 0;
	}

	.classified {
		/* height: 100%; */
		display: flex;
	}
</style>
