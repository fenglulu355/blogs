<template>
	<view class='seck'>
		<Navigation></Navigation>
		<div class='seckill'>
			<scroll-view class="swiper-tab" scroll-x :scroll-with-animation="true" show-scrollbar="false" :scroll-into-view="tabid">
				<view v-for="(item,index) in times" :key="item" :id="'a'+index" class="swiperli" @click="tabs(item,index)" :style="'background-color:'+item.background">
					<view class='time' :style="'color:'+item.color">{{item.time}}</view>
					<view class="state" :style="'color:'+item.color">{{item.title}}</view>
					<div class='sj' :style="'border-top-color:'+ item.bordercolor"></div>
				</view>
			</scroll-view>
			<view class="seckRush">
				<view class="seckleft">
					<div class='secktitle'>必抢 好货</div>
					<div class='seckimg'>
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</div>
				</view>
				<view class="seckright">
					<view class='righttxt'>全网通全面屏社偶记开抢了</view>
					<view>
						<view class="gou">
							<image mode="widthFix" src="../../static/images/gou.png"></image>
							<div>新品上市现货速发</div>
						</view>
						<view class="gou">
							<image mode="widthFix" src="../../static/images/gou.png"></image>
							<div>新品上市现货速发</div>
						</view>
					</view>

					<view class="num">
						<div class='Progress'></div>
						<div class="progtxt">已抢18件</div>
						<div></div>
					</view>
					<view class='total'>
						<view class='dazhe'>¥<span>6666</span></view>
						<view class="yuanjia">¥9999</view>
					</view>
				</view>
			</view>
			<view class="exclusive">
				<view class="exctitle">专属推荐</view>
				<view class="excontent">
					<view class="excli" v-for="item in 6" :key="item">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<view class='exctext'>宝优妮 阳台晾衣架落地晒衣架不锈钢</view>
						<view class="exctxta">
							¥399
						</view>
					</view>
				</view>
			</view>
			<view class="Rushtobuy">
				<view class="rushtobuyli" v-for="item in 6" :key="item" @click="seckilxq">
					<view class="rushleft">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</view>
					<view class="rushright">
						<view class="rushtitle">宝优妮 阳台晾衣架落地晒衣架不锈钢晾衣杆单杆衣架杆DQ0777B-1</view>
						<view class="rushinfo">
							<view class="rushinfoleft">
								<view class="rushSpeed">
									<div></div>
									<span>已抢18件</span>
								</view>
								<view class="rushmon">
									<div>¥128</div>
									<div>¥9999</div>
								</view>
							</view>
							<view class="rushinforight">抢购</view>
						</view>
					</view>
				</view>
			</view>
		</div>
	</view>
</template>

<script>
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				tabid: 'a' + 0,
				bashurl: '',
				times: [{
						time: '00:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '01:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '02:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '03:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '04:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					}, {
						time: '05:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					}, {
						time: '06:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '07:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '08:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '09:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '10:00',
						title: '已结束',
						state: 0,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '11:00',
						title: '进行中',
						state: 1,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '12:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '13:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '14:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '15:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '16:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '17:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '18:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '19:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '20:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '21:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},
					{
						time: '22:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					},{
						time: '23:00',
						title: '未开始',
						state: 2,
						bordercolor: 'transparent',
						background: '#F5BC32',
						color: '#000'
					}
				]
			}
		},
		mounted() {
			for (let i in this.times) {
				if (this.times[i].state == 1) {
					this.tabid = 'a' + (i - 2);
					this.times[i].bordercolor = '#ff643a'
					this.times[i].background = '#ff643a'
					this.times[i].color = '#fff'
				}
			}
		},
		created: function() {
			console.log(this.shophome,"shophome")
			this.getSeckillli();
			let time = Date.parse(new Date());
			console.log(time);
			// setInterval(function(){
			//    var date=new Date();
			//    var year=date.getFullYear(); //获取当前年份
			//    var mon=date.getMonth()+1; //获取当前月份
			//    var da=date.getDate(); //获取当前日
			//    var day=date.getDay(); //获取当前星期几
			//    var h=date.getHours(); //获取小时
			//    var m=date.getMinutes(); //获取分钟
			//    var s=date.getSeconds(); //获取秒
			//    // var d=document.getElementById('Date'); 
			//    // d.innerHTML='当前时间:'+year+'年'+mon+'月'+da+'日'+'星期'+day+' '+h+':'+m+':'+s;
			//    console.log('当前时间:'+year+'年'+mon+'月'+da+'日'+'星期'+day+' '+h+':'+m+':'+s)
			//   },1000);
		},
		computed: {
			...mapState(['shophome'])
		},
		methods: {
			...mapActions(['getSeckillli']),
			tabs: function(item, index) {
				for (let i in this.times) {
					this.times[i].bordercolor = 'transparent'
					this.times[i].background = '#F5BC32'
					this.times[i].color = '#000'
					if (i == index) {
						this.tabid = 'a' + (i - 2);
						this.times[i].bordercolor = '#ff643a'
						this.times[i].background = '#ff643a'
						this.times[i].color = '#fff'
					}
				}
			},
			seckilxq: function() {
				uni.navigateTo({
					url: '../Seckillxq/Seckillxq'
				});
			}
		},
		components: {
			Navigation
		}
	}
</script>

<style>
	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo .rushinforight {
		width: 90rpx;
		height: 50rpx;
		background-color: #ff643a;
		border-radius: 5rpx 10rpx 5rpx 10rpx;
		margin: auto 0;
		text-align: center;
		line-height: 50rpx;
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo .rushinfoleft .rushmon div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		text-decoration: line-through;
		color: #999999;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo .rushinfoleft .rushmon div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo .rushinfoleft .rushmon {
		display: flex;
		align-items: flex-end;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo .rushinfoleft .rushSpeed span {
		font-family: PingFang-SC-Medium;
		font-size: 18rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
		margin: auto 0;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo .rushinfoleft .rushSpeed div {
		width: 35rpx;
		height: 100%;
		background-color: #ff643a;
		border-radius: 13rpx;
		margin-right: 10rpx;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo .rushinfoleft .rushSpeed {
		width: 231rpx;
		height: 25rpx;
		background-color: #ffede6;
		border-radius: 13rpx;
		border: solid 1rpx #fbbead;
		display: flex;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushinfo {
		display: flex;
		justify-content: space-between;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright .rushtitle {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushright {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushleft image {
		width: 100%;
		border-radius: 5rpx;
	}

	.seck .seckill .Rushtobuy .rushtobuyli .rushleft {
		width: 150rpx;
		height: 150rpx;
		background-color: #000000;
		border-radius: 5rpx;
		margin-right: 18rpx;
	}

	.seck .seckill .Rushtobuy .rushtobuyli {
		height: 150rpx;
		background-color: #ffffff;
		margin-bottom: 10rpx;
		padding: 30rpx 18rpx;
		display: flex;
	}

	.seck .seckill .Rushtobuy {
		margin-bottom: 40rpx;
	}

	.seck .seckill .exclusive .excontent .excli .exctxta {
		text-align: center;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
	}

	.seck .seckill .exclusive .excontent .excli .exctext {
		width: 100%;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seck .seckill .exclusive .excontent .excli image {
		width: 100%;
		border-radius: 5px;
	}

	.seck .seckill .exclusive .excontent .excli:last-child {
		margin: 0;
	}

	.seck .seckill .exclusive .excontent .excli {
		width: 169rpx;
		margin-right: 16rpx;
	}

	.seck .seckill .exclusive .excontent {
		display: flex;
		overflow: auto;
	}

	.seck .seckill .exclusive .exctitle {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #333333;
		margin: 30rpx 0;
	}

	.seck .seckill .exclusive {
		height: 360rpx;
		background-color: #ffffff;
		margin-bottom: 20rpx;
		padding: 0 17rpx;
		display: flex;
		flex-direction: column;
	}

	.seck .seckill .seckRush .seckright .num .progtxt {
		font-family: PingFang-SC-Medium;
		font-size: 18rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
		margin: auto 0;
	}

	.seck .seckill .seckRush .seckright .num .Progress {
		width: 35rpx;
		height: 100%;
		background-color: #ff643a;
		border-radius: 13rpx;
		margin-right: 10rpx;
	}

	.seck .seckill .seckRush .seckright .total .yuanjia {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #999999
	}

	.seck .seckill .seckRush .seckright .total .dazhe span {
		font-size: 36rpx;
	}

	.seck .seckill .seckRush .seckright .total .dazhe {
		font-family: PingFang-SC-Bold;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #ff643a;
	}

	.seck .seckill .seckRush .seckright .total {
		display: flex;
		align-items: flex-end
	}

	.seck .seckill .seckRush .seckright .num {
		width: 231rpx;
		height: 25rpx;
		background-color: #ffede6;
		border-radius: 13rpx;
		border: solid 1rpx #fbbead;
		display: flex;
		box-sizing: border-box;
	}

	.seck .seckill .seckRush .seckright .gou div {
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #222222;
		margin: auto 0;
	}

	.seck .seckill .seckRush .seckright .gou image {
		width: 31rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}

	.seck .seckill .seckRush .seckright .gou {
		display: flex;
	}

	.seck .seckill .seckRush .seckright .righttxt {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #666666;
	}

	.seck .seckill .seckRush .seckright {
		flex: 1;
		padding-top: 50rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.seck .seckill .seckRush .seckleft .seckimg image {
		width: 100%;
	}

	.seck .seckill .seckRush .seckleft .seckimg {
		width: 246rpx;
	}

	.seck .seckill .seckRush .seckleft .secktitle {
		font-family: PingFang-SC-Heavy;
		font-size: 36rpx;
		font-weight: bold;
		font-style: italic;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #333333;
	}

	.seck .seckill .seckRush .seckleft {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-right: 30rpx;
	}

	.seck .seckill .seckRush {
		width: 684rpx;
		height: 320rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		padding: 15rpx;
		padding-bottom: 40rpx;
		display: flex;
		margin-bottom: 20rpx;
	}

	.swiperli .state {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		text-align: center;
	}

	.swiperli .time {
		font-family: PingFang-SC-Regular;
		font-size: 36rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #222222;
		text-align: center;
		margin-top: 7rpx;
	}

	.swiperli .sj {
		height: 0;
		width: 0;
		border-bottom: 12rpx solid transparent;
		border-top: 12rpx solid red;
		border-left: 12rpx solid transparent;
		border-right: 12rpx solid transparent;
		position: absolute;
		left: 0;
		right: 0;
		bottom: -20rpx;
		z-index: 2;
		margin: 0 auto;
	}

	.swiperli {
		font-size: 30upx;
		width: 150rpx;
		height: 100rpx;
		display: inline-block;
		text-align: center;
		color: #000;
		background: #F5BC32;
		position: relative;
	}

	.swiper-tab {
		width: 100%;
		white-space: nowrap;
		height: 124rpx;
		border: 0;
	}

	.seckill {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
	}

	.seck {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100vh;
	}
</style>
