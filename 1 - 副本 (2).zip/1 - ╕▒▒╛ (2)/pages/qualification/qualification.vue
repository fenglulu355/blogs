<template>
	<view class="qualificapage">
		<Navigation></Navigation>
		<view class="qualifica">
			<view class="quaimg">
				<view class="title">
					营业许可资质
				</view>
				<view class="imgs">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		components:{
			Navigation
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.qualificapage{
	height: 100%;
	display: flex;
	flex-direction: column;
}
.qualifica .quaimg .imgs image{
	width: 100%;
}
.qualifica .quaimg .imgs{
	width: 100%;
}
.qualifica .quaimg .title{
	height: 73rpx;
	line-height: 73rpx;
	color: #222222;
	font-size: 28rpx;
	font-weight: bold;
}
.qualifica .quaimg{
	padding: 0 18rpx;
	margin-top: 18rpx;
	background-color: #fff;
	flex: 1;
}
.qualifica{
	flex: 1;
	background-color: #f8f8f8;
	overflow: auto;
	display: flex;
	flex-direction: column;
}
</style>
