<template>
	<view class="secondchatpage">
		<Navigation></Navigation>
		<view class="secondchat">
			<view class="secondchatop">
				<view class="secondshop">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<view class="secondshopname">
						<div>Dell戴尔家用台式一体...</div>
						<div>
							<p>￥199.00</p>
							<p>不含运费</p>
						</div>
					</view>
					<view class="purchase">马上买</view>
				</view>
				<view class="secondchatli">
					<scroll-view scroll-y="true" class="scroll-Y" scroll-into-view="demo1">
						<view v-for="item in secondchat">
							<view class="chat" v-if="item.static == 0" style="justify-content: flex-start;">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<view class="chatdiv" style="background-color: #fff;color: #222222;">
									{{item.value}}
								</view>
							</view>
							<view class="chat" v-else style="justify-content: flex-end;">
								<view class="chatdiv" style="background-color: #3c9cff;color: #fff;">
									{{item.value}}
								</view>
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			<view class="secondchatbottom">
				<view class="one">+</view>
				<view class="tow"><input type="text" name="" id="" v-model="inputvalue" placeholder="请输入您要发送的信息"></view>
				<view class="three" @click="sub">
					<Iconfonts name="icon-emizhifeiji" size="42rpx" colors="#fff" />
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				inputvalue:'',
				secondchat: [
				]
			}
		},
		onShow:function(){
			uni.getStorage({
			    key: 'secondchats',
			    success: function (res) {
					this.secondchat = res.data
			        // console.log(res.data);
			    }
			});
		},
		methods: {
			sub:function(){
				if(this.inputvalue){
					let arr = this.secondchat;
					arr.push({
						value:this.inputvalue,
						static:0
					});
					uni.setStorage({
					    key: 'secondchats',
					    data: arr,
					    success: function () {
					        console.log('success');
					    }
					});
				}
			}
		},
		components: {
			Iconfonts,
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.secondchat .secondchatop .secondchatli .scroll-Y .chat .chatdiv {
		/* width: 208rpx;
		height: 77rpx; */
		word-wrap: break-word;
		word-break: break-all;
		overflow: hidden;
		min-width: 400rpx;
		padding: 20rpx;
		background-color: #ffffff;
		box-shadow: 0rpx 1rpx 20rpx 0rpx rgba(195, 195, 195, 0.35);
		border-radius: 20rpx;
		margin: 0 12rpx;
		color: #222222;
		font-size: 28rpx;
	}

	.secondchat .secondchatop .secondchatli .scroll-Y .chat image {
		width: 73rpx;
		height: 72rpx;
		border-radius: 50%;
	}

	.secondchat .secondchatop .secondchatli .scroll-Y .chat {
		display: flex;
		margin: 15rpx 0;
	}

	.secondchat .secondchatop .secondchatli .scroll-Y {
		height: 100%;
	}

	.secondchat .secondchatop .secondchatli {
		flex: 1;
		padding: 35rpx 18rpx;
	}

	.secondchat .secondchatop .secondshop .purchase {
		width: 200rpx;
		height: 66rpx;
		background-color: #3c9cff;
		border-radius: 5rpx;
		margin: auto 0;
		text-align: center;
		line-height: 66rpx;
		color: #ffffff;
		font-size: 32rpx;
	}

	.secondchat .secondchatop .secondshop .secondshopname div:last-child p:last-child {
		color: #9b9b9b;
		font-size: 20rpx;
	}

	.secondchat .secondchatop .secondshop .secondshopname div:last-child p:first-child {
		color: #3c9cff;
		font-size: 28rpx;
		margin-right: 18rpx;
	}

	.secondchat .secondchatop .secondshop .secondshopname div:last-child {
		display: flex;
	}

	.secondchat .secondchatop .secondshop .secondshopname div:first-child {
		color: #222222;
		width: 100%;
		font-size: 28rpx;
		font-weight: bold;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.secondchat .secondchatop .secondshop .secondshopname {
		flex: 1;
		margin: 0 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 12rpx 0;
	}

	.secondchat .secondchatop .secondshop image {
		width: 112rpx;
		height: 112rpx;
		background-color: #d8d8d8;
		border-radius: 5rpx;
	}

	.secondchat .secondchatop .secondshop {
		background-color: #ffffff;
		display: flex;
		padding: 30rpx 18rpx;
	}

	.secondchat .secondchatbottom .three Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.secondchat .secondchatbottom .three {
		width: 128rpx;
		background-color: #3c9cff;
		display: flex;
		justify-content: center;
	}

	.secondchat .secondchatbottom .tow input {
		color: #cccccc;
		font-size: 24rpx;
		flex: 1;
	}

	.secondchat .secondchatbottom .tow {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: center;
		padding: 0 25rpx;
	}

	.secondchat .secondchatbottom .one {
		width: 95rpx;
		border-right: 2rpx solid #f8f8f8;
		text-align: center;
		line-height: 87rpx;
		font-size: 50rpx;
		color: #3c9cff;
	}

	.secondchat .secondchatbottom {
		height: 87rpx;
		background-color: #ffffff;
		box-shadow: 0px 1px 20px 0px rgba(195, 195, 195, 0.35);
		display: flex;
	}

	.secondchat .secondchatop {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.secondchatpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.secondchat {
		flex: 1;
		display: flex;
		flex-direction: column;
	}
</style>
