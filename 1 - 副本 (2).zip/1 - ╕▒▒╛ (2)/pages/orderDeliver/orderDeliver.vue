<template>
	<view class="orderdeliver">
		<div class='logistics'>
			<div class='logs' @click='confirma'>
				<div><img src="../../static/images/char.png" alt=""></div>
				<div class="logtxt">暂无物流信息</div>
				<div><img src="../../static/images/right.png" alt=""></div>
			</div>
			<div class='information'>
				<div class='infoimg'><img src="../../static/images/dv.png" alt=""></div>
				<div class='infotxt'>
					<div>杨YY 156 6666 6666</div>
					<div>地址：四川省成都市武侯区人民南路北段新希望大厦7楼704室</div>
				</div>
			</div>
			<div class='message'>
				<div class='messimg'><img src="../../static/images/xx.png" alt=""></div>
				<div class='messtxt'>
					<div>买家留言</div>
					<div>需要包装好些</div>
				</div>
			</div>
		</div>
		<div class='briefintroduction'>
			<div class='brierone'>订单号:2134323533</div>
			<div class='briertow'>
				<div class='brierimg'>
					<img src="../../static/images/orders.jpg" alt="">
				</div>
				<div class='briertxt'>
					<div class='briertitle'>
						<div>休闲卤味风味鸭头</div>
						<div>规格：1份</div>
					</div>
					<div class='brierbottom'>
						<div>￥9.90</div>
						<div>x1</div>
					</div>
				</div>
			</div>
			<div class='briermessage'>
				<div>收货人信息</div>
				<div>杨YY 156 6666 6666</div>
				<div style='color: #666666;'>四川省成都市武侯区人民南路北段新希望大厦7楼704室</div>
			</div>
			<div class='brierinfo briersa'>买家留言:<span style='color: #f5bc32;'>无</span></div>
			<div class='brierinfo'>共1件商品(含运费) 合计:<span style='color: #ff683a;font-weight: bold;'>￥9.90</span></div>
		</div>
		<div class='Immediatedelivery' @click='confirma'>立即发货</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			confirma:function(){
				uni.navigateTo({
					url: '../Confirmation/Confirmation'
				});
			}
		}
	}
</script>

<style>
	page {
		height: 100%;
	}

	.briersa {
		border-bottom: 1rpx solid #f2f2f2;
	}

	.orderdeliver .Immediatedelivery {
		width: 250rpx;
		height: 70rpx;
		background-color: #ff683a;
		box-shadow: 0rpx 5rpx 20rpx 0rpx #ff683a;
		border-radius: 35rpx;
		margin: 20rpx auto;
		font-family: PingFang-SC-Bold;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 70rpx;
	}

	.orderdeliver .briefintroduction .brierinfo {
		line-height: 96rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .briefintroduction .briermessage div {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.orderdeliver .briefintroduction .briermessage {
		padding: 35rpx 0;
		border-bottom: 1rpx solid #f2f2f2;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .brierbottom div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .brierbottom div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff683a;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .brierbottom {
		display: flex;
		justify-content: space-between;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .briertitle div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .briertitle div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;

	}

	.orderdeliver .briefintroduction .briertow .briertxt {
		margin-left: 20rpx;
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.orderdeliver .briefintroduction .briertow .brierimg img {
		width: 100%;
		height: 100%;
	}

	.orderdeliver .briefintroduction .briertow .brierimg {
		width: 160rpx;
		height: 160rpx;
	}

	.orderdeliver .briefintroduction .briertow {
		display: flex;
	}

	.orderdeliver .briefintroduction .brierone {
		line-height: 70rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .briefintroduction {
		width: 664rpx;
		/* height: 566rpx; */
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		padding: 0 22rpx;
	}

	.orderdeliver .logistics .message .messtxt div:last-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #f5bc32;
	}

	.orderdeliver .logistics .message .messtxt div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.orderdeliver .logistics .message .messtxt {
		display: flex;
		flex-direction: column;
		margin-left: 20rpx;
	}

	.orderdeliver .logistics .message .messimg img {
		width: 100%;
		height: 100%;
	}

	.orderdeliver .logistics .message .messimg {
		width: 34rpx;
		height: 34rpx;
	}

	.orderdeliver .logistics .message {
		display: flex;
	}

	.orderdeliver .logistics .information .infotxt div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .logistics .information .infotxt div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}


	.orderdeliver .logistics .information .infotxt {
		flex: 1;
		display: flex;
		flex-direction: column;
		margin-left: 20rpx;
	}

	.orderdeliver .logistics .information .infoimg img {
		width: 100%;
		height: 100%;
	}

	.orderdeliver .logistics .information .infoimg {
		width: 34rpx;
		height: 34rpx;
	}

	.orderdeliver .logistics .information {
		display: flex;
		margin: 40rpx 0;
	}

	.orderdeliver .logistics .logs .logtxt {
		flex: 1;
		margin-left: 20rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .logistics .logs div:last-child img {
		width: 100%;
		height: 100%;
		margin: auto 0;
	}

	.orderdeliver .logistics .logs div:last-child {
		width: 28rpx;
		height: 34rpx;
		margin: auto 0;
		display: flex;
	}

	.orderdeliver .logistics .logs div:first-child img {
		width: 100%;
		height: 100%;
		margin: auto 0;
	}

	.orderdeliver .logistics .logs div:first-child {
		width: 37rpx;
		height: 34rpx;
		margin: auto 0;
		display: flex;
	}

	.orderdeliver .logistics .logs {
		display: flex;
		justify-content: space-between;
	}

	.orderdeliver .logistics {
		width: 664rpx;
		/* height: 262rpx; */
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		padding: 50rpx 25rpx;
	}

	.orderdeliver {
		height: 100%;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}
</style>
