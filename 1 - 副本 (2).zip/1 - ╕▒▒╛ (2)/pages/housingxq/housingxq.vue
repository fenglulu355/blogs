<template>
	<view class="housingpage">
		<Navigation></Navigation>
		<view class="housing">
			<!-- 弹窗模式(无界面) -->
			<calendar @change="change2" :modal="true" :show="showCaledar"></calendar>
			<view class="housinglb">
				<swiper class="swiper" autoplay="true" interval="3000" duration="300" circular @change="setchange">
					<swiper-item v-for="item in 5">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</swiper-item>
				</swiper>
				<view class="indicator">
					{{currentid}}/5
				</view>
			</view>
			<view class="housingname">
				<view class="housingnametop">
					<div>高级温馨大床房</div>
					<div>月售55</div>
				</view>
				<view class="housingnamebottom">
					<view class="housingnameleft">￥<span>129</span></view>
					<view class="housingnameright">
						<div>
							<Iconfonts name="icon-fenxiang" size="37rpx" colors="#dddddd" />
							<p>分享</p>
						</div>
						<div>
							<Iconfonts name="icon-xingxing" size="37rpx" colors="#dddddd" />
							<p>收藏</p>
						</div>
					</view>
				</view>
				<view class="housingnamelabol">
					<div>上网 <span> WiFi</span></div>
					<div>上网 <span> WiFi</span></div>
					<div>上网 <span> WiFi</span></div>
					<div>上网 <span> WiFi</span></div>
					<div>上网 <span> WiFi</span></div>
					<div>上网 <span> WiFi</span></div>
				</view>
			</view>
			<view class="housingshop">
				<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				<view class="housingshopright">
					<view class="housingshopone">
						<div>成都锦江之星店</div>
						<div>订</div>
					</view>
					<view class="housingshoptow">
						<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
						<div>营业时间 6:00-20:30</div>
					</view>
					<view class="housingshoptow">
						<Iconfonts name="icon-dizhi" size="25rpx" colors="#f0cf26" />
						<div>人民南路北段4号</div>
						<p>{{you}}50m</p>
					</view>
				</view>
			</view>
			<view class="housingExplain">
				<view class="housingrule" v-for="item in 3">
					<view class="housingruletitle">
						退款规则
					</view>
					<view class="housingruletxt">
						<view class="housingruletxtli">
							<div></div>
							<div>限时取消  入住日当天18点前可免费取消，逾期不可取消/变更，如未入住，酒店将扣除全额房费</div>
						</view>
						<view class="housingruletxtli">
							<div></div>
							<div>限时取消  入住日当天18点前可免费取消，逾期不可取消/变更，如未入住，酒店将扣除全额房费</div>
						</view>
						<view class="housingruletxtli">
							<div></div>
							<div>限时取消  入住日当天18点前可免费取消，逾期不可取消/变更，如未入住，酒店将扣除全额房费</div>
						</view>
					</view>
				</view>
			</view>
			<view class="Reserve">
				<div>￥<span>129</span></div>
				<div @tap="showCaledar = !showCaledar">预订房间</div>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import calendar from '../../components/date-picker/date-picker.vue'
	export default {
		data() {
			return {
				currentid: 1,
				you: '<',
				showCaledar: true,
				dateStr: ''
			}
		},
		methods: {
			setchange: function(e) {
				this.currentid = e.detail.current + 1
				// console.log(e.detail.current)
			},
			change2({
				choiceDate,
				dayCount
			}) {
				getApp().globalData.startime = choiceDate[0];
				getApp().globalData.endtime = choiceDate[1];
				getApp().globalData.day = dayCount;
				// uni.navigateTo({
				// 	url: '../housingorder/housingorder'
				// });
				if(this.dateStr){
					uni.navigateTo({
						url: '../housingorder/housingorder'
					});
				}else{
					
				}
				console.log(this.dateStr);
				// console.log(choiceDate[0]);
				this.dateStr = '入住从 ' + choiceDate[0].re + ' (星期' + choiceDate[0].week + ')  到 ' + choiceDate[1].re + '(星期' +
					choiceDate[1].week + ')' + '  共 ' + dayCount + ' 晚 ';
			}
		},
		components: {
			Navigation,
			Iconfonts,
			calendar
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.Reserve div:first-child span {
		font-size: 32rpx;
	}

	.Reserve div:last-child {
		text-align: center;
		line-height: 100rpx;
		background-color: #23c88c;
		color: #ffffff;
		font-size: 32rpx;
		flex: 1;
	}

	.Reserve div:first-child {
		color: #ff643a;
		font-size: 22rpx;
		width: 50%;
		background-color: #fff;
		text-align: center;
		line-height: 100rpx;
	}

	.Reserve {
		width: 100%;
		height: 100rpx;
		position: fixed;
		bottom: 0;
		display: flex;
	}

	.housing .housingExplain .housingrule .housingruletxt .housingruletxtli div:last-child {
		color: #222222;
		font-size: 24rpx;
	}

	.housing .housingExplain .housingrule .housingruletxt .housingruletxtli div:first-child {
		width: 10rpx;
		height: 10rpx;
		border-radius: 50%;
		background-color: #000000;
		margin: auto 0;
		margin-right: 15rpx;
		flex-shrink: 0;
	}

	.housing .housingExplain .housingrule .housingruletxt .housingruletxtli {
		margin: 25rpx 0;
		display: flex;
	}

	.housing .housingExplain .housingrule .housingruletitle {
		height: 50rpx;
		line-height: 50rpx;
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
	}

	.housing .housingExplain .housingrule:last-child {
		border: none;
	}

	.housing .housingExplain .housingrule {
		border-bottom: 1rpx solid #f2f2f2;
	}

	.housing .housingExplain {
		background-color: #fff;
		padding: 15rpx 18rpx;
		margin-bottom: 120rpx;
	}

	.housing .housingshop .housingshopright .housingshoptow p {
		margin: auto 0;
		color: #666666;
		font-size: 24rpx;
	}

	.housing .housingshop .housingshopright .housingshoptow div {
		flex: 1;
		color: #666666;
		font-size: 24rpx;
		margin: auto 0;
	}

	.housing .housingshop .housingshopright .housingshoptow Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 12rpx;
	}

	.housing .housingshop .housingshopright .housingshoptow {
		display: flex;
		justify-content: space-between;
		margin-top: 20rpx;
	}

	.housing .housingshop .housingshopright .housingshopone div:last-child {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #23c88c;
		text-align: center;
		line-height: 34rpx;
		color: #23c88c;
		font-size: 24rpx;
	}

	.housing .housingshop .housingshopright .housingshopone div:first-child {
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
	}

	.housing .housingshop .housingshopright .housingshopone {
		display: flex;
		justify-content: space-between;
	}

	.housing .housingshop .housingshopright {
		margin-left: 20rpx;
		flex: 1;
	}

	.housing .housingshop image {
		width: 100rpx;
		height: 100rpx;
		background-color: #dcdcdc;
		border-radius: 5rpx;
	}

	.housing .housingshop {
		margin: 18rpx 0;
		padding: 30rpx 18rpx;
		background-color: #fff;
		display: flex;
	}

	.housing .housingname .housingnamelabol div span {
		color: #222222;
		margin-left: 15rpx;
	}

	.housing .housingname .housingnamelabol div {
		width: 50%;
		color: #999999;
		font-size: 24rpx;
		margin-top: 20rpx;
	}

	.housing .housingname .housingnamelabol {
		display: flex;
		flex-wrap: wrap;
	}

	.housing .housingname .housingnamebottom .housingnameright div p {
		text-align: center;
		color: #666666;
		font-size: 22rpx;
		margin-top: 15rpx;
	}

	.housing .housingname .housingnamebottom .housingnameright div Iconfonts {
		margin: 0 auto;
		display: flex;
		justify-content: center;
	}

	.housing .housingname .housingnamebottom .housingnameright div {
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		margin-left: 40rpx;
	}

	.housing .housingname .housingnamebottom .housingnameright {
		display: flex;
	}

	.housing .housingname .housingnamebottom .housingnameleft span {
		font-size: 32rpx;
	}

	.housing .housingname .housingnamebottom .housingnameleft {
		color: #ff643a;
		font-size: 22rpx;
		font-weight: bold;
	}

	.housing .housingname .housingnamebottom {
		display: flex;
		justify-content: space-between;
		align-items: flex-end;
		margin-bottom: 20rpx;
	}

	.housing .housingname .housingnametop div:last-child {
		color: #999999;
		font-size: 22rpx;
	}

	.housing .housingname .housingnametop div:first-child {
		color: #222222;
		font-size: 32rpx;
		font-weight: bold;
	}

	.housing .housingname {
		/* height: 142rpx; */
		padding: 20rpx 18rpx;
		background-color: #fff;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.housingpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.housing .housinglb .indicator {
		position: absolute;
		width: 80rpx;
		height: 50rpx;
		background-color: #000000;
		border-radius: 25rpx;
		opacity: 0.4;
		bottom: 18rpx;
		right: 18rpx;
		color: #eeeeee;
		font-size: 24rpx;
		text-align: center;
		line-height: 50rpx;
	}

	.housing .housinglb .swiper image {
		width: 100%;
	}

	.housing .housinglb .swiper {
		width: 100%;
		height: 100%;
	}

	.housing .housinglb {
		height: 500rpx;
		position: relative;
	}

	.housing {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
	}
</style>
