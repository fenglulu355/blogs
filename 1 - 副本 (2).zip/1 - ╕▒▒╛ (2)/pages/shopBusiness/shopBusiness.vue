<template>
	<view class="businesspage">
		<Navigation></Navigation>
		<view class="business">
			<view class="towli" v-for="item in 10" @click="aecondxq">
				<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				<view class="towlibottom">
					<view class="towliones">
						<view class="towlionesa">
							西洋风情茶水杯
						</view>
						<view class="towlionesb">
							<div>￥ <span>99</span></div>
							<div>全新未使用</div>
						</view>
					</view>
					<view class="towliname">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<div>
							<p>你丑你先走</p>
							<p>当前在线</p>
						</div>
					</view>
				</view>
			</view>
		</view>
		<view class="sell">
			我要卖宝贝
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		components: {
			Iconfonts,
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.sell {
		position: fixed;
		width: 400rpx;
		height: 88rpx;
		background-color: #3c9cff;
		box-shadow: 0rpx 10rpx 20rpx 0rpx rgba(3, 67, 134, 0.5);
		border-radius: 44rpx;
		left: 0;
		right: 0;
		margin: 0 auto;
		bottom: 20rpx;
		text-align: center;
		line-height: 88rpx;
		color: #ffffff;
		font-size: 32rpx;
		font-weight: bold;
	}

	.towli .towlibottom .towliname div p:last-child {
		color: #999999;
		font-size: 18rpx;
	}

	.towli .towlibottom .towliname div p:first-child {
		color: #222222;
		font-size: 22rpx;
	}

	.towli .towlibottom .towliname div {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.towli .towlibottom .towliname image {
		width: 50rpx;
		height: 50rpx;
		border-radius: 50%;
		margin-right: 12rpx;
	}

	.towli .towlibottom .towliname {
		padding: 20rpx 0;
		display: flex;
	}

	.towli .towlibottom .towliones .towlionesb div:last-child {
		width: 105rpx;
		height: 30rpx;
		background-color: #eaf3fd;
		text-align: center;
		line-height: 30rpx;
		color: #3c9cff;
		font-size: 18rpx;
		margin: auto 0;
	}

	.towli .towlibottom .towliones .towlionesb div:first-child span {
		color: #3c9cff;
		font-size: 28rpx;
	}

	.towli .towlibottom .towliones .towlionesb div:first-child {
		color: #3c9cff;
		font-size: 24rpx;
		margin: auto 0;
		font-weight: bold;
	}

	.towli .towlibottom .towliones .towlionesb {
		display: flex;
		justify-content: space-between;
	}

	.towli .towlibottom .towliones .towlionesa {
		color: #222222;
		font-size: 28rpx;
		margin-bottom: 25rpx;
	}

	.towli .towlibottom .towliones {
		padding: 20rpx 0;
		border-bottom: 1rpx solid #f2f2f2;
	}

	.towli .towlibottom {
		display: flex;
		flex-direction: column;
		padding: 0 20rpx;
	}

	.towli image {
		width: 348rpx;
		height: 348rpx;
		background-color: #3c9cff;
		border-radius: 10rpx 10rpx 0rpx 0rpx;
	}

	.towli {
		/* width: 325rpx; */
		/* height: 560rpx; */
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 15rpx;
	}

	.business {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
		display: flex;
		flex-wrap: wrap;
		padding: 15rpx 0;
	}

	.businesspage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
