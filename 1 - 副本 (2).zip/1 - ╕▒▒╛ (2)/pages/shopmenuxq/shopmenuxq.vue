<template>
	<view class="shopmenuxqpage">
		<Navigation></Navigation>
		<view class="shopmenuxq">
			<view class="shopmebulb">
				<swiper class="swiper" autoplay="true" interval="3000" duration="300" circular @change="setchanges">
					<swiper-item v-for="item in 5">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</swiper-item>
				</swiper>
				<div>{{current}}/5</div>
			</view>
			<view class="shoptitle">
				<view class="title">
					<div>酸辣土豆丝</div>
					<div>月售55</div>
				</view>
				<view class="titlebottom">
					<view class="titleleft">
						￥<span>10.6</span>
					</view>
					<view class="titleright">
						<div>
							<Iconfonts name="icon-fenxiang" size="35rpx" colors="#dddddd" />
							<p>分享</p>
						</div>
						<div>
							<Iconfonts name="icon-xingxing" size="35rpx" colors="#dddddd" />
							<p>收藏</p>
						</div>
					</view>
				</view>
			</view>
			<view class="shops">
				<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				<view class="shopleft">
					<view class="shopleftone">
						<view class="shopleftitle">
							嘎嘎鸭(科华店)
						</view>
						<view class="shoplabol">
							<div>订</div>
							<div>买</div>
						</view>
					</view>
					<view class="shopleftow">
						<Iconfonts name="icon-canju" size="25rpx" colors="#f0cf26" />
						<div>人均￥75   川菜</div>
					</view>
					<view class="shopleftow">
						<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
						<div>营业时间 6:00-20:30</div>
					</view>
					<view class="shoplefthree">
						<Iconfonts name="icon-dizhi" size="25rpx" colors="#f0cf26" />
						<div>人民南路北段4号</div>
						<p>{{xiaoyu}}50m</p>
					</view>
				</view>
			</view>
			<view class="BestSellers">
				<view class="bestitle">
					本店热卖
				</view>
				<view class="besli">
					<view class="beslis" v-for="item in 10">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<div>休闲卤味风味鸭...</div>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				current:1,
				xiaoyu:'<'
			}
		},
		methods: {
			setchanges:function(e){
				this.current = e.detail.current+1
			}
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.shopmenuxq .BestSellers .besli .beslis div{
	color: #222222;
	font-size: 24rpx;
	overflow: hidden;
	text-overflow:ellipsis;
	white-space: nowrap;
	width: 100%;
	margin: 10rpx 0;
}
.shopmenuxq .BestSellers .besli .beslis image{
	width: 200rpx;
	height: 200rpx;
	border-radius: 5rpx;
}
.shopmenuxq .BestSellers .besli .beslis:last-child{
	margin: 0;
}
.shopmenuxq .BestSellers .besli .beslis{
	margin-right: 20rpx;
}
.shopmenuxq .BestSellers .besli{
	display: flex;
	overflow: auto;
	margin-bottom: 30rpx;
}
.shopmenuxq .BestSellers .bestitle{
	height: 84rpx;
	line-height: 84rpx;
	color: #222222;
	font-size: 28rpx;
	font-weight: bold;
}
.shopmenuxq .BestSellers{
	padding: 0 18rpx;
	background-color: #fff;
}
.shopmenuxq .shops .shopleft .shoplefthree Iconfonts{
	margin: auto 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
	margin-right: 12rpx;
}
.shopmenuxq .shops .shopleft .shoplefthree p{
	margin: auto 0;
	color: #666666;
	font-size: 24rpx;
}
.shopmenuxq .shops .shopleft .shoplefthree div{
	flex: 1;
	margin: auto 0;
	color: #666666;
	font-size: 24rpx;
}
.shopmenuxq .shops .shopleft .shoplefthree{
	display: flex;
	justify-content: space-between;
}
.shopmenuxq .shops .shopleft .shopleftow div{
	margin: auto 0;
	color: #666666;
	font-size: 24rpx;
}
.shopmenuxq .shops .shopleft .shopleftow Iconfonts{
	margin: auto 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
	margin-right: 12rpx;
}
.shopmenuxq .shops .shopleft .shopleftow{
	display: flex;
	margin-bottom: 15rpx;
}
.shopmenuxq .shops .shopleft .shopleftone .shopleftitle{
	color: #222222;
	font-size: 28rpx;
	font-weight: bold;
}
.shopmenuxq .shops .shopleft .shopleftone .shoplabol div{
	width: 34rpx;
	height: 34rpx;
	border-radius: 3rpx;
	border: solid 1rpx #23c88c;
	color: #23c88c;
	font-size: 24rpx;
	text-align: center;
	line-height: 34rpx;
	margin-right: 5rpx;
}
.shopmenuxq .shops .shopleft .shopleftone .shoplabol{
	display: flex;
}
.shopmenuxq .shops .shopleft .shopleftone{
	display: flex;
	justify-content: space-between;
	margin-bottom: 15rpx;
}
.shopmenuxq .shops .shopleft{
	flex: 1;
}
.shopmenuxq .shops image{
	width: 100rpx;
	height: 100rpx;
	background-color: #dcdcdc;
	border-radius: 5rpx;
	margin-right: 20rpx;
}
.shopmenuxq .shops{
	margin: 18rpx 0;
	background-color: #fff;
	padding: 30rpx 18rpx;
	display: flex;
}
.shopmenuxq .shoptitle .titlebottom .titleright div p{
	text-align: center;
	color: #666666;
	font-size: 22rpx;
}
.shopmenuxq .shoptitle .titlebottom .titleright div Iconfonts{
	margin: 0 auto;
	display: flex;
	justify-content: center;
	margin-bottom: 5rpx;
}
.shopmenuxq .shoptitle .titlebottom .titleright div{
	display: flex;
	flex-direction: column;
	justify-content: flex-end;
	margin-right: 40rpx;
}
.shopmenuxq .shoptitle .titlebottom .titleright{
	display: flex;
}
.shopmenuxq .shoptitle .titlebottom .titleleft span{
	font-size: 32rpx;
}
.shopmenuxq .shoptitle .titlebottom .titleleft{
	color: #ff643a;
	font-size: 22rpx;
}
.shopmenuxq .shoptitle .titlebottom{
	display: flex;
	justify-content: space-between;
	align-items: flex-end;
}
.shopmenuxq .shoptitle .title div:last-child{
	color: #999999;
	font-size: 22rpx;
}
.shopmenuxq .shoptitle .title div:first-child{
	color: #222222;
	font-size: 32rpx;
	font-weight: bold;
}
.shopmenuxq .shoptitle{
	background-color: #ffffff;
	padding: 25rpx 18rpx;
}
.shopmenuxq .shopmebulb div{
	width: 80rpx;
	height: 50rpx;
	background-color: rgba(0,0,0,0.5);
	border-radius: 25rpx;
	position: absolute;
	bottom: 18rpx;
	right: 18rpx;
	text-align: center;
	line-height: 50rpx;
	color: #eeeeee;
	font-size: 24rpx;
}
.shopmenuxq .shopmebulb .swiper image{
	width: 100%;
}
.shopmenuxq .shopmebulb .swiper{
	height: 100%;
	width: 100%;
}
.shopmenuxq .shopmebulb{
	height: 506rpx;
	width: 100%;
	position: relative;
}
.shopmenuxqpage{
	height: 100%;
	display: flex;
	flex-direction: column;
}
.shopmenuxq{
	flex: 1;
	background-color: #f8f8f8;
	overflow: auto;
}
</style>
