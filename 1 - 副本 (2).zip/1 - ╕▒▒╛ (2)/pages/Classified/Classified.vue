<template>
	<view class='classified'>
		<div class='classifleft'>
			<div class='classleftli' v-for="(item,index) in oneclass" :style="item.sty" @click="changesty(index)">{{item.name}}</div>
		</div>
		<div class='classifright'>
			<div v-for="item in 5" :key="item" class='classdiv'>
				11
				<div class='yuan'>-</div>
			</div>
			<div class='classdiv' style="color: #999999;">+</div>
		</div>
		<div class='Reset'>
			<div>重置</div>
			<div>保存</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				oneclass: []
			}
		},
		methods: {
			changesty: function(e) {
				let arr1 = this.oneclass;
				for (let i in arr1) {
					arr1[i].sty = 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4'
				}
				arr1[e].sty = 'border-left:2rpx solid #f5bc32;background-color:#fff';
				this.oneclass = arr1;
			}
		},
		onLoad: function(option) {
			console.log(option.classid); //打印出上个页面传递的参数。
			let arr = getApp().globalData.oneclass;
			for (let i in arr) {
				arr[i].sty = 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4'
			}
			arr[option.classid].sty = 'border-left:2rpx solid #f5bc32;background-color:#fff'
			this.oneclass = arr;
			// getApp().globalData.oneclass = 'test'//赋值
			// console.log(getApp().globalData.oneclass) // 'test'取值
		},
	}
</script>

<style>
	page {
		height: 100%;
		background-color: #f8f8f8;
	}

	.classified .Reset div:last-child {
		background-color: #f5bc32;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.classified .Reset div:first-child {
		background-color: #222222;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.classified .Reset div {
		width: 50%;
		line-height: 100rpx;
		text-align: center;
	}

	.classified .Reset {
		width: 530rpx;
		height: 100rpx;
		position: fixed;
		bottom: 0;
		right: 0;
		display: flex;
	}

	.classified .classifright .classdiv .yuan {
		width: 28rpx;
		height: 28rpx;
		background-color: #ff643a;
		position: absolute;
		right: -10rpx;
		top: -10rpx;
		border-radius: 50%;
		color: #fff;
		text-align: center;
		line-height: 24rpx;
		font-size: 24rpx;
		font-weight: bold;
	}

	.classified .classifright .classdiv {
		position: relative;
		width: 210rpx;
		height: 60rpx;
		background-color: #ffffff;
		border-radius: 5rpx;
		float: left;
		margin: 10rpx;
		flex-shrink: 0;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 20rpx;
		letter-spacing: 0rpx;
		color: #222222;
		text-align: center;
		line-height: 60rpx;
	}

	.classified .classifright {
		flex: 1;
		padding: 30rpx;
		margin-left: 220rpx;
		/* display: flex;
		flex-wrap: wrap; */
	}

	.classified .classifleft .classleftli {
		height: 100rpx;
		border-bottom: 1rpx solid #fff;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 2rpx;
		color: #222222;
		line-height: 100rpx;
		text-align: center;
	}

	.classified .classifleft {
		width: 220rpx;
		height: 100%;
		background-color: #f4f4f4;
		position: fixed;
		left: 0;
	}

	.classified {
		height: 100%;
		display: flex;
	}
</style>
