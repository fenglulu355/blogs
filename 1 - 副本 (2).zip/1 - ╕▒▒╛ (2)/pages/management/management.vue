<template>
	<view class='management'>
		<div class='manages' v-for="(item,index) in oneclass" :key="index">
			<div class='managetop'>
				<div><view>类型名称：</view><span v-if="item.isinp">{{item.name}}</span><input v-else type="text" :placeholder="item.name" @blur="isinput(index)" v-model="item.name"></div>
				<div>{{item.time}}</div>
			</div>
			<div class='managebottom'>
				<div @click="classif(index)"><image mode="widthFix" src="../../static/images/saoma.png"></image><span>查看下级</span></div>
				<div @click='isinput(index)'><image mode="widthFix" src="../../static/images/bj.png"></image><span>编辑名称</span></div>
			</div>
		</div>
		<div style='height: 100rpx;'></div>
		<div class='addclass'>添加一级分类</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				oneclass:[],
				
			}
		},
		onShow:function(){
			this.oneclass = getApp().globalData.oneclass;
			// getApp().globalData.oneclass = 'test'//赋值
			// console.log(getApp().globalData.oneclass) // 'test'取值
		},
		methods: {
			classif:function(e){
				uni.navigateTo({
					url: `../Classified/Classified?classid=${e}`
				});
			},
			isinput:function(e){
				this.oneclass[e].isinp = !this.oneclass[e].isinp
			}
		}
	}
</script>

<style>
page{
	height: 100%;
	background-color: #f8f8f8;
}

.management .addclass{
	width:100%;
	height: 100rpx;
	background-color: #f5bc32;
	position: fixed;
	bottom: 0;
	text-align: center;
	line-height: 100rpx;
	font-family: PingFang-SC-Medium;
	font-size: 32rpx;
	font-weight: bold;
	font-stretch: normal;
	letter-spacing: 0rpx;
	color: #222222;
}
.management .manages .managebottom div:first-child{
	border-right: 1rpx solid #f2f2f2;
}
.management .manages .managebottom div span{
	font-family: PingFang-SC-Regular;
	font-size: 24rpx;
	font-weight: normal;
	font-stretch: normal;
	letter-spacing: 0rpx;
	color: #222222;
	margin: auto 0;
}
.management .manages .managebottom div image{
	width: 25rpx;
	margin: auto 0;
	margin-right: 12rpx;
}
.management .manages .managebottom div{
	width: 50%;
	display: flex;
	justify-content: center;
}
.management .manages .managebottom{
	display: flex;
	height: 64rpx;
}
.management .manages .managetop div:last-child{
	font-family: PingFang-SC-Regular;
	font-size: 24rpx;
	font-weight: normal;
	font-stretch: normal;
	letter-spacing: 0rpx;
	color: #999999;
	margin: auto 0;
}
.management .manages .managetop div:first-child span{
	line-height: 98rpx;
}
.management .manages .managetop div:first-child input{
	margin: auto 0;
}
.management .manages .managetop div:first-child view{
	line-height: 98rpx;
}
.management .manages .managetop div:first-child{
	font-family: PingFang-SC-Medium;
	font-size: 28rpx;
	font-weight: normal;
	font-stretch: normal;
	line-height: 30rpx;
	letter-spacing: 0rpx;
	color: #222222;
	margin: auto 0;
	display: flex;
}
.management .manages .managetop{
	border-bottom: 1rpx solid #f2f2f2;
	height: 98rpx;
	display: flex;
	justify-content: space-between;
}
.management .manages{
	width: 670rpx;
	background-color: #ffffff;
	border-radius: 10rpx;
	margin: 0 auto;
	margin-top:20rpx;
	padding:0 22rpx;
}
.management{
	display: flex;
	flex-direction: column;
}
</style>
