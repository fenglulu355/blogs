<template>
	<view class="orderstate">
		<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
		<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
			<swiper-item id="1">
				<div class='Tobeshipped'>
					<div class='oneorder' v-for="item in 3" :key="item">
						<div class='one'>
							<div class='onetitle'>
								<div>订单号:2134323533</div>
								<div @click="Deliver">发货</div>
							</div>
							<div class='ImageText'>
								<div class='oneimage'>
									<img src="../../static/images/orders.jpg" alt="">
								</div>
								<div class='onetxt'>
									<div class='ordetitle'>
										<div>休闲卤味风味鸭头</div>
										<div>规格：1份</div>
									</div>
									<div class="orderPrice">
										<div>￥9.90</div>
										<div>x1</div>
									</div>
								</div>
							</div>
							<div class='Receiving'>
								<div>收货人信息</div>
								<div>杨YY 156 6666 6666</div>
								<div>四川省成都市武侯区人民南路北段新希望大厦7楼704室</div>
							</div>
						</div>
						<div class='tow'>
							买家留言：<span>无</span>
						</div>
						<div class='three'>共1件商品(含运费) 合计:<span>￥9.90</span></div>
					</div>
				</div>
			</swiper-item>
			<swiper-item id="2">
				<div class='Tobeshipped'>
					<div class='oneorder' v-for="item in 3" :key="item">
						<div class='one'>
							<div class='onetitle'>
								<div>订单号:2134323533</div>
								<div style='background-color: #fff;color: #ff683a;'>已发货</div>
							</div>
							<div class='ImageText'>
								<div class='oneimage'>
									<img src="../../static/images/orders.jpg" alt="">
								</div>
								<div class='onetxt'>
									<div class='ordetitle'>
										<div>休闲卤味风味鸭头</div>
										<div>规格：1份</div>
									</div>
									<div class="orderPrice">
										<div>￥9.90</div>
										<div>x1</div>
									</div>
								</div>
							</div>
							<div class='Receiving'>
								<div>收货人信息</div>
								<div>杨YY 156 6666 6666</div>
								<div>四川省成都市武侯区人民南路北段新希望大厦7楼704室</div>
							</div>
						</div>
						<div class='tow'>
							买家留言：<span>无</span>
						</div>
						<div class='three'>
							<div>共1件商品(含运费) 合计:<span>￥9.90</span></div>
							<div>查看物流</div>
						</div>
					</div>
				</div>
			</swiper-item>
			<swiper-item id="3">
				<div class='Tobeshipped'>
					<div class='oneorder' v-for="item in 3" :key="item">
						<div class='one'>
							<div class='onetitle'>
								<div>订单号:2134323533</div>
								<div style='background-color: #fff;color: #ff683a;'>已完成</div>
							</div>
							<div class='ImageText'>
								<div class='oneimage'>
									<img src="../../static/images/orders.jpg" alt="">
								</div>
								<div class='onetxt'>
									<div class='ordetitle'>
										<div>休闲卤味风味鸭头</div>
										<div>规格：1份</div>
									</div>
									<div class="orderPrice">
										<div>￥9.90</div>
										<div>x1</div>
									</div>
								</div>
							</div>
							<div class='Receiving'>
								<div>收货人信息</div>
								<div>杨YY 156 6666 6666</div>
								<div>四川省成都市武侯区人民南路北段新希望大厦7楼704室</div>
							</div>
						</div>
						<div class='tow'>
							买家留言：<span>无</span>
						</div>
						<div class='three'>共1件商品(含运费) 合计:<span>￥9.90</span></div>
					</div>
				</div>
			</swiper-item>
			<swiper-item id="4">
				<div class='Tobeshipped'>
					<div class='oneorder' v-for="item in 3" :key="item">
						<div class='one'>
							<div class='onetitle'>
								<div>订单号:2134323533</div>
								<div style='background-color: #fff;color: #ff683a;'>用户申请中...</div>
							</div>
							<div class='ImageText'>
								<div class='oneimage'>
									<img src="../../static/images/orders.jpg" alt="">
								</div>
								<div class='onetxt'>
									<div class='ordetitle'>
										<div>休闲卤味风味鸭头</div>
										<div>规格：1份</div>
									</div>
									<div class="orderPrice">
										<div>￥9.90</div>
										<div>x1</div>
									</div>
								</div>
							</div>
							<div class='Receiving'>
								<div>收货人信息</div>
								<div>杨YY 156 6666 6666</div>
								<div>四川省成都市武侯区人民南路北段新希望大厦7楼704室</div>
							</div>
						</div>
						<div class='tow'>
							买家留言：<span>无</span>
						</div>
						<div class='three'>
							<div>共1件商品(含运费) 合计:<span>￥9.90</span></div>
							<div>确认退(换)货</div>
						</div>
					</div>
				</div>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	export default {
		data() {
			return {
				TabCur: 0,
				tabList: [{
					name: '待发货'
				}, {
					name: '已发货'
				}, {
					name: '已完成'
				}, {
					name: '退换货'
				}],
			}
		},
		components: {
			WucTab
		},
		methods: {
			tabChange(index) {
				this.TabCur = index;
			},
			swiperChange(e) {
				this.tabChange(e.detail.current)
			},
			Deliver: function() {
				uni.navigateTo({
					url: '../orderDeliver/orderDeliver'
				});
			}
		},
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
			console.log(option);
			// console.log(this.Deliverid);
		}
	}
</script>

<style>
	.oneorder .three span {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: normal;
		letter-spacing: 0rpx;
		color: #ff683a;
	}

	.oneorder .three div:last-child {
		/* width: 150rpx; */
		padding: 0 20rpx;
		height: 50rpx;
		background-color: #ff643a;
		border-radius: 25rpx;
		text-align: center;
		line-height: 50rpx;
		margin: auto 0;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.oneorder .three {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		line-height: 96rpx;
		display: flex;
		justify-content: space-between;
	}

	.oneorder .tow span {
		color: #f5bc32;
	}

	.oneorder .tow {
		border-bottom: 1rpx solid #f2f2f2;
		line-height: 96rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.oneorder .one .Receiving div:last-child {
		color: #666666;
	}

	.oneorder .one .Receiving div {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.oneorder .one .Receiving {
		margin: 35rpx 0;
	}

	.oneorder .one .ImageText .onetxt .orderPrice div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.oneorder .one .ImageText .onetxt .orderPrice div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff683a;
	}

	.oneorder .one .ImageText .onetxt .orderPrice {
		display: flex;
		justify-content: space-between;
	}

	.oneorder .one .ImageText .onetxt .ordetitle div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.oneorder .one .ImageText .onetxt .ordetitle div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.oneorder .one .ImageText .onetxt {
		flex: 1;
		margin-left: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.oneorder .one .ImageText .oneimage img {
		width: 100%;
		height: 100%;
	}

	.oneorder .one .ImageText .oneimage {
		width: 160rpx;
		height: 160rpx;
		background-color: #222222;
		border-radius: 5rpx;
		overflow: hidden;
	}

	.oneorder .one .ImageText {
		display: flex;
	}

	/* body .oneorder .one .onetitle .Delivergoods{
		background-color: #fff;
		color: #ff683a;
	} */

	.oneorder .one .onetitle div:first-child {
		line-height: 70rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.oneorder .one .onetitle div:last-child {
		/* width: 100rpx; */
		padding: 0 20rpx;
		height: 44rpx;
		background-color: #ff683a;
		border-radius: 22rpx;
		color: #fff;
		text-align: center;
		line-height: 44rpx;
		margin: auto 0;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
	}

	.oneorder .one .onetitle {
		display: flex;
		justify-content: space-between;
	}

	.oneorder .one {
		border-bottom: 1rpx solid #f2f2f2;
	}

	.Tobeshipped {
		display: flex;
		height: 100%;
		flex-direction: column;
		overflow: auto;
	}

	.oneorder {
		margin: 0 auto;
		margin-top: 20rpx;
		width: 674rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		padding: 5rpx 20rpx;
	}

	.orderstate {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100%;
	}

	.swip {
		height: 100%;
		background-color: #f8f8f8;
	}
</style>
