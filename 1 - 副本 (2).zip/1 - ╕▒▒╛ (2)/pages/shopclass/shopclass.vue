<template>
	<view class="shopclass">
		<view class="shopclassli">
			<view class="shopsearch">
				<view class="shopinp">
					<Iconfonts name="icon-sousuo" size="25rpx" colors="#9a9a9a" />
					<input type="text" value="" placeholder="吃喝玩乐随便找" />
				</view>
				<view class="quxiao">
					取消
				</view>
			</view>
			<view class="shopxia">
				<view class="shoptype" v-for="item in allclass">
					<view class="shopstitle">
						<view class="shopeat" :style="'background-color:'+item.color">{{item.name}}</view>
						<view class="shopall">全部 {{right}}</view>
					</view>
					<view class="shopdetail">
						<div v-for="items in item.child">{{items.name}}</div>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				right: '>',
				Modularsli:[],
				bashurl:'',
				shoptype: [{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					},
					{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					},
					{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					},
					{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					},
					{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					},
					{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					},
					{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					},
					{
						title: '吃',
						type: [{
							title: '办公用品'
						}]
					}
				]
			}
		},
		created:function(){
			// this.bashurl = getApp().globalData.bashurl;
			// this.getindexlabol();
			this.getallclass();
		},
		computed: {
			...mapState(['allclass'])
		},
		methods: {
			...mapActions(['getallclass']),
			// getindexlabol:function(){
			// 	let arr = this.Modularsli;
			// 	let colorarr = ['#ff683a','#3c9cff','#ffbf00','#23c88c','#fb683a','#f85b71']
			// 	uni.request({
			// 		url: `${this.bashurl}/index/api/index`, //仅为示例，并非真实接口地址。
			// 		success: (res) => {
			// 			// console.log(res.data.data);
			// 			for(let i in res.data.data){
			// 				res.data.data[i].color = colorarr[i]
			// 				arr.push(res.data.data[i]);
			// 			}
			// 			// console.log(arr);
			// 		}
			// 	});
			// 	console.log(this.Modularsli);
			// },
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	.shopclassli .shopsearch .quxiao{
		margin: auto 0;
		color: #222222;
		font-size: 28rpx;
		margin-right: 15rpx;
	}
	.shopclassli .shopsearch .shopinp input{
		color: #999999;
		font-size: 24rpx;
		margin: auto 0;
		margin-left: 10rpx;
	}
	.shopclassli .shopsearch .shopinp{
		display: flex;
		width: 560rpx;
		height: 60rpx;
		background-color: #efefef;
		border-radius: 30rpx;
		padding: 0 30rpx;
		margin: auto 0;
	}
	.shopclassli .shopsearch{
		height: 85rpx;
		background-color: #fff;
		padding: 0 18rpx;
		display: flex;
		justify-content: space-between;
	}
	.shopclassli .shopxia{
		flex: 1;
		overflow: auto;
		padding: 18rpx;
	}
	.shopclassli .shoptype .shopdetail div {
		text-align: center;
		width: 178rpx;
		height: 70rpx;
		line-height: 70rpx;
		background-color: #ffffff;
		color: #222222;
		font-size: 28rpx;
		margin-right: 1rpx;
		margin-bottom: 1rpx;
	}

	.shopclassli .shoptype .shopdetail {
		display: flex;
		flex-wrap: wrap;
	}

	.shopclassli .shoptype .shopstitle .shopall {
		color: #cccccc;
		font-size: 24rpx;
		line-height: 80rpx;
	}

	.shopclassli .shoptype .shopstitle .shopeat {
		width: 80rpx;
		height: 80rpx;
		background-color: #ff683a;
		border-radius: 0rpx 0rpx 20rpx 0rpx;
		text-align: center;
		line-height: 80rpx;
		color: #ffffff;
		font-size: 36rpx;
	}

	.shopclassli .shoptype .shopstitle {
		height: 80rpx;
		background-color: #ffffff;
		display: flex;
		justify-content: space-between;
		padding-right: 30rpx;
		margin-bottom: 1rpx;
	}

	.shopclassli .shoptype {
		margin-bottom: 18rpx;
	}

	.shopclassli {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100vh;
	}

	.shopclass {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
