<template>
	<view class="secondpage">
		<Navigation></Navigation>
		<view class="second">
			<view class="secondcontent">
				<swiper class="swiper" :duration="duration" :current="itemid" @change="scroll" duration="300">
					<swiper-item id='1' catchtouchmove='catchTouchMove'>
						<allseconds></allseconds>
					</swiper-item>
					<swiper-item id='2' catchtouchmove='catchTouchMove'>
						<secondclassification></secondclassification>
					</swiper-item>
					<swiper-item id='3' catchtouchmove='catchTouchMove'>
						<secondnews></secondnews>
					</swiper-item>
				</swiper>
			</view>
			<view class="Bottomnavigation">
				<div @click="setnav(index,item.id)" v-for="(item,index) in navimg">
					<Iconfonts :name="item.name" :size="item.size" :colors="item.color" />
					<p>{{item.title}}</p>
				</div>
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	import allseconds from '../../components/allseconds.vue'
	import secondclassification from '../../components/secondclassification.vue'
	import secondnews from '../../components/secondnews.vue'
	export default {
		data() {
			return {
				itemid: 0,
				navimg: [{
						name: 'icon-shouye',
						size: '40rpx',
						color: "#3c9cff",
						title: "首页",
						id: 0
					},
					{
						name: 'icon-fenlei',
						size: '50rpx',
						color: "#999999",
						title: "分类",
						id: 1
					},
					{
						name: 'icon-jia',
						size: '45rpx',
						color: "#3c9cff",
						title: "发布",
						id: 3
					},
					{
						name: 'icon-xiaoxi2',
						size: '40rpx',
						color: "#999999",
						title: "消息",
						id: 2
					},
					{
						name: 'icon-wode',
						size: '40rpx',
						color: "#999999",
						title: "我的",
						id: 4
					}
				]
			}
		},
		methods: {
			setnav: function(e, a) {
				let arr = this.navimg;
				if (a == 4) {
					uni.switchTab({
						url: '../shopmain/shopmain'
					});
				} else if (a == 3) {
					uni.navigateTo({
						url: '../Releasesecond/Releasesecond'
					});
				} else {
					this.itemid = a
				}
				for (let i in arr) {
					arr[i].color = '#999999'
				}
				arr[e].color = '#3c9cff';
				arr[2].color = '#3c9cff';
			},
			scroll: function(e) {
				console.log(e.detail.current)
			},
			catchTouchMove: function(res) {
				return false
			}
		},
		components: {
			Navigation,
			Iconfonts,
			allseconds,
			secondclassification,
			secondnews
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.swiper {
		height: 100%;
	}

	.secondpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.second .secondcontent {
		flex: 1;
	}

	.second {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.second .Bottomnavigation div p {
		text-align: center;
		margin-top: 5rpx;
		color: #666666;
		font-size: 20rpx;
	}

	.second .Bottomnavigation div Iconfonts {
		margin: 0 auto;
		display: flex;
		justify-content: center;
	}

	.second .Bottomnavigation div {
		width: 20%;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.second .Bottomnavigation {
		width: 100%;
		height: 100rpx;
		background-color: #ffffff;
		display: flex;

	}
</style>
