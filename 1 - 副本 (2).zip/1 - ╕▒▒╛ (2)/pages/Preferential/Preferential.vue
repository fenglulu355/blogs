<template>
	<view class="preferential">
		<div class='preferli preone' >
			<div class='preferleft'>
				<div>满减商品券</div>
				<div>适用于门店所有分类</div>
			</div>
			<div class='preferright' style="color: #f5bc32;" @click="addpre(0)">添加该券</div>
		</div>
		<div class='preferli pretow'>
			<div class='preferleft'>
				<div>折扣商品券</div>
				<div>适用于门店所有分类</div>
			</div>
			<div class='preferright' style="color: #23c88c;" @click="addpre(1)">添加该券</div>
		</div>
		<div class='preferli prethree'>
			<div class='preferleft'>
				<div>满减外卖券</div>
				<div>适用于门店所有分类</div>
			</div>
			<div class='preferright' style="color: #ff643a;" @click="addpre(2)">添加该券</div>
		</div>
		<div class='preferli prefour'>
			<div class='preferleft'>
				<div>折扣外卖券</div>
				<div>适用于门店所有分类</div>
			</div>
			<div class='preferright' style="color: #3c9cff;" @click="addpre(3)">添加该券</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			addpre:function(e){
				uni.navigateTo({
					url:`../addpreferential/addpreferential?pid=${e}`
				});
			}
		}
	}
</script>

<style>
page{
	height: 100%;
}
.preone{
	background-image: url(../../static/images/prefour.png);
}
.pretow{
	background-image: url(../../static/images/preone.png);
}
.prethree{
	background-image: url(../../static/images/pretow.png);
}
.prefour{
	background-image: url(../../static/images/prethree.png);
}
.preferential .preferli .preferright{
	width: 160rpx;
	height: 50rpx;
	background-color: #ffffff;
	box-shadow: 0rpx 5rpx 20rpx 0rpx 
		rgba(205, 149, 15, 0.35);
	border-radius: 25rpx;
	font-family: PingFang-SC-Medium;
	font-size: 24rpx;
	font-weight: normal;
	font-stretch: normal;
	line-height: 44rpx;
	letter-spacing: 0rpx;
	text-align: center;
	line-height: 50rpx;
	margin: auto 0;
}
.preferential .preferli .preferleft div:last-child{
	font-family: PingFang-SC-Medium;
	font-size: 24rpx;
	font-weight: normal;
	font-stretch: normal;
	line-height: 44rpx;
	letter-spacing: 0rpx;
	color: #ffffff;
}
.preferential .preferli .preferleft div:first-child{
	font-family: PingFang-SC-Bold;
	font-size: 36rpx;
	font-weight: bold;
	font-stretch: normal;
	line-height: 44rpx;
	letter-spacing: 0rpx;
	color: #ffffff;
}
.preferential .preferli .preferleft{
	margin: auto 0;
}
.preferential .preferli{
	width: 614rpx;
	height: 210rpx;
	border-radius: 10rpx;
	margin: 0 auto;
	margin-top: 20rpx;
	padding: 0 50rpx;
	display: flex;
	justify-content: space-between;
	background-position: center;
	background-size: cover;
	background-repeat: no-repeat;
}
.preferential{
	height: 100%;
	background-color: #f8f8f8;
	display: flex;
	flex-direction: column;
}
</style>
