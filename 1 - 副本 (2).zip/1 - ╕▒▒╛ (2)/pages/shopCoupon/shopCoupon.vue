<template>
	<view class="coupons">
		<Navigation></Navigation>
		<view class="shopcoupon">
			<view>
				<view class="tz">
					<Iconfonts name="icon-laba" size="30rpx" colors="#f5bc32" />
					<div>过期优惠券将自动清除，请尽快使用！</div>
				</view>
				<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
			</view>
			<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
				<swiper-item id="1">
					<view class="Couponli" v-for="item in 50">
						<view class="couponleft">
							<view class="coupontop">商品券</view>
							<view class="couponbottom">
								<div class="title">全场满100减50</div>
								<div>有效期：2019-03-20至2019-04-20</div>
								<div>使用门店：精致女人服装店</div>
							</view>
							<div class="xiabanyuan"></div>
							<div class="banyuan"></div>
						</view>
						<view class="couponright">
							<div>50 <span>元</span></div>
							<div>满100可使用</div>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="2">
					<view class="Couponli" v-for="item in 50">
						<view class="couponleft">
							<view class="coupontop">商品券</view>
							<view class="couponbottom">
								<div class="title">全场满100减50</div>
								<div>有效期：2019-03-20至2019-04-20</div>
								<div>使用门店：精致女人服装店</div>
							</view>
							<div class="xiabanyuan"></div>
							<div class="banyuan"></div>
						</view>
						<view class="couponright">
							<div>50 <span>元</span></div>
							<div>满100可使用</div>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="3">
					<view class="Couponli" v-for="item in 50">
						<view class="couponleft">
							<view class="coupontop">商品券</view>
							<view class="couponbottom">
								<div class="title">全场满100减50</div>
								<div>有效期：2019-03-20至2019-04-20</div>
								<div>使用门店：精致女人服装店</div>
							</view>
							<div class="xiabanyuan"></div>
							<div class="banyuan"></div>
						</view>
						<view class="couponright">
							<div>50 <span>元</span></div>
							<div>满100可使用</div>
						</view>
					</view>
				</swiper-item>
			</swiper>
		</view>
	</view>
</template>

<script>
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				TabCur: 0,
				tabList: [{
					name: '全部'
				}, {
					name: '商品'
				}, {
					name: '外卖'
				}],
			}
		},
		components: {
			WucTab,
			Navigation,
			Iconfonts
		},
		methods: {
			tabChange(index) {
				this.TabCur = index;
			},
			swiperChange(e) {
				this.tabChange(e.detail.current)
			}
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	
	.Couponli .couponleft .xiabanyuan{
		bottom: -16rpx;
		position: absolute;
		width: 32rpx;
		height: 32rpx;
		border-radius: 50%;
		right: -19rpx;
		background-color: #f8f8f8;
	}
	
	.Couponli .couponleft .banyuan{
		position: absolute;
		width: 32rpx;
		height: 32rpx;
		border-radius: 50%;
		right: -19rpx;
		top: -16rpx;
		background-color: #f8f8f8;
	}
	
	.Couponli .couponright div:first-child span{
		font-size: 28px;
	}
	
	.Couponli .couponright div:first-child{
		color: #ffffff;
		font-size: 60rpx;
		text-align: center;
		font-weight: bold;
	}
	
	.Couponli .couponright div:last-child{
		color: #ffffff;
		font-size: 20rpx;
		text-align: center;
	}

	.Couponli .couponright {
		flex: 1;
		background-color: #f5bc32;
		text-align: center;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	
	.Couponli .couponleft .couponbottom div{
		color: #666666;
		font-size: 20rpx;
	}
	
	.Couponli .couponleft .couponbottom .title{
		color: #333333;
		font-size: 32rpx;
		margin-bottom: 14rpx;
	}
	
	.Couponli .couponleft .couponbottom{
		flex: 1;
		padding: 20rpx;
		display: flex;
		flex-direction: column;
	}
	
	.Couponli .couponleft .coupontop{
		width: 100rpx;
		height: 40rpx;
		background-color: #f5bc32;
		border-radius: 5rpx 0rpx 5rpx 0rpx;
		text-align: center;
		line-height: 40rpx;
		color: #ffffff;
		font-size: 24rpx;
	}

	.Couponli .couponleft {
		width: 485rpx;
		border-right: 6rpx dashed #f1f1f1;
		display: flex;
		flex-direction: column;
		position: relative;
	}

	.Couponli {
		width: 714rpx;
		height: 180rpx;
		margin: 18rpx auto;
		background-color: #fff;
		overflow: hidden;
		flex-shrink: 0;
		border-radius: 10rpx;
		display: flex;
	}

	swiper-item {
		display: flex;
		flex-direction: column;
		overflow: auto;
	}

	.coupons {
		display: flex;
		flex-direction: column;
		height: 100%;
	}

	.shopcoupon .tz div {
		margin: auto 0;
		color: #222222;
		font-size: 20rpx;
	}

	.shopcoupon .tz Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 8rpx;
	}

	.shopcoupon .tz {
		height: 60rpx;
		background-color: #f8f2e4;
		padding: 0 18rpx;
		display: flex;
	}

	.shopcoupon {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.swip {
		background-color: #f8f8f8;
		flex: 1;
	}
</style>
