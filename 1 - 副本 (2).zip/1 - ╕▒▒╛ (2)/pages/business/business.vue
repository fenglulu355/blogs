<template>
	<view class="business">
		<div class='head'></div>
		<div class='introduction'>
			<div class='introne'>
				<div class='intrtop'>
					<div class='intrimg'>
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<div class='abso'>封面</div>
					</div>
					<div class='addimg' @click='addimage'>
						<image mode="widthFix" src="../../static/images/xiangji.png"></image>
						<div>添加图片</div>
					</div>
				</div>
				<div class='intrbottom'>商家照片最多上传50张</div>
			</div>
			<div class='introne'>
				<div class='intrtop'>
					<div class='intrimg'>
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</div>
					<div class='addimg' @click='addimage'>
						<image mode="widthFix" src="../../static/images//xiangji.png"></image>
						<div>添加图片</div>
					</div>
				</div>
				<div class='intrbottom'>商家资质</div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>商家名称</div>
				<div class='intrlitow' style='color: #222222;'><input type="text" placeholder="精品纱纺女装上衣" placeholder-style="color:#222222"></div>
				<div class='intrlithree'></div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>联系电话</div>
				<div class='intrlitow'><input type="text" placeholder="请输入联系电话"></div>
				<div class='intrlithree'></div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>营业时间</div>
				<div class='intrlitow'>请选择营业时间</div>
				<div class='intrlithree'>
					<image mode="widthFix" src="../../static/images/right.png"></image>
				</div>
			</div>
			<div class='intrli'>
				<div class='intrlione'>地理位置</div>
				<div class='intrlitow'>请选择商家位置</div>
				<div class='intrlithree'>
					<image mode="widthFix" src="../../static/images/right.png"></image>
				</div>
			</div>
			<div class='intrclass'>
				<div>服务类型</div>
				<div :style='intrcla[0]' @click="intrsty(0)">电话订位</div>
				<div :style='intrcla[1]' @click="intrsty(1)">接受外卖</div>
				<div :style='intrcla[2]' @click="intrsty(2)">线上买单</div>
			</div>
		</div>
		<div class='Recommend'>
			<div class='recomone'>推荐商品</div>
			<div class='recomtow' @click='addimage'>+</div>
		</div>
		<div class='Preservation'>保存</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				intrcla: [
					'background-color: #23c88c;color: #ffffff;',
					'background-color: #FFFFFF;color: #bbbbbb;',
					'background-color: #FFFFFF;color: #bbbbbb;',
				]
			}
		},
		methods: {
			addimage: function() {
				uni.chooseImage({
					count: 9, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album', 'camera'], //从相册选择
					success: function(res) {
						console.log(JSON.stringify(res.tempFilePaths));
					}
				});
			},
			intrsty: function(e) {
				this.intrcla = [
					'background-color: #FFFFFF;color: #bbbbbb;',
					'background-color: #FFFFFF;color: #bbbbbb;',
					'background-color: #FFFFFF;color: #bbbbbb;',
				];
				let arr = this.intrcla;
				arr[e] = 'background-color: #23c88c;color: #ffffff;'
				this.intrcla = arr
			}
		}
	}
</script>

<style>
	page {
		height: 100%;
	}

	.business .Preservation {
		width: 100%;
		height: 100rpx;
		background-color: #f5bc32;
		text-align: center;
		line-height: 100rpx;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		position: fixed;
		bottom: 0;
	}

	.business .Recommend .recomtow {
		width: 120rpx;
		height: 120rpx;
		background-color: #f8f8f8;
		border-radius: 5rpx;
		margin: 0 auto;
		color: #bbbbbb;
		font-size: 70rpx;
		text-align: center;
		line-height: 120rpx;
	}

	.business .Recommend .recomone {
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #222222;
		margin: 0 auto;
		margin-bottom: 50rpx;
	}

	.business .Recommend {
		width: 714rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 20rpx auto;
		padding: 30rpx 0;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-bottom: 120rpx;
	}

	.business .introduction .intrclass div:first-child {
		width: auto;
		background-color: #FFFFFF;
		border: none;
	}

	.business .introduction .intrclass div {
		width: 150rpx;
		height: 50rpx;
		border-radius: 25rpx;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #bbbbbb;
		text-align: center;
		line-height: 50rpx;
		margin: auto 0;
		border: solid 1rpx #eeeeee;
	}

	.business .introduction .intrclass {
		height: 98rpx;
		display: flex;
		justify-content: space-between;
	}

	.business .introduction .intrli .intrlithree image {
		width: 100%;
	}

	.business .introduction .intrli .intrlithree {
		width: 28rpx;
		margin: auto 0;
	}

	.business .introduction .intrli .intrlitow {
		flex: 1;
		margin: auto 0;
		margin-left: 20rpx;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.business .introduction .intrli .intrlione {
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #bbbbbb;
		margin: auto 0;
	}

	.business .introduction .intrli {
		height: 98rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.business .introduction .introne .intrbottom {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 30rpx;
		letter-spacing: 0rpx;
		color: #999999;
		line-height: 60rpx;
	}

	.business .introduction .introne .intrtop .addimg div {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin: 0 auto;
	}

	.business .introduction .introne .intrtop .addimg image {
		width: 61rpx;
		margin: 0 auto;
	}

	.business .introduction .introne .intrtop .addimg {
		width: 120rpx;
		height: 120rpx;
		background-color: #f8f8f8;
		border-radius: 5rpx;
		margin-left: 14rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.business .introduction .introne .intrtop .intrimg .abso {
		width: 100%;
		height: 40rpx;
		background-color: #3c9cff;
		opacity: 0.8;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #fffbfb;
		position: absolute;
		text-align: center;
		line-height: 40rpx;
		bottom: 0;
	}

	.business .introduction .introne .intrtop .intrimg image {
		width: 100%;
	}

	.business .introduction .introne .intrtop .intrimg {
		width: 120rpx;
		height: 120rpx;
		background-color: #f8f8f8;
		border-radius: 5rpx;
		position: relative;
	}

	.business .introduction .introne .intrtop {
		display: flex;
	}

	.business .introduction .introne {
		border-bottom: 1rpx solid #f2f2f2;
		padding-bottom: 20rpx;
		padding-top: 30rpx;
	}

	.business .introduction {
		width: 670rpx;
		padding: 0 22rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: -70rpx;
	}

	.business .head {
		height: 70rpx;
		background-color: #ffc528;
	}

	.business {
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}
</style>
