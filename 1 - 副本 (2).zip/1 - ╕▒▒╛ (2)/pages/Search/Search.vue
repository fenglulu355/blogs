<template>
	<view class="search">
		<Navigation></Navigation>
		<view class="searchdetail">
			<view class="searchinput">
				<view class="inp">
					<Iconfonts name="icon-sousuo" size="25rpx" colors="#9a9a9a" />
					<input type="text" placeholder="吃喝玩乐随便找" v-model="searchs" @blur="result">
				</view>
				<view class="cancel" @click="cancels">取消</view>
			</view>
			<view class="tab">
				<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
			
				<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
					<swiper-item id="1">
						<view class="business">
							<!-- <view class="Guess">
								<view class="guetitle">猜你喜欢</view>
								<view class="guetxt">
									<view class="searchlabol" v-for="item in 5">老君肝串串</view>
								</view>
							</view> -->
							<view class="History" v-if="History.shop">
								<view class="histitle">
									<div>搜索历史</div>
									<span @click="empty(0)"><Iconfonts name="icon-lajitong" size="38rpx" colors="#8d8d8d" /></span>
								</view>
								<view class="histxt">
									<view class="searchlabol" v-for="item in History.shop" :key="item">{{item}}</view>
								</view>
							</view>
						</view>
					</swiper-item>
					<swiper-item id="2">
						<view class="business">
							<!-- <view class="Guess">
								<view class="guetitle">猜你喜欢</view>
								<view class="guetxt">
									<view class="searchlabol" v-for="item in 5">老君肝串串</view>
								</view>
							</view> -->
							<view class="History" v-if="History.commodity">
								<view class="histitle">
									<div>搜索历史</div>
									<span @click="empty(1)"><Iconfonts name="icon-lajitong" size="38rpx" colors="#8d8d8d" /></span>
								</view>
								<view class="histxt">
									<view class="searchlabol" v-for="item in History.commodity">{{item}}</view>
								</view>
							</view>
						</view>
					</swiper-item>
				</swiper>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	import Iconfonts from '../../components/iconfonts.vue'
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				searchs: '',
				TabCur: 0,
				tabList: [{
					name: '商家'
				}, {
					name: '商品'
				}]
			}
		},
		onShow:function(){
			this.getHistory();
		},
		computed: {
			...mapState(['History'])
		},
		methods: {
			...mapActions(['getHistory','getsearchshop','getsearchcomm']),
			...mapMutations(['setthishistory','setempty']),
			cancels: function() {
				this.searchs = ''
			},
			tabChange(index) {
				// console.log(index);
				this.TabCur = index;
			},
			swiperChange(e) {
				// console.log(e);
				this.tabChange(e.detail.current)
			},
			result:function(){
				if(this.TabCur == 0){
					this.getsearchshop(this.searchs);
				}else{
					this.getsearchcomm({page:1,data:this.searchs});
				}
				uni.showLoading({
					title: '加载中...'
				});
				setTimeout(()=>{
					this.setthishistory({id:this.TabCur,searchs:this.searchs});
					uni.navigateTo({
						url: '../searchResult/searchResult'
					});
					this.searchs = '';
					uni.hideLoading();
				}, 500);
			},
			empty:function(e){
				this.setempty(e);
			}
		},
		components: {
			Navigation,
			Iconfonts,
			WucTab
		}
	}
</script>

<style>
	.searchlabol {
		padding: 0 24rpx;
		height: 50rpx;
		background-color: #efefef;
		border-radius: 25rpx;
		line-height: 50rpx;
		text-align: center;
		color: #222222;
		font-size: 24rpx;
		margin-right: 30rpx;
		margin-bottom: 30rpx;
	}
	.search .searchdetail .tab .swip .business .History .histxt{
		display: flex;
		flex-wrap: wrap;
	}
	
	.search .searchdetail .tab .swip .business .History .histitle Iconfonts{
		margin: auto 0;
	}
	
	.search .searchdetail .tab .swip .business .History .histitle div{
		line-height: 54rpx;
		text-align: center;
		color: #222222;
		font-size: 28rpx;
	}
	
	.search .searchdetail .tab .swip .business .History .histitle{
		height: 54rpx;
		display: flex;
		justify-content: space-between;
		margin: 20rpx 0;
	}

	.search .searchdetail .tab .swip .business .Guess .guetxt {
		display: flex;
		flex-wrap: wrap;
	}

	.search .searchdetail .tab .swip .business .Guess .guetitle {
		line-height: 54rpx;
		color: #222222;
		font-size: 28rpx;
		margin: 20rpx 0;
	}

	.search .searchdetail .tab .swip .business {
		padding: 0 18rpx;
		display: flex;
		flex-direction: column;
		margin-bottom: 20rpx;
	}

	.search .searchdetail .tab .swip {
		flex: 1;
		overflow: auto;
	}

	.search .searchdetail .tab wuc-tab {
		background-color: #fff;
		border-bottom: 1rpx solid #f2f2f2;
	}

	.search .searchdetail .tab {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.search .searchdetail .searchinput .cancel {
		margin: auto 0;
		color: #222222;
		font-size: 28rpx;
		margin-left: 30rpx;
	}

	.search .searchdetail .searchinput .inp Iconfonts {
		position: absolute;
		top: 0;
		bottom: 0;
		margin: auto 0;
	}

	.search .searchdetail .searchinput .inp input {
		margin: auto 0;
		width: 100%;
		margin-left: 35rpx;
		color: #999999;
		font-size: 24rpx;
	}

	.search .searchdetail .searchinput .inp {
		width: 560rpx;
		height: 60rpx;
		background-color: #efefef;
		border-radius: 30rpx;
		margin: auto 0;
		display: flex;
		padding: 0 30rpx;
		position: relative;
	}

	.search .searchdetail .searchinput {
		height: 88rpx;
		background-color: #fff;
		padding: 0 18rpx;
		display: flex;
	}

	.search .searchdetail {
		flex: 1;
		background-color: #fff;
		display: flex;
		flex-direction: column;
	}

	.search {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100vh;
	}
</style>
