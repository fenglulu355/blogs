<template>
	<view class="account">
		<Navigation></Navigation>
		<view class="accountdetail">
			<view class="user">
				<view class="switch">
					<div>手机号</div>
					<view class="zhon">
						18180417045
					</view>
					<view class="yanzheng">
						验证码
					</view>
				</view>
				<view class="switch">
					<div>验证码</div>
					<view class="zhon">
						<input type="text" value="" v-model="Code" />
					</view>
				</view>
			</view>
			<view class="Signin" @click="Nextstep">
				下一步
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				Code: ''
			}
		},
		methods: {
			Nextstep: function() {
				let iscode = /^\d{6}$/;
				if (iscode.test(this.Code)) {
					uni.showLoading({
						title: '加载中'
					});
					setTimeout(function() {
						uni.navigateTo({
							url: '../newChangeties/newChangeties'
						});
						uni.hideLoading();
					}, 2000);

				} else {
					uni.showToast({
						title: '请输入六位整数验证码',
						icon: 'none',
						duration: 2000
					})
				}
			}
		},
		components: {
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.accountdetail .Signin {
		width: 714rpx;
		height: 88rpx;
		opacity: 0.5;
		background-color: #ffc528;
		border-radius: 10rpx;
		margin: 0 auto;
		color: #222222;
		opacity: 0.5;
		font-size: 28rpx;
		text-align: center;
		line-height: 88rpx;
	}

	.accountdetail .user .switch .phone {
		margin: auto 0;
		color: #999999;
		font-size: 24rpx;
	}

	.accountdetail .user .switch .yanzheng {
		width: 150rpx;
		height: 60rpx;
		background-color: #f2f2f2;
		border-radius: 5rpx;
		border: solid 1rpx #dddddd;
		margin: auto 0;
		color: #666666;
		font-size: 24rpx;
		text-align: center;
		line-height: 60rpx;
	}

	.accountdetail .user .switch .zhon {
		flex: 1;
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
		margin-left: 28rpx;
	}

	.accountdetail .user .switch div {
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}

	.accountdetail .user .switch {
		height: 96rpx;
		background-color: #fff;
		display: flex;
		border-bottom: 1rpx solid #f8f8f8;
		padding: 0 18rpx;
		justify-content: space-between;
	}

	.accountdetail .user {
		margin: 18rpx 0;
	}

	.accountdetail {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.account {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
