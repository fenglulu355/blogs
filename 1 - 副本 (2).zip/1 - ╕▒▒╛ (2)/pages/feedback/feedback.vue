<template>
	<view class="feedback">
		<Navigation></Navigation>
		<view class="feedbackdetail">
			<view class="feedtype" v-for="(item,index) in ClassA">
				<view class="feedtitle">
					{{item.title}}
				</view>
				<view class="feedtxt" v-for="(items,indexs) in item.all">
					<view class="feedli" @click="open(index,indexs)">
						<div>{{items.title}}</div>
						<div v-if="items.display == 'none'">+</div>
						<div v-else>-</div>
					</view>
					<view class="feedlitxt" :style="'display:'+items.display">
						{{items.txt}}
					</view>
				</view>
			</view>
		</view>
		<view class="Opinion" @click="leaving">
			<Iconfonts name="icon-yijianfankui1" size="37rpx" colors="#040000" />
			<div>意见反馈</div>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				ClassA:[
					{
						title:'订单支付',
						all:[
							{
								title:'支付突然中断，订单完成不了？',
								txt:'若购买过程中遇到联网中断，一般系统在30分钟之内自动退款,若30分钟后仍查询未到账请联系商家客服我们将马上处理！',
								display:'none',
								istrue:false
							},
							{
								title:'支付突然中断，订单完成不了？',
								txt:'若购买过程中遇到联网中断，一般系统在30分钟之内自动退款,若30分钟后仍查询未到账请联系商家客服我们将马上处理！',
								display:'none',
								istrue:false
							}
						]
					},
					{
						title:'订单支付',
						all:[
							{
								title:'支付突然中断，订单完成不了？',
								txt:'若购买过程中遇到联网中断，一般系统在30分钟之内自动退款,若30分钟后仍查询未到账请联系商家客服我们将马上处理！',
								display:'none',
								istrue:false
							},
							{
								title:'支付突然中断，订单完成不了？',
								txt:'若购买过程中遇到联网中断，一般系统在30分钟之内自动退款,若30分钟后仍查询未到账请联系商家客服我们将马上处理！',
								display:'none',
								istrue:false
							}
						]
					},
					{
						title:'订单支付',
						all:[
							{
								title:'支付突然中断，订单完成不了？',
								txt:'若购买过程中遇到联网中断，一般系统在30分钟之内自动退款,若30分钟后仍查询未到账请联系商家客服我们将马上处理！',
								display:'none',
								istrue:false
							},
							{
								title:'支付突然中断，订单完成不了？',
								txt:'若购买过程中遇到联网中断，一般系统在30分钟之内自动退款,若30分钟后仍查询未到账请联系商家客服我们将马上处理！',
								display:'none',
								istrue:false
							}
						]
					}
				]
			}
		},
		methods: {
			open:function(e,a){
				let arr = this.ClassA;
				if(arr[e].all[a].istrue){
					arr[e].all[a].display = 'none'
					arr[e].all[a].istrue = false
				}else{
					arr[e].all[a].display = 'block'
					arr[e].all[a].istrue = true
				}
			},
			leaving:function(){
				uni.navigateTo({
					url: '../Leaving/Leaving'
				});
			}
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
page{
	height: 100vh;
}

.feedbackdetail .feedtype .feedtxt .feedlitxt{
	background-color: #f8f8f8;
	border-radius: 5rpx;
	margin-bottom: 30rpx;
	padding: 40rpx 32rpx;
	color: #666666;
	font-size: 24rpx;
}

.feedbackdetail .feedtype .feedtxt .feedli div:last-child{
	width: 38rpx;
	height: 38rpx;
	border: solid 2rpx #222222;
	border-radius: 50%;
	color:#f5bc32;
	font-size: 34rpx;
	font-weight: bold;
	line-height: 32rpx;
	text-align: center;
	margin: auto 0;
}

.feedbackdetail .feedtype .feedtxt .feedli div:first-child{
	color: #222222;
	font-size: 28rpx;
	margin: auto 0;
}

.feedbackdetail .feedtype .feedtxt .feedli{
	line-height: 80rpx;
	display: flex;
	justify-content: space-between;
}

.feedbackdetail .feedtype .feedtxt{
	display: flex;
	flex-direction: column;
	border-bottom: 1rpx solid #f2f2f2;
	background-color: #fff;
	padding: 0 18rpx;
}

.feedbackdetail .feedtype .feedtitle{
	height: 80rpx;
	padding: 0 18rpx;
	line-height: 80rpx;
	color: #666666;
	font-size: 24rpx;
}

.Opinion div{
	margin: auto 0;
	color: #222222;
	font-size: 28rpx;
}

.Opinion Iconfonts{
	margin: auto 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
	margin-right: 10rpx;
}
.Opinion{
	position: fixed;
	width: 100%;
	height: 100rpx;
	bottom: 0;
	background-color: #ffffff;
	box-shadow: 0rpx 5rpx 24rpx 0rpx rgba(3, 0, 0, 0.1);
	display: flex;
	justify-content: center;
}
.feedbackdetail{
	flex: 1;
	margin-bottom: 100rpx;
	background-color: #f8f8f8;
}
.feedback{
	height: 100%;
	display: flex;
	flex-direction: column;
}
</style>
