<template>
	<view class="footprintpage">
		<Navigation></Navigation>
		<view class="footprint">
			<view class="footgood">
				<view class="foottime">
					今天
				</view>
				<view class="footsli">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<view class="footliright">
						<view class="foottitle">油渣大白菜</view>
						<view class="foottotal">￥<spa>16</spa></view>
						<div>巴适得坂川菜馆</div>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {

			}
		},
		created: function() {
			var now = new Date();
			var year = now.getFullYear(); //得到年份
			var month = now.getMonth() + 1; //得到月份
			var date = now.getDate(); //得到日期
			let newtime = year + '-' + month + '-' + date
			console.log(newtime);
		},
		methods: {

		},
		components: {
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	
	.footprint .footgood .footsli .footliright div{
		width: 180rpx;
		height: 50rpx;
		/* padding: 0 20rpx; */
		background-color: #fffbe9;
		border-radius: 2rpx;
		text-align: center;
		line-height: 50rpx;
		color: #666666;
		font-size: 20rpx;
	}
	
	.footprint .footgood .footsli .footliright .foottotal span{
		font-size: 32px;
	}
	
	.footprint .footgood .footsli .footliright .foottotal{
		color: #ff643a;
		font-size: 22rpx;
	}
	
	.footprint .footgood .footsli .footliright .foottitle{
		color: #222222;
		font-size: 24rpx;
		margin-bottom: 20rpx;
	}
	
	.footprint .footgood .footsli .footliright{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.footprint .footgood .footsli image {
		width: 160rpx;
		height: 160rpx;
		border-radius: 5rpx;
		border: solid 1rpx #f8f8f8;
		margin-right: 20rpx;
	}

	.footprint .footgood .footsli {
		height: 160rpx;
		background-color: #ffffff;
		padding: 20rpx 18rpx;
		display: flex;
		border-bottom: 1rpx solid #f8f8f8;
	}

	.footprint .footgood .foottime {
		height: 78rpx;
		line-height: 78rpx;
		padding: 0 18rpx;
		color: #666666;
		font-size: 24rpx;
	}

	.footprintpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.footprint {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
		overflow: auto;
	}
</style>
