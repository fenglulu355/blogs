<template>
	<view class="orderpage">
		<Navigation></Navigation>
		<view class="orderdetails">
			<view class="orderaddr">
				<view class="ordertop">
					<view class="ordertopa">
						<div>收货人：杨YY</div>
						<div>156 6666 6666</div>
					</view>
					<view class="ordertopb">
						收货地址：四川省成都市武侯区人民南路北段40号新希望大厦7楼704室
					</view>
				</view>
				<view class="orderbottom">
					<div v-for="item in color" :style="'background-color:'+item"></div>
				</view>
			</view>
			<view class="dynamic" @click="logistic">
				<div>物流动态</div>
				<div>
					<p>已发货</p>
					<Iconfonts name="icon-you" size="26rpx" colors="#222222" />
				</div>
			</view>
			<view class="commodity">
				<view class="commoditytitle">
					<div>精致女人桐梓林店</div>
					<div>商品订单</div>
				</view>
				<view class="commidityli">
					<view class="commiditys">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<view class="onediv">
							<p>女装2019夏季新款珍珠扣翻领短袖polo针织衫女A300345 静谧蓝S(2码)</p>
							<p>x1</p>
						</view>
						<view class="towdiv">
							￥58.00
						</view>
					</view>
					<view class="commiditys">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<view class="onediv">
							<p>女装时尚毛衫</p>
							<p>x1</p>
						</view>
						<view class="towdiv">
							￥58.00
						</view>
					</view>
				</view>
				<view class="Discount">
					<div>商家优惠</div>
					<div> -￥10</div>
				</view>
				<view class="Discount">
					<div style="color:#999999">实付</div>
					<div>小计<span>￥36.50</span></div>
				</view>
			</view>
			<view class="Business">
				<view class="busineli">
					<div style="color:#666666">商家信息</div>
				</view>
				<view class="busineli">
					<div>商家地址</div>
					<p>成都武侯区桐梓林人民南路7号</p>
				</view>
				<view class="busineli">
					<div>联系商家</div>
					<Iconfonts name="icon-dianhua" size="50rpx" colors="#f5bc32" />
				</view>
			</view>
			<view class="Business">
				<view class="busineli">
					<div style="color:#666666">订单信息</div>
				</view>
				<view class="busineli">
					<div>订单编号</div>
					<p>214213451231321</p>
				</view>
				<view class="busineli">
					<div>下单时间</div>
					<p>2019-06-04</p>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				color: ['#f5bc32', '#3c9cff', '#f5bc32', '#3c9cff', '#f5bc32', '#3c9cff', '#f5bc32', '#3c9cff', '#f5bc32',
					'#3c9cff', '#f5bc32', '#3c9cff', '#f5bc32'
				]
			}
		},
		methods:{
			logistic:function(){
				uni.navigateTo({
					url: '../Logisticsdetails/Logisticsdetails'
				});
			}
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.orderpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.orderdetails .Business .busineli Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.orderdetails .Business .busineli p{
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
		font-weight: bold;
	}
	
	.orderdetails .Business .busineli div{
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}
	
	.orderdetails .Business .busineli{
		display: flex;
		justify-content: space-between;
		height: 96rpx;
		border-bottom: 1rpx solid #f2f2f2;
	}
	
	.orderdetails .Business{
		padding: 0 18rpx;
		background-color: #fff;
		margin-bottom: 18rpx;
	}
	
	.orderdetails .commodity .Discount div span{
		font-size: 32rpx;
		font-weight: bold;
	}

	.orderdetails .commodity .Discount div {
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}

	.orderdetails .commodity .Discount {
		height: 103rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.orderdetails .commodity .commidityli .commiditys .onediv p {
		color: #222222;
		font-size: 28rpx;
	}

	.orderdetails .commodity .commidityli .commiditys .towdiv {
		color: #222222;
		font-size: 24rpx;
	}

	.orderdetails .commodity .commidityli .commiditys .onediv {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-right: 35rpx;
	}

	.orderdetails .commodity .commidityli .commiditys image {
		width: 100rpx;
		height: 100rpx;
		background-color: #f2f2f2;
		border-radius: 5rpx;
		flex-shrink: 0;
		margin-right: 22rpx;
	}

	.orderdetails .commodity .commidityli .commiditys:last-child {
		margin: 0;
	}

	.orderdetails .commodity .commidityli .commiditys {
		display: flex;
		justify-content: space-between;
		margin-bottom: 38rpx;
	}

	.orderdetails .commodity .commidityli {
		border-bottom: 1rpx solid #f2f2f2;
		padding: 38rpx 0;
	}

	.orderdetails .commodity .commoditytitle div:last-child {
		width: 120rpx;
		height: 50rpx;
		background-color: #fef8ea;
		border-radius: 2rpx;
		color: #222222;
		font-size: 24rpx;
		text-align: center;
		line-height: 50rpx;
		margin: auto 0;
	}

	.orderdetails .commodity .commoditytitle div:first-child {
		margin: auto 0;
		color: #666666;
		font-size: 24rpx;
	}

	.orderdetails .commodity .commoditytitle {
		height: 96rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.orderdetails .commodity {
		padding: 0 18rpx;
		background-color: #fff;
		margin-bottom: 18rpx;
	}

	.orderdetails .dynamic div:last-child Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.orderdetails .dynamic div:last-child p {
		margin: auto 10rpx;
		color: #ff643a;
		font-size: 24rpx;
	}

	.orderdetails .dynamic div:last-child {
		margin: auto 0;
		display: flex;
	}

	.orderdetails .dynamic div:first-child {
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}

	.orderdetails .dynamic {
		height: 96rpx;
		background-color: #ffffff;
		padding: 0 18rpx;
		display: flex;
		justify-content: space-between;
		margin-bottom: 18rpx;
	}

	.orderdetails .orderaddr .orderbottom div {
		width: 42rpx;
		height: 7rpx;
		background-color: #f5bc32;
		transform: skewX(-40deg);
	}

	.orderdetails .orderaddr .orderbottom {
		display: flex;
		justify-content: space-around;
	}

	.orderdetails .orderaddr .ordertop .ordertopb {
		color: #222222;
		font-size: 24rpx;
	}

	.orderdetails .orderaddr .ordertop .ordertopa div {
		color: #222222;
		font-size: 24rpx;
	}

	.orderdetails .orderaddr .ordertop .ordertopa {
		display: flex;
		justify-content: space-between;
		margin-bottom: 26rpx;
	}

	.orderdetails .orderaddr .ordertop {
		padding: 30rpx 18rpx;
	}

	.orderdetails .orderaddr {
		display: flex;
		flex-direction: column;
		background-color: #fff;
		margin: 18rpx 0;
	}

	.orderdetails {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
	}
</style>
