<template>
	<view class="commentpage">
		<Navigation></Navigation>
		<view class="comment">
			<view class="evaluate">
				<view class="xinxinli">
					<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
					<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
					<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
					<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
					<Iconfonts name="icon-xingxing" size="36rpx" colors="#f5bc32" />
				</view>
				<view class="evatxt">
					觉得怎么样，打个分吧
				</view>
				<view class="evalabolli">
					<div v-for="item in 6">我喜欢的啊啊</div>
				</view>
				<view class="evatexta">
					<textarea maxlength="50" placeholder-style="color:#999999" placeholder="商品还符合您的预期吗？（至少要写10个字哦~）…" />
					</view>
				<view class="addimage">
					<view class="addimgli">
						<view class="imglis" @click="addimg">
							<image mode="widthFix" src="../../static/images/jia.png"></image>
						</view>
						<view class="imglis">
							<image mode="widthFix" src="../../static/images/jia.png"></image>
						</view>
					</view>
					<view class="imgtxt">
						最多上传5张
					</view>
				</view>
			</view>
			
			<view class="pinglun">
				评论
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.pinglun{
	margin: 40rpx auto;
	width: 400rpx;
	height: 80rpx;
	background-color: #f5bc32;
	border-radius: 40rpx;
	text-align: center;
	line-height: 80rpx;
	color: #222222;
	font-size: 28rpx;
}
.commentpage{
	height: 100%;
	display: flex;
	flex-direction: column;
}
.comment .evaluate .addimage .imgtxt{
	color: #999999;
	font-size: 24rpx;
	margin-bottom: 40rpx;
}
.comment .evaluate .addimage .addimgli .imglis image{
	width: 100%;
}
.comment .evaluate .addimage .addimgli .imglis{
	width: 101rpx;
	height: 100rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
	overflow: hidden;
	margin-right: 5rpx;
	margin-bottom: 25rpx;
	margin-top: 25rpx;
	flex-shrink: 0;
}
.comment .evaluate .addimage .addimgli{
	display: flex;
}
.comment .evaluate .evatexta textarea{
	width: 100%;
	height: 100%;
}
.comment .evaluate .evatexta{
	width: 622rpx;
	padding: 22rpx;
	height: 156rpx;
	background-color: #f9f9f9;
	border-radius: 10rpx;
	position: relative;
	margin: 20rpx auto;
	font-size: 24rpx;
}
.comment .evaluate .evalabolli div{
	margin: 10rpx 5rpx;
	height: 54rpx;
	border-radius: 27rpx;
	padding: 0 25rpx;
	text-align: center;
	line-height: 54rpx;
	border: solid 1rpx #cccccc;
	color: #666666;
	font-size: 24rpx;
}
.comment .evaluate .evalabolli{
	display: flex;
	flex-wrap: wrap;
}
.comment .evaluate .evatxt{
	text-align: center;
	height: 85rpx;
	line-height: 85rpx;
	color: #999999;
	font-size: 24rpx;
}
.comment .evaluate .xinxinli Iconfonts{
	margin: 0 8rpx;
}
.comment .evaluate .xinxinli{
	margin: 0 auto;
	margin-top: 35rpx;
	display: flex;
}
.comment .evaluate{
	width: 678rpx;
	background-color: #ffffff;
	border-radius: 10rpx;
	padding: 0 18rpx;
	margin: 0 auto;
	margin-top: 18rpx;
	display: flex;
	flex-direction: column;
}
.comment{
	flex: 1;
	background-color: #f8f8f8;
	overflow: auto;
}
</style>
