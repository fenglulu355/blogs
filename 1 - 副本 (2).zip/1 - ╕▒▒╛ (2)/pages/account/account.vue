<template>
	<view class="account">
		<Navigation></Navigation>
		<view class="accountdetail">
			<view class="user">
				<view class="switch">
					<div>切换账号</div>
					<Iconfonts name="icon-you" size="22rpx" colors="#999999" />
				</view>
				<view class="switch" @click="changeties">
					<div>换绑手机</div>
					<view class="phone">
						18180417045
					</view>
				</view>
			</view>
			<view class="Signin" @click="outsig">
				退出登录
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			changeties:function(){
				uni.navigateTo({
					url: '../Changeties/Changeties'
				});
			},
			outsig:function(){
				uni.reLaunch({
				    url: '../login/login'
				});
			}
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
page{
	height: 100vh;
}

.accountdetail .Signin{
	width: 714rpx;
	height: 88rpx;
	background-color: #ffffff;
	border-radius: 10rpx;
	margin: 0 auto;
	color: #222222;
	font-size: 28rpx;
	text-align: center;
	line-height: 88rpx;
}
.accountdetail .user .switch .phone{
	margin: auto 0;
	color: #999999;
	font-size: 24rpx;
}
.accountdetail .user .switch Iconfonts{
	margin: auto 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
}
.accountdetail .user .switch div{
	margin: auto 0;
	color: #222222;
	font-size: 24rpx;
}
.accountdetail .user .switch{
	height: 96rpx;
	background-color: #fff;
	display: flex;
	border-bottom: 1rpx solid #f8f8f8;
	padding: 0 18rpx;
	justify-content: space-between;
}
.accountdetail .user{
	margin: 18rpx 0;
}
.accountdetail{
	flex: 1;
	background-color: #f8f8f8;
	display: flex;
	flex-direction: column;
}
.account{
	height: 100%;
	display: flex;
	flex-direction: column;
}
</style>
