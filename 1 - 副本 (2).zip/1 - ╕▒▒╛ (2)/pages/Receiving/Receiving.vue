<template>
	<view class="recepage">
		<Navigation></Navigation>
		<view class="receiv">
			<view class="address" v-for="(item,index) in addres">
				<view class="addretop">
					<view class="username">
						<div>{{item.name}}</div>
						<div>{{item.phone}}</div>
					</view>
					<view class="useraddr">{{item.addr}}</view>
				</view>
				<view class="addrebottom">
					<view class="addreleft">
						<label class="radio" @click="Choice(index)"><radio color="#F5BC32" value="r2" :checked="item.isdefault"  />选择该地址</label>
					</view>
					<view class="addreright">
						<view class="operation">
							<Iconfonts name="icon-bianji" size="30rpx" colors="#222222" />
							<div>编辑</div>
						</view>
						<view class="operation">
							<Iconfonts name="icon-lajitong" size="30rpx" colors="#222222" />
							<div>删除</div>
						</view>
					</view>
				</view>
				<div class="default" v-if="item.isdefault">默认地址</div>
			</view>
			<view class="newaddr" @click="address">
				新增地址
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				addres:[]
			}
		},
		created:function(){
			this.addres = getApp().globalData.addres;
		},
		methods: {
			Choice:function(e){
				let arr = this.addres;
				for(let i in arr){
					arr[i].isdefault = false
				}
				arr[e].isdefault = !arr[e].isdefault;
				// console.log(e);
			},
			address:function(){
				uni.navigateTo({
					url: '../Newamendments/Newamendments'
				});
			}
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.recepage{
	height: 100%;
	display: flex;
	flex-direction: column;
}
.receiv .address .addrebottom .addreright .operation div{
	color: #222222;
	font-size: 24rpx;
	margin: auto 0;
}
.receiv .address .addrebottom .addreright .operation Iconfonts{
	margin: auto 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
	margin-right: 12rpx;
}
.receiv .address .addrebottom .addreright .operation:first-child{
	margin-right: 58rpx;
}
.receiv .address .addrebottom .addreright .operation{
	display: flex;
}
.receiv .address .addrebottom .addreright{
	display: flex;
}
.receiv .address .addrebottom .addreleft .radio{
	color: #222222;
	font-size: 24rpx;
	margin: auto 0;
}
.receiv .address .addrebottom .addreleft{
	display: flex;
	flex-direction: column;
	justify-content: center;
	margin: auto 0;
}
.receiv .address .addrebottom{
	flex: 1;
	display: flex;
	justify-content: space-between;
}
.receiv .address .addretop .useraddr{
	color: #999999;
	font-size: 24rpx;
}
.receiv .address .addretop .username div{
	color: #222222;
	font-size: 30rpx;
	margin-right: 28rpx;
}
.receiv .address .addretop .username{
	display: flex;
}
.receiv .address .addretop{
	height: 81rpx;
	border-bottom: 1rpx solid #f2f2f2;
	padding: 32rpx 0;
	display: flex;
	flex-direction: column;
	justify-content: space-between;
}
.receiv .address .default{
	position: absolute;
	right: 0;
	top: 0;
	width: 100rpx;
	height: 44rpx;
	background-color: #f5bc32;
	border-radius: 0rpx 0rpx 0rpx 5rpx;
	text-align: center;
	line-height: 44rpx;
	color: #222222;
	font-size: 20rpx;
}
.receiv .address:last-child{
	margin-bottom: 20rpx;
}
.receiv .address{
	width: 678rpx;
	height: 242rpx;
	background-color: #ffffff;
	border-radius: 5rpx;
	margin: 0 auto;
	margin-top: 20rpx;
	padding: 0 18rpx;
	position: relative;
	display: flex;
	flex-direction: column;
}
.receiv .newaddr{
	position: absolute;
	width:100%;
	height: 96rpx;
	background-color: #f5bc32;
	bottom: 0;
	text-align: center;
	line-height: 96rpx;
	color: #222222;
	font-size: 32rpx;
}
.receiv{
	flex: 1;
	background-color: #f8f8f8;
	position: relative;
	padding-bottom: 96rpx;
	display: flex;
	flex-direction: column;
}
</style>
