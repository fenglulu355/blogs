<template>
	<view class="searchresult">
		<Navigation></Navigation>
		<view class="result">
			<view class="resultinp">
				<viea class="resuinp">
					<div>
						<Iconfonts name="icon-sousuo" size="25rpx" colors="#9a9a9a" />
						<input type="text" placeholder="吃喝玩乐随便找" v-model="searchs">
					</div>
				</viea>
				<view class="screen">
					<view class="selects" v-for="(item,index) in selectsa" @click="dropdown(index)">
						<span>{{item.name}}</span>
						<Iconfonts :name="item.icon" size="25rpx" :colors="item.iconcolor" />
					</view>
					<!-- <Imitateselect></Imitateselect> -->
				</view>
			</view>   
			<view class="resultli">
				<scroll-view scroll-top="0" scroll-y="true" class="results" @scrolltolower="scrollbottom">
					<!-- <view class="resultsdiv" @click="hous">
						<view class="resuleft">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						</view>
						<view class="resuright">
							<view class="resurone">
								<view class="resuroneleft">
									隔壁老王菜店
								</view>
								<view class="resuroneright">
									<div>订</div>
									<div>订</div>
									<div>订</div>
								</view>
							</view>
							<view class="resurtow">
								<view class="resura">
									<Iconfonts name="icon-canju" size="25rpx" colors="#f0cf26" />
									<div>人均￥75 菜场</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
									<div>营业时间 6:00-20:30</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-dizhi" size="25rpx" colors="#f0cf26" />
									<div>营业时间 6:00-20:30</div>
									<p>{{dayu}}50m</p>
								</view>
							</view>
							<view class="resurthree">
								<view class="resurlabol">
									<div>减</div>
									<span>满200减30</span>
								</view>
							</view>
						</view>
					</view> -->
					<view class="resultsdiv" v-if="classshop[index].id" v-for="(item,index) in page" @click="boardlod(classshop[index].id)">
						<view class="resuleft">
							<image mode="widthFix" :src="classshop[index].logo"></image>
						</view>
						<view class="resuright">
							<view class="resurone">
								<view class="resuroneleft">
									{{classshop[index].store_name}}
								</view>
								<view class="resuroneright">
									<div v-for="items in classshop[index].attr">{{items}}</div>
								</view>
							</view>
							<view class="resurtow">
								<view class="resura">
									<Iconfonts name="icon-canju" size="25rpx" colors="#f0cf26" />
									<div>人均￥{{classshop[index].rj_price}}</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
									<div>营业时间 {{classshop[index].yytime}}</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-dizhi" size="25rpx" colors="#f0cf26" />
									<div>{{classshop[index].address}}</div>
									<p>{{dayu}}{{classshop[index].distance}}</p>
								</view>
							</view>
							<view class="resurthree" v-if="classshop[index].activ == 1">
								<view class="resurlabol" v-if="classshop[index].activ_j" v-for="itemsa in classshop[index].activ_j">
									<div>减</div>
									<span>{{itemsa}}</span>
								</view>
								<view class="resurlabol" v-if="classshop[index].activ_t" v-for="itemsa in classshop[index].activ_t">
									<div>团</div>
									<span>{{itemsa}}</span>
								</view>
							</view>
						</view>
					</view>
				</scroll-view>
				<view class="resuMask" v-for="(item,index) in selectsa" :style="'display:'+ item.display">
					<view>
						<view class="maskfood" v-if="item.sty == 'food'">
							<view class="maskli" v-for="(item,index) in masklis" @click="maska(item.id,item.name)">{{item.name}}</view>
						</view>
						<view class="maskcity" v-if="item.sty == 'city'">
							<view class="maskoneli">
								<view class="maskonelis" v-for="(item,indexs) in addrlist" @click="maskaddr(indexs)">
									<div :style="'color:'+ item.color">{{item.name}}</div>
									<Iconfonts name="icon-you" size="25rpx" colors="#cccccc" />
								</view>
							</view>
							<!-- <view class="maskonelia" v-for="item in maskcity" v-if="item.static">
								<view class="maskonelis" v-for="(items,indexa) in item.addr" @click="maskliaddr(items)">
									{{items.name}}
								</view>
							</view> -->
						</view>
						<view class="maskfood" v-if="item.sty == 'sort'">
							<view class="maskli" v-for="(item,index) in sort" @click="maskasort(index)">{{item.name}}</view>
						</view>
						<view class="maskscreen" v-if="item.sty == 'screen'">
							<view class="masklitop" v-for="(item,index) in maskscreens">
								<view class="masktitle">
									{{item.name}}
								</view>
								<view class="maskdetail">
									<div v-for="(items,indexs) in item.child" @click="setmaskcolor(index,indexs)" :style="'color:'+items.color+';background-color:'+ items.background">{{items.name}}</div>
								</view>
							</view>
							<view class="masklibottom">
								<div>重置</div>
								<div style="color:#f5bc32" @click="outdrow">完成</div>
							</view>
						</view>
					</view>
					<view class="konbottom" @click="outdrow">

					</view>

				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	// import Imitateselect from '../../components/imitateselect.vue'
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				// resumask:,
				dayu: '>',
				xiaoyu: "<",
				searchs: '',
				selectsa: [{
						name: '全部',
						icon: "icon-xia",
						iconcolor: '#cccccc',
						istop: false,
						display: 'none',
						sty: 'food'
					},
					{
						name: '全城',
						icon: "icon-xia",
						iconcolor: '#cccccc',
						istop: false,
						display: 'none',
						sty: 'city'
					},
					{
						name: '智能排序',
						icon: "icon-xia",
						iconcolor: '#cccccc',
						istop: false,
						display: 'none',
						sty: 'sort'
					},
					{
						name: '筛选',
						icon: "icon-xia",
						iconcolor: '#cccccc',
						istop: false,
						display: 'none',
						sty: 'screen'
					}
				],
				sort: [{
					name: '智能排序'
				}, {
					name: '评价最高'
				}, {
					name: '人气最高'
				}, {
					name: '离我最近'
				}],
				bashurl: '',
				page: 8,
				shopid: '',
				shopli: []
			}
		},
		onShow: function() {
			// this.bashurl = getApp().globalData.bashurl;
			// this.Location = getApp().globalData.Location;
		},
		computed: {
			...mapState(['classshop', 'masklis', 'addrlist', 'maskscreens', 'addr', 'location',"bashurl"])
		},
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
			console.log(option.id,"id");
		
			this.shopid = option.id;
			this.getaddrli();
		},
		methods: {
			//滚动到底部触发
			...mapActions(['getclassshop', 'getaddrli']),
			...mapMutations(['setaddrlist', 'setmaskcolors', 'setsort']),
			setmaskcolor: function(a, b) {
				this.setmaskcolors({
					a: a,
					b: b
				});
			},
			scrollbottom: function() {
				uni.showLoading({
					title: '加载中...'
				});
				let i = this.page
				i = i + 8;
				this.page = i;
				setTimeout(function() {
					uni.hideLoading();
				}, 500)
				// console.log(i);
			},
			outdrow: function() {
				let arr = this.selectsa;
				for (let i in arr) {
					arr[i].icon = "icon-xia"
					arr[i].iconcolor = "#cccccc"
					arr[i].istop = false
					arr[i].display = 'none'
				}
			},
			dropdown: function(e) {
				let arr = this.selectsa;
				if (arr[e].istop == false) {
					for (let i in arr) {
						arr[i].icon = "icon-xia"
						arr[i].iconcolor = "#cccccc"
						arr[i].istop = false
						arr[i].display = 'none'
					}
					arr[e].icon = 'icon-shang'
					arr[e].iconcolor = '#f5bc32'
					arr[e].istop = true
					arr[e].display = 'flex'
				} else {
					for (let i in arr) {
						arr[i].icon = "icon-xia"
						arr[i].iconcolor = "#cccccc"
						arr[i].istop = false
						arr[i].display = 'none'
					}
					arr[e].icon = 'icon-xia'
					arr[e].iconcolor = '#cccccc'
					arr[e].istop = false
					arr[e].display = 'none'
				}
				// console.log(arr[e].istop);
			},
			maska: function(e, a) {
				// let arr = this.masklis;
				let arr1 = this.selectsa;
				arr1[0].name = a;
				this.selectsa = arr1;
				if (e) {
					this.getclassshop({
						id: this.shopid,
						childid: e
					});
				} else {
					this.getclassshop({
						id: this.shopid
					});
				}
				this.outdrow()
				console.log(e);
			},
			maskaddr: function(e) {
				let arr = this.addr;
				let obj = this.addrlist;
				console.log(obj[e].name);
				let arr1 = this.selectsa;
				arr1[1].name = obj[e].name;
				this.selectsa = arr1;
				if (obj[e].name == '附近') {
					this.getclassshop({
						id: this.shopid
					});
				} else {
					let str = ''
					for (let i in arr) {
						for (let j in arr[i].child) {
							for (let k in arr[i].child[j].child) {
								if (obj[e].name == arr[i].child[j].child[k].name) {
									str = arr[i].name + arr[i].child[j].name + arr[i].child[j].child[k].name
								}
							}
						}
					}
					// console.log(str);
					uni.request({
						url:`${this.bashurl}/index/Seller/index`, //仅为示例，并非真实接口地址。
						method: 'POST',
						data: {
							pagesize: 6,
							pid:0,
							page:1,
							
							lat: 30.688220909446,
							lng:104.09138294256
						},
						success: (res) => {
							console.log(res,"549873541164687")
							this.getclassshop({
								id: this.shopid,
								addr: res.data.result.location
							});
							// console.log(res.data.result.location);
						}
					});
				}

				this.outdrow()
				this.setaddrlist(e)
			},
			maskliaddr: function(e) {
				this.outdrow()
				console.log(e);
			},
			maskasort: function(e) {
				this.outdrow()
				this.page = 8;
				let arr = this.selectsa;
				let arr1 = this.sort;
				arr[2].name = arr1[e].name;
				this.selectsa = arr;
				if (e == 0) {
					this.getclassshop({
						id: this.shopid
					});
				} else if (e == 3) {
					this.getclassshop({
						id: this.shopid
					});
				} else {
					this.setsort(e)
				}
				// console.log(e);
			},
			boardlod: function(e) {
				// console.log(e);
				if (this.shopid == 5) {
					uni.navigateTo({
						url: '../housing/housing'
					});
				} else {
					uni.navigateTo({
						url: `../Boardlodging/Boardlodging?id=${e}`
					});
				}

				// console.log(e);
			}
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.konbottom {
		flex: 1;
	}

	.searchresult .result .resultli .resuMask .maskscreen .masklibottom div {
		width: 50%;
		border-right: 1rpx solid #f2f2f2;
		text-align: center;
		line-height: 80rpx;
		font-size: 24rpx;
		color: #222222;
	}

	.searchresult .result .resultli .resuMask .maskscreen .masklibottom {
		display: flex;
		height: 80rpx;
		border-top: 1rpx solid #f2f2f2;
	}

	.searchresult .result .resultli .resuMask .maskscreen .masklitop .maskdetail div {
		height: 50rpx;
		border-radius: 30rpx;
		padding: 0 35rpx;
		color: "#222222";
		font-size: 24rpx;
		line-height: 50rpx;
		text-align: center;
		background-color: #efefef;
		margin: 15rpx;
	}

	.searchresult .result .resultli .resuMask .maskscreen .masklitop .maskdetail {
		display: flex;
		flex-wrap: wrap;
	}

	.searchresult .result .resultli .resuMask .maskscreen .masklitop .masktitle {
		color: "#a1a1a1";
		font-size: 24rpx;
		height: 70rpx;
		line-height: 70rpx;
	}

	.searchresult .result .resultli .resuMask .maskscreen .masklitop {
		padding: 15rpx 35rpx;
	}

	.searchresult .result .resultli .resuMask .maskscreen {
		max-height: 700rpx;
		overflow: auto;
		background-color: #fff;
		border-top: 1rpx solid #f8f8f8;
	}

	.searchresult .result .resultli .resuMask .maskcity .maskonelia .maskonelis {
		height: 72rpx;
		line-height: 72rpx;
		color: #222222;
		font-size: 24rpx;
		display: flex;
		justify-content: space-between;
	}

	.searchresult .result .resultli .resuMask .maskcity .maskonelia {
		flex: 1;
		overflow: auto;
		display: flex;
		flex-direction: column;
	}

	.searchresult .result .resultli .resuMask .maskcity .maskoneli .maskonelis {
		width: 250rpx;
		height: 72rpx;
		line-height: 72rpx;
		color: #222222;
		font-size: 24rpx;
		display: flex;
		justify-content: space-between;
	}

	.searchresult .result .resultli .resuMask .maskcity .maskoneli {
		width: 250rpx;
		overflow: auto;
		margin-right: 50rpx;
	}

	.searchresult .result .resultli .resuMask .maskcity {
		padding: 25rpx 36rpx;
		max-height: 700rpx;
		/* overflow: auto; */
		background-color: #fff;
		border-top: 1rpx solid #f8f8f8;
		display: flex;
	}

	.searchresult .result .resultli .resuMask .maskfood .maskli {
		height: 72rpx;
		line-height: 72rpx;
		color: #222222;
		font-size: 24rpx;
	}

	.searchresult .result .resultli .resuMask .maskfood {
		padding: 25rpx 48rpx;
		max-height: 700rpx;
		overflow: auto;
		background-color: #fff;
		border-top: 1rpx solid #f8f8f8;
	}

	.searchresult .result .resultli .resuMask {
		position: fixed;
		top: 324rpx;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
		z-index: 2;
		display: flex;
		flex-direction: column;
		/* display: none; */
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurthree .resurlabol span {
		color: #666666;
		font-size: 24rpx;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurthree .resurlabol div {
		width: 24rpx;
		height: 24rpx;
		background-color: #ff643a;
		border-radius: 3rpx;
		color: #ffffff;
		font-size: 20rpx;
		text-align: center;
		line-height: 24rpx;
		margin: auto 0;
		margin-right: 12rpx;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurthree .resurlabol {
		display: flex;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurthree {
		padding: 20rpx 0;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurtow .resura Iconfonts {
		margin-right: 10rpx;
		line-height: 24rpx;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurtow .resura p {
		margin: 0;
		color: #666666;
		font-size: 24rpx;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurtow .resura div {
		color: #666666;
		font-size: 24rpx;
		margin-right: 24rpx;
		flex: 1;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurtow .resura:last-child {
		margin: 0;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurtow .resura {
		display: flex;
		justify-content: space-between;
		margin-bottom: 12rpx;

	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurtow {
		display: flex;
		flex-direction: column;
		border-bottom: 1rpx solid #f2f2f2;
		padding: 22rpx 0;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurone .resuroneright div {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #23c88c;
		color: #23c88c;
		font-size: 24rpx;
		text-align: center;
		line-height: 34rpx;
		margin-left: 10rpx;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurone .resuroneright {
		display: flex;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurone .resuroneleft {
		flex: 1;
		color: #222222;
		font-size: 28rpx;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright .resurone {
		display: flex;
		justify-content: space-between;
	}

	.searchresult .result .resultli .results .resultsdiv .resuright {
		flex: 1;
	}

	.searchresult .result .resultli .results .resultsdiv .resuleft image {
		width: 100%;
	}

	.searchresult .result .resultli .results .resultsdiv .resuleft {
		width: 120rpx;
		height: 120rpx;
		border-radius: 5rpx;
		margin-right: 20rpx;
		overflow: hidden;
	}

	.searchresult .result .resultli .results .resultsdiv:last-child {
		margin-bottom: 10rpx;
	}

	.searchresult .result .resultli .results .resultsdiv {
		margin-top: 10rpx;
		padding: 18rpx;
		display: flex;
		background-color: #fff;
		flex-shrink: 0;
	}

	.searchresult .result .resultli .results {
		height: 100%;
		overflow: auto;
		display: flex;
		flex-direction: column;
		/* padding-bottom: 10rpx; */
	}

	.searchresult .result .resultli {
		flex: 1;
		position: relative;
		overflow: auto;
	}

	.searchresult .result .resultinp .screen .selects Iconfonts {
		margin: auto 0;
		line-height: 80rpx;
	}

	.searchresult .result .resultinp .screen .selects span {
		color: #666666;
		font-size: 24rpx;
		margin: auto 0;
		margin-right: 8rpx;
	}

	.searchresult .result .resultinp .screen .selects {
		display: flex;
		justify-content: center;
	}

	.searchresult .result .resultinp .screen {
		height: 90rpx;
		background-color: #fff;
		display: flex;
		justify-content: space-around
	}

	.searchresult .result .resultinp .resuinp div input {
		color: #999999;
		font-size: 24rpx;
		line-height: 60rpx;
		margin: auto 0;
		flex: 1;
	}

	.searchresult .result .resultinp .resuinp div Iconfonts {
		margin: auto 0;
		margin-right: 10rpx;
		display: flex;
	}

	.searchresult .result .resultinp .resuinp div {
		margin: auto 0;
		width: 654rpx;
		height: 60rpx;
		background-color: #efefef;
		border-radius: 30rpx;
		padding: 0 30rpx;
		display: flex;
	}

	.searchresult .result .resultinp .resuinp {
		height: 86rpx;
		display: flex;
		justify-content: center;
		border-bottom: 1rpx solid #f2f2f2;
		background-color: #fff;
	}

	.searchresult .result {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.searchresult {
		height: 100%;
		display: flex;
		flex-direction: column;
		overflow: hidden;
	}
</style>
