<template>
	<view class="leavpag">
		<Navigation></Navigation>
		<view class="leaving">
			<view class="leavtitle">
				请选择您的反馈问题类型（必选）
			</view>
			<view class="leavcontent">
				<view class="leaclabol">
					<div v-for="item in 5">投诉商家</div>
				</view>
				<view class="leactext">
					<textarea fixed="true" placeholder-style="color:#999999" maxlength="400" v-model="leactxt" @input="textare" placeholder="说点什么吧..."/>
					<div>{{txtlength}}/400</div>
				</view>
				<view class="leacimg">
					<view class="imgli">
						<div @click="addimg"><image mode="widthFix" src="../../static/images/jia.png"></image></div>
						<view v-if="imageli == ''">
							
						</view>
						<view class="imgone" v-else v-for="item in imageli">
							<image mode="widthFix" :src="item"></image>
						</view>
					</view>
					<div>最多上传9张</div>
				</view>
			</view>
			<view class="Contact">
				<div>联系方式</div>
				<div>156 666 666</div>
			</view>
			<view class="leacsub">
				提交反馈
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				leactxt:'',
				txtlength:0,
				imageli:''
			}
		},
		methods: {
			textare:function(){
				this.txtlength = this.leactxt.length
				// console.log(this.leactxt.length)
			},
			addimg:function(){
				uni.chooseImage({
				    count: 9, //默认9
				    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				    sourceType: ['album'], //从相册选择
				    success: (res)=> {
						this.imageli = res.tempFilePaths
				        console.log(this.imageli);
				    }
				});
			}
		},
		components:{
			Navigation
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.leaving .leacsub{
	margin: 45rpx auto;
	width: 400rpx;
	height: 80rpx;
	background-color: #f5bc32;
	border-radius: 40rpx;
	color: #222222;
	font-size: 28rpx;
	text-align: center;
	line-height: 80rpx;
}
.leaving .Contact div:last-child{
	color: #222222;
	font-size: 30rpx;
	margin: auto 0;
}
.leaving .Contact div:first-child{
	color: #999999;
	font-size: 24rpx;
	margin: auto 0;
	margin-right: 50rpx;
}
.leaving .Contact{
	margin: 20rpx 0;
	height: 89rpx;
	background-color: #ffffff;
	border-radius: 4rpx;
	padding: 0 18rpx;
	display: flex;
}
.leaving .leavcontent .leacimg .imgli .imgone image{
	width: 100%;
}
.leaving .leavcontent .leacimg .imgli .imgone{
	width: 100rpx;
	height: 100rpx;
	margin-right: 12rpx;
	margin-bottom: 15rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
}
.leaving .leavcontent .leacimg .imgli{
	display: flex;
	flex-wrap: wrap;
}
.leaving .leavcontent .leacimg div:last-child{
	color: #999999;
	font-size: 24rpx;
}
.leaving .leavcontent .leacimg div:first-child image{
	width: 100rpx;
}
.leaving .leavcontent .leacimg div:first-child{
	width: 100rpx;
	height: 100rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
	margin-bottom: 15rpx;
	margin-right: 12rpx;
}
.leaving .leavcontent .leacimg{
	margin: 15rpx 18rpx;
}
.leaving .leavcontent .leactext div{
	position: absolute;
	right: 15rpx;
	bottom: 18rpx;
	color: #cccccc;
	font-size: 20rpx;
}
.leaving .leavcontent .leactext textarea{
	width: 100%;
	height: 100%;
}
.leaving .leavcontent .leactext{
	margin: 25rpx auto;
	width: 684rpx;
	height: 324rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
	padding: 18rpx 15rpx;
	color: #999999;
	font-size: 24rpx;
	position: relative;
}
.leaving .leavcontent .leaclabol div{
	margin: 15rpx 18rpx;
	height: 50rpx;
	padding: 0 25rpx;
	border-radius: 25rpx;
	border: solid 1px #e5e5e5;
	color: #999999;
	font-size: 24rpx;
	text-align: center;
	line-height: 50rpx;
}
.leaving .leavcontent .leaclabol {
	display: flex;
	flex-wrap: wrap;
}
.leaving .leavcontent{
	padding: 25rpx 0rpx;
	background-color: #fff;
}
.leaving .leavtitle{
	height: 85rpx;
	color: #666666;
	font-size: 24rpx;
	padding: 0 18rpx;
	line-height: 85rpx;
}
.leaving{
	flex: 1;
	background-color: #f8f8f8;
	overflow: auto;
}
.leavpag{
	height: 100%;
	display: flex;
	flex-direction: column;
}
</style>
