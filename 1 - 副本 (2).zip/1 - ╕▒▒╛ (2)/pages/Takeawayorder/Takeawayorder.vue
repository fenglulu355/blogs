<template>
	<view class="takeawaypage">
		<Navigation></Navigation>
		<view class="takeaway">
			<view class="Deliver">
				<view class="deliverli">
					<view class="txt">
						选择收货地址 {{you}}
					</view>
				</view>
				<view class="deliverli">
					<div>立即送出</div>
					<div>
						<p>大约17:00送达</p>
						<Iconfonts name="icon-you" size="28rpx" colors="#999999" />
					</div>
				</view>
			</view>
			<view class="shopDelivery">
				<view class="shopdelititle">
					<div>嘎嘎鸭卤肉店</div>
					<div>商家配送</div>
				</view>
				<view class="shopdetail">
					<view class="shopdetailli" v-for="item in 5">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<view class="shopdetailright">
							<div>流口水的干锅兔</div>
							<div>x1</div>
						</view>
						<view class="shopdetails">
							￥58
						</view>
					</view>
				</view>
				<view class="shopCost">
					<div>
						<span>包装费</span><span>￥2</span>
					</div>
					<div>
						<span>包装费</span><span>￥2</span>
					</div>
				</view>
				<view class="Discount">
					<div>商家优惠</div>
					<div> -￥10</div>
				</view>
				<view class="Actualpayment">
					<div>实付</div>
					<div>小计￥<span>36.50</span></div>
				</view>
			</view>
			<view class="Remarks">
				<view class="remarksone">
					<div>餐具份数</div>
					<div>
						<p>未选择</p>
						<Iconfonts name="icon-you" size="28rpx" colors="#999999" />
					</div>
				</view>
				<view class="remarksone">
					<div>订单备注</div>
					<div>
						<p>口味、偏好</p>
						<Iconfonts name="icon-you" size="28rpx" colors="#999999" />
					</div>
				</view>
				<view class="remarksone">
					<div>发票信息</div>
					<div>
						<p>请电话联系商家开具发票</p>
					</div>
				</view>
			</view>
			<view class="Totalprice">
				<view class="totals">
					<div>总价<p>￥</p><span>129</span></div>
					<div>已优惠￥0</div>
				</view>
				<view class="pricesub">
					提交订单
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				you: '>'
			}
		},
		methods: {

		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	.Totalprice .pricesub{
		width: 50%;
		background-color: #f5bc32;
		text-align: center;
		line-height: 100rpx;
		color: #222222;
		font-size: 32rpx;
	}
	.Totalprice .totals div:last-child{
		color: #999999;
		font-size: 18rpx;
	}
	.Totalprice .totals div:first-child{
		color: #666666;
		font-size: 24rpx;
		display: flex;
	}
	.Totalprice .totals div:first-child p{
		color: #ff643a;
	}
	.Totalprice .totals div:first-child span{
		color: #ff643a;
		font-size: 32rpx;
		font-weight: bold;
	}
	.Totalprice .totals{
		flex: 1;
		background-color: #fff;
		display: flex;
		flex-direction: column;
		justify-content: center;
		padding: 0 18rpx;
	}
	.Totalprice{
		height: 100rpx;
		width: 100%;
		display: flex;
		position: fixed;
		bottom: 0;
	}
	.Remarks .remarksone div:last-child Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.Remarks .remarksone div:last-child p{
		margin: auto 0;
		color: #999999;
		font-size: 24rpx;
		margin-right: 10rpx;
	}
	.Remarks .remarksone div:last-child{
		display: flex;
		margin: auto 0;
	}
	.Remarks .remarksone div:first-child{
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}
	.Remarks .remarksone:last-child{
		border: none;
	}
	.Remarks .remarksone{
		height: 102rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}
	.Remarks{
		width: 678rpx;
		padding: 0 18rpx;
		background-color: #ffffff;
		border-radius: 5rpx;
		margin: 0 auto;
		margin-bottom: 120rpx;
	}
	.Actualpayment div:last-child span{
		color: #222222;
		font-size: 32rpx;
		font-weight: bold;
	}
	.Actualpayment div:last-child{
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}
	.Actualpayment div:first-child{
		color: #999999;
		font-size: 24rpx;
		margin: auto 0;
	}
	.Actualpayment{
		height: 105rpx;
		display: flex;
		justify-content: space-between;
	}
	.Discount div{
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}
	.Discount{
		height: 104rpx;
		display: flex;
		justify-content: space-between;
		border-bottom: 1rpx solid #f2f2f2;
	}
	.takeaway .shopCost div span{
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}
	.takeaway .shopCost div{
		height: 60rpx;
		display: flex;
		justify-content: space-between;
	}
	.takeaway .shopCost{
		border-bottom: 1rpx solid #f2f2f2;
		padding: 20rpx 0;
	}
	.takeaway .shopDelivery .shopdetail .shopdetailli .shopdetails{
		color: #222222;
		font-size: 24rpx;
	}
	.takeaway .shopDelivery .shopdetail .shopdetailli .shopdetailright div{
		color: #222222;
		font-size: 24rpx;
	}
	
	.takeaway .shopDelivery .shopdetail .shopdetailli .shopdetailright{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
	
	.takeaway .shopDelivery .shopdetail .shopdetailli image{
		width: 90rpx;
		height: 90rpx;
		background-color: #f2f2f2;
		border-radius: 5rpx;
		margin-right: 20rpx;
	}
	
	.takeaway .shopDelivery .shopdetail .shopdetailli:last-child{
		margin: 0;
	}
	
	.takeaway .shopDelivery .shopdetail .shopdetailli{
		display: flex;
		margin-bottom: 40rpx;
	}
	
	.takeaway .shopDelivery .shopdetail{
		border-bottom: 1rpx solid #f2f2f2;
		padding: 36rpx 0;
	}
	
	.takeaway .shopDelivery .shopdelititle div:last-child{
		margin: auto 0;
		width: 120rpx;
		height: 50rpx;
		background-color: #fffbe9;
		border-radius: 2rpx;
		color: #222222;
		font-size: 20rpx;
		text-align: center;
		line-height: 50rpx;
	}
	
	.takeaway .shopDelivery .shopdelititle div:first-child{
		color: #666666;
		font-size: 24rpx;
		margin: auto 0;
	}
	
	.takeaway .shopDelivery .shopdelititle{
		height: 96rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.takeaway .shopDelivery {
		width: 678rpx;
		background-color: #ffffff;
		border-radius: 5rpx;
		padding: 0 18rpx;
		margin: 0 auto;
		margin-bottom: 18rpx;
	}

	.takeaway .Deliver .deliverli div:last-child Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.takeaway .Deliver .deliverli div:last-child p {
		margin: auto 0;
		color: #ff643a;
		font-size: 24rpx;
		margin-right: 10rpx;
	}

	.takeaway .Deliver .deliverli div:last-child {
		margin: auto 0;
		display: flex;
	}

	.takeaway .Deliver .deliverli div:first-child {
		margin: auto 0;
		color: #222222;
		font-size: 28rpx;
	}

	.takeaway .Deliver .deliverli .txt {
		margin: auto 0;
		color: #666666;
		font-size: 32rpx;
	}

	.takeaway .Deliver .deliverli {
		height: 112rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.takeaway .Deliver {
		width: 686rpx;
		padding: 0 15rpx;
		background-color: #ffffff;
		border-radius: 5rpx;
		margin: 18rpx auto;
	}

	.takeaway {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
		display: flex;
		flex-direction: column;
	}

	.takeawaypage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
