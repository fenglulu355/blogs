<template>
	<view class="allcommentpage">
		<Navigation></Navigation>
		<view class="comment">
			<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
			<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
				<swiper-item id="1">
					<view class="swipers">
						<view class="commentone" v-for="item in 5">
							<view class="commentlift">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							</view>
							<view class="commentright">
								<view class="commentname">
									<div>流沙包</div>
									<div>2019.03.16</div>
								</view>
								<view class="commentxinxin">
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								</view>
								<view class="commentext">
									<view class="text">味道非常好，好吃得快飞起来了！</view>
									<view class="images">
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									</view>
								</view>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="2">
					<view class="swipers">
						<view class="commentone" v-for="item in 5">
							<view class="commentlift">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							</view>
							<view class="commentright">
								<view class="commentname">
									<div>流沙包</div>
									<div>2019.03.16</div>
								</view>
								<view class="commentxinxin">
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								</view>
								<view class="commentext">
									<view class="text">味道非常好，好吃得快飞起来了！</view>
									<view class="images">
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									</view>
								</view>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="3">
					<view class="swipers">
						<view class="commentone" v-for="item in 5">
							<view class="commentlift">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							</view>
							<view class="commentright">
								<view class="commentname">
									<div>流沙包</div>
									<div>2019.03.16</div>
								</view>
								<view class="commentxinxin">
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								</view>
								<view class="commentext">
									<view class="text">味道非常好，好吃得快飞起来了！</view>
									<view class="images">
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									</view>
								</view>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="4">
					<view class="swipers">
						<view class="commentone" v-for="item in 5">
							<view class="commentlift">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							</view>
							<view class="commentright">
								<view class="commentname">
									<div>流沙包</div>
									<div>2019.03.16</div>
								</view>
								<view class="commentxinxin">
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
									<Iconfonts name="icon-xingxing" size="20rpx" colors="#ffdc28" />
								</view>
								<view class="commentext">
									<view class="text">味道非常好，好吃得快飞起来了！</view>
									<view class="images">
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									</view>
								</view>
							</view>
						</view>
					</view>
				</swiper-item>
			</swiper>
		</view>
	</view>
</template>

<script>
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				TabCur: 0,
				tabList: [{
					name: '全部(145)'
				}, {
					name: '晒图(14)'
				}, {
					name: '低分(64)'
				}, {
					name: '最新(64)'
				}]
			}
		},
		methods: {
			tabChange(index) {
				this.TabCur = index;
			},
			swiperChange(e) {
				this.tabChange(e.detail.current)
			},
		},
		components: {
			Navigation,
			WucTab,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	
	.swipers{
		padding: 30rpx 18rpx;
	}

	.allcommentpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.comment {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.comment .swip {
		flex: 1;
	}

	swiper-item {
		overflow: auto;
	}

	.commentone .commentright .commentext .images image {
		width: 141rpx;
		height: 141rpx;
		background-color: #ffdc28;
		border-radius: 10rpx;
		margin-right: 10rpx;

	}

	.commentone .commentright .commentext .images {
		display: flex;
		flex-wrap: wrap;
	}

	.commentone .commentright .commentext .text {
		color: #2d2d2d;
		font-size: 24rpx;
		margin: 12rpx 0;
	}

	.commentone .commentright .commentext {
		margin: 30rpx 0;
	}

	.commentone .commentright .commentxinxin Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 5rpx;
	}

	.commentone .commentright .commentxinxin {
		display: flex;
		margin: 12rpx 0;
	}

	.commentone .commentright .commentname div:last-child {
		color: #b3b3b3;
		font-size: 24rpx;
	}

	.commentone .commentright .commentname div:first-child {
		color: #2d2d2d;
		font-size: 28rpx;
	}

	.commentone .commentright .commentname {
		display: flex;
		justify-content: space-between;
	}

	.commentone .commentright {
		display: flex;
		flex-direction: column;
		border-bottom: 1rpx solid #f2f2f2;
		flex: 1;
		padding: 10rpx 0;
	}

	.commentone .commentlift image {
		width: 82rpx;
		height: 82rpx;
		border: solid 1rpx #f5f5f5;
		border-radius: 50%;
	}

	.commentone .commentlift {
		margin-right: 20rpx;
	}

	.commentone {
		display: flex;
		margin-bottom: 30rpx;
	}
</style>
