<template>
	<view class="shopnews">
		<Navigation></Navigation>
		<view class="news">
			<div class='notice'>
				<img src="../../static/images/tz.png" alt="">
				<p>关注本城商铺公众号，不错过一个消息</p>
			</div>
			<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
			<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
				<swiper-item id="1">
					<view class="Newnews" @click="chats">
						<view class="newimg"><Iconfonts name="icon-xiaoxi1" size="40rpx" colors="#fff" /></view>
						<view class="newtxt">
							<div>买买买日用百货</div>
							<div>你的订单已发货</div>
						</view>
						<view class="newtime">
							<div>今天 15:20</div>
							<div></div>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="2">
					<view class="Newnews">
						<view class="newimg"><Iconfonts name="icon-xiaoxi1" size="40rpx" colors="#fff" /></view>
						<view class="newtxt">
							<div>买买买日用百货</div>
							<div>你的订单已发货</div>
						</view>
						<view class="newtime">
							<div>今天 15:20</div>
							<div></div>
						</view>
					</view>
				</swiper-item>
			</swiper>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				TabCur: 0,
				tabList: [{
					name: '我的消息'
				}, {
					name: '聊天消息'
				}],
			}
		},
		methods: {
			tabChange(index) {
				this.TabCur = index;
			},
			swiperChange(e) {
				this.tabChange(e.detail.current)
			},
			chats:function(){
				uni.navigateTo({
					url:'../Customer/Customer'
				});
			}
		},
		components: {
			Navigation,
			WucTab,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	
	.Newnews .newtime div{
		color: #999999;
		font-size: 24rpx;
	}
	
	.Newnews .newtime{
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
	
	.Newnews .newtxt div:last-child{
		color: #999999;
		font-size: 24rpx;
	}
	
	.Newnews .newtxt div:first-child{
		color: #222222;
		font-size: 32rpx;
	}
	
	.Newnews .newtxt{
		margin-left: 24rpx;
		flex: 1;
		margin-left: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
	
	.Newnews .newimg Iconfonts{
		margin: auto 0;
	}
	
	.Newnews .newimg{
		width: 80rpx;
		height: 80rpx;
		border-radius: 50%;
		background-color: #ffcc4b;
		display: flex;
		justify-content: center;
	}
	
	.Newnews{
		height: 80rpx;
		background-color: #ffffff;
		margin-top: 18rpx;
		padding: 20rpx 30rpx;
		display: flex;
		justify-content: space-between;
	}
	
	.swip{
		flex: 1;
		overflow: auto;
	}

	.shopnews {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.news {
		background-color: #F8F8F8;
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.notice {
		height: 60rpx;
		background-color: rgba(60, 156, 255, 0.1);
		padding: 0 18rpx;
		display: flex;
	}

	.notice p {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #3c9cff;
		margin: auto 0;
	}

	.notice img {
		width: 26rpx;
		height: 26rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}
	
	.swiper-item{
		overflow: auto;
		display: flex;
		flex-direction: column;
	}
	
	wuc-tab{
		background-color: #fff;
	}
</style>
