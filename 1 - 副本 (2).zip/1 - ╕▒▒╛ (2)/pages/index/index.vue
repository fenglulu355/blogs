<template>
	<view class='conso'>
		<swiper class="swiper" :duration="duration" :current="itemid" @change="scroll">
			<swiper-item id='1'>
				<homes></homes>
			</swiper-item>
			<swiper-item id='2'>
				<News></News>
			</swiper-item>
			<swiper-item id='3'>
				<Mys></Mys>
			</swiper-item>
		</swiper>
		<view class="swiper-list">
			<div @click="qiehuan(0)">
				<image mode="widthFix" :src="src[0]"></image>
				<view>首页</view>
			</div>
			<div @click="qiehuan(1)">
				<image mode="widthFix" :src="src[1]"></image>
				<view>消息</view>
			</div>
			<div @click="qiehuan(2)">
				<image mode="widthFix" :src="src[2]"></image>
				<view>我的</view>
			</div>
		</view>
	</view>


</template>

<script>
	import Homes from '../../components/homes.vue';
	import News from '../../components/news.vue';
	import Mys from '../../components/mys.vue'
	export default {
		data() {
			return {
				duration: 200,
				itemid: 0,
				src: ['../../static/images/index1.png', '../../static/images/new.png', '../../static/images/my.png']
			}
		},
		onLoad() {

		},
		components: {
			Homes,
			News,
			Mys
		},
		methods: {
			qiehuan: function(e) {
				this.itemid = e;
				let arr = this.src;
				this.src = ['../../static/images/index.png', '../../static/images/new.png', '../../static/images/my.png']
				if (e == 0) {
					this.src[0] = '../../static/images/index1.png'
					uni.setNavigationBarTitle({
						title: '商家首页'
					});
					uni.setNavigationBarColor({
						frontColor: '#000000',
						backgroundColor: '#ffc528',
						animation: {
							duration: 0,
							timingFunc: 'easeIn'
						}
					})
				} else if (e == 1) {
					uni.setNavigationBarTitle({
						title: '本城商铺'
					});
					uni.setNavigationBarColor({
						frontColor: '#000000',
						backgroundColor: '#ffffff',
						animation: {
							duration: 0,
							timingFunc: 'easeIn'
						}
					})
					this.src[1] = '../../static/images/new1.png'
				} else if (e == 2) {
					uni.setNavigationBarTitle({
						title: '本城商铺'
					});
					uni.setNavigationBarColor({
						frontColor: '#000000',
						backgroundColor: '#ffffff',
						animation: {
							duration: 0,
							timingFunc: 'easeIn'
						}
					})
					this.src[2] = '../../static/images/my1.png'
				}
			},
			scroll: function(e) {
				let ela = e.detail.current;
				let arr = this.src;
				this.src = ['../../static/images/index.png', '../../static/images/new.png', '../../static/images/my.png']
				if (ela == 0) {
					uni.setNavigationBarTitle({
						title: '商家首页'
					});
					uni.setNavigationBarColor({
						frontColor: '#000000',
						backgroundColor: '#ffc528',
						animation: {
							duration: 0,
							timingFunc: 'easeIn'
						}
					})
					this.src[0] = '../../static/images/index1.png'
				} else if (ela == 1) {
					uni.setNavigationBarTitle({
						title: '本城商铺'
					});
					uni.setNavigationBarColor({
						frontColor: '#000000',
						backgroundColor: '#ffffff',
						animation: {
							duration: 0,
							timingFunc: 'easeIn'
						}
					})
					this.src[1] = '../../static/images/new1.png'
				} else if (ela == 2) {
					uni.setNavigationBarTitle({
						title: '本城商铺'
					});
					uni.setNavigationBarColor({
						frontColor: '#000000',
						backgroundColor: '#ffffff',
						animation: {
							duration: 0,
							timingFunc: 'easeIn'
						}
					})
					this.src[2] = '../../static/images/my1.png'
				}
			}
		}
	}
</script>

<style>
	.conso {
		height: 100%;
	}

	.swiper {
		height: 100%;
	}

	page {
		height: 100%;
		background-color: #f8f8f8;
	}

	.swiper-list div view {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		text-align: center;
	}

	.swiper-list div image {
		width: 40rpx;
		margin: 0 auto;
	}

	.swiper-list div {
		width: 100rpx;
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
	}

	.swiper-list {
		width: 100%;
		height: 100rpx;
		display: flex;
		justify-content: space-around;
		
		background-color: #fff;
		position: fixed;
		bottom: 0;
	}
</style>
