<template>
	<view class="recommendpage">
		<Navigation></Navigation>
		<view class="recommend">
			<view class="recommendtitle">
				商家推荐<span>(12)</span>
			</view>
			<view class="recommendli">
				<view class="recommends" v-for="item in 50">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<view class="recommright">
						<div>休闲卤味风味鸭头</div>
						<div>祖传卤料制作</div>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		components: {
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.recommendpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.recommend .recommendtitle span {
		color: #999999;
		font-size: 24rpx;
	}

	.recommend .recommendtitle {
		height: 80rpx;
		line-height: 80rpx;
		padding: 0 18rpx;
		color: #222222;
		font-size: 28rpx;
	}

	.recommend .recommendli .recommends .recommright div:last-child {
		text-align: center;
		width: 120rpx;
		height: 30rpx;
		background-color: #fef2ee;
		line-height: 30rpx;
		color: #ff683a;
		font-size: 18rpx;
	}

	.recommend .recommendli .recommends .recommright div:first-child {
		color: #222222;
		font-size: 28rpx;
		margin-bottom: 16rpx;
		font-weight: bold;
	}

	.recommend .recommendli .recommends .recommright {
		flex: 1;
	}

	.recommend .recommendli .recommends image {
		width: 160rpx;
		height: 160rpx;
		border-radius: 5rpx;
		margin-right: 20rpx;
	}

	.recommend .recommendli .recommends {
		margin-bottom: 30rpx;
		display: flex;
	}

	.recommend .recommendli {
		display: flex;
		flex-direction: column;
		padding: 0 18rpx;
	}

	.recommend {
		flex: 1;
		overflow: auto;
	}
</style>
