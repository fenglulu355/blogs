<template>
	<view class="releasepage">
		<Navigation></Navigation>
		<view class="release">
			<view class="addimage">
				<view class="add" @click="setimg">
					<Iconfonts name="icon-xiangji" size="60rpx" colors="#3c9cff" />
					<div>添加图片</div>
				</view>
				<view v-for="(item,index) in addimg">
					<view class="oneimg" v-if="index == 0">
						<div>封面</div>
						<image mode="widthFix" :src="item"></image>
					</view>
					<view class="oneimg" v-else>
						<image mode="widthFix" :src="item"></image>
					</view>
				</view>
			</view>
			<view class="describe">
				<view class="describename">
					<input class="uni-input" v-model="descrname" type="text" maxlength="20" placeholder="在此填写宝贝名称，如“OPPO手机”" />
					<span>{{lengths}}</span>
				</view>
				<view class="describetext">
					<textarea placeholder-style="color:#999999" placeholder="在此描述你的宝贝，如品牌、购买渠道、规格、转手原因等"/>
				</view>
				<view class="addr">
					<Iconfonts name="icon-dizhi" size="25rpx" colors="#222222" />
					<div>成都武侯区桐梓林新希望大厦附近</div>
				</view>
			</view>
			<view class="Specifications">
				<view class="specifili">
					<div>分类</div>
					<div>
						<p>分类</p>
						<Iconfonts name="icon-you" size="25rpx" colors="#a6a6a6" />
					</div>
				</view>
				<view class="specifili">
					<div>成色</div>
					<div>
						<p>成色</p>
						<Iconfonts name="icon-you" size="25rpx" colors="#a6a6a6" />
					</div>
				</view>
				<view class="specifili">
					<div>价格</div>
					<div>
						<p>开价</p>
						<Iconfonts name="icon-you" size="25rpx" colors="#a6a6a6" />
					</div>
				</view>
			</view>
			<view class="subs">
				发布
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				addimg:[],
				descrname:'',
				lengths:20
			}
		},
		watch:{
			descrname:function(e){
				this.lengths--
			}
		},
		methods: {
			setimg:function(){
				uni.chooseImage({
				    count: 3, //默认9
				    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				    sourceType: ['album'], //从相册选择
				    success: (res)=> {
						this.addimg = res.tempFilePaths
				    }
				});
			}
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	.subs{
		position: fixed;
		bottom: 0;
		width: 100%;
		height: 98rpx;
		background-color: #3c9cff;
		text-align: center;
		line-height: 98rpx;
		color: #ffffff;
		font-size: 32rpx;
	}
	.release .Specifications .specifili div:last-child Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-left: 12rpx;
	}
	.release .Specifications .specifili div:last-child p{
		margin: auto 0;
		color: #999999;
		font-size: 24rpx;
	}
	.release .Specifications .specifili div:last-child{
		display: flex;
		margin: auto 0;
	}
	.release .Specifications .specifili div:first-child{
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}
	.release .Specifications .specifili{
		display: flex;
		padding: 0 18rpx;
		border-bottom: 1rpx solid #f2f2f2;
		height: 95rpx;
		justify-content: space-between;
	}
	.release .Specifications{
		background-color: #fff;
	}
	.release .describe .addr div{
		color: #999999;
		font-size: 24rpx;
		margin: auto 0;
	}
	.release .describe .addr Iconfonts{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 12rpx;
	}
	.release .describe .addr{
		height: 85rpx;
		display: flex;
	}
	.release .describe .describetext textarea{
		width: 100%;
		height: 100%;
		color: #999999;
		font-size: 24rpx;
	}
	.release .describe .describetext{
		padding: 30rpx 0;
		height: 290rpx;
	}
	.release .describe .describename span{
		margin: auto 0;
		color: #999999;
		font-size: 24rpx;
	}
	.release .describe .describename .uni-input{
		margin: auto 0;
		color: #999999;
		font-size: 24rpx;
		flex: 1;
	}
	.release .describe .describename{
		height: 96rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}
	.release .describe{
		background-color: #ffffff;
		padding: 0 18rpx;
		margin-bottom: 18rpx;
	}
	.release .addimage .oneimg image{
		width: 100%;
	}
	
	.release .addimage .oneimg div {
		position: absolute;
		width: 100%;
		height: 40rpx;
		background-color: #3c9cff;
		opacity: 0.8;
		bottom: 0;
		left: 0;
		text-align: center;
		line-height: 40rpx;
		color: #fffbfb;
		font-size: 28rpx;
		overflow: hidden;
	}

	.release .addimage .oneimg {
		width: 168rpx;
		height: 168rpx;
		background-color: #f8f8f8;
		margin-left: 12rpx;
		position: relative;
	}

	.release .addimage .add div {
		text-align: center;
		color: #222222;
		font-size: 24rpx;
		margin: 0 auto;
		margin-top: 15rpx;
	}

	.release .addimage .add Iconfonts {
		margin: 0 auto;
		display: flex;
		justify-content: center;
	}

	.release .addimage .add {
		width: 168rpx;
		height: 168rpx;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.release .addimage {
		background-color: #ffffff;
		margin: 18rpx 0;
		padding: 18rpx;
		display: flex;
	}

	.release {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100vh;
	}

	.releasepage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
