<template>
	<view class='shophome'>
		<view class='custom'>
			<view class="status_bar">
				<!-- 这里是状态栏 -->
			</view>
			<view class='Navigation'>
				<div>本城商铺</div>
				<div @click="searchs">
					<image mode="widthFix" src="../../static/images/search.png"></image>
					<input type="text" placeholder="吃喝玩乐随便找">
				</div>
			</view>
			<view class="navs">
				<div class='city' @click="locationcity">
					<span>{{location.desc}}</span>
					<div></div>
				</div>
				<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
			</view>
		</view>
		<view class='fixedate'>
			<scroll-view scroll-top="0" scroll-y="true" class="scroll-Y" @scrolltolower="scroll">
				<Seckill></Seckill>
				<div class='mokuai'>
					<Modulars v-for="item in Modularsli" :key="item" :content="item"></Modulars>
					<Second :content="used"></Second>
					<Nearby :nearlis="nearbyshop" :page="page"></Nearby>
				</div>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	import Seckill from '../../components/Seckill.vue';
	import Modulars from '../../components/Modulars.vue';
	import Second from '../../components/second.vue';
	import Nearby from '../../components/nearby.vue';
	import amap from '../../components/demo/utils/amap-wx.js'
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				TabCur: 1,
				addr: '',
				banner: [],
				amapPlugin: null,
				key: '602542b03b0eca67a24e5badc7b34660',
				weather: {
					hasData: false,
					data: []
				},
				Location: {},
				page: 8
			}
		},

		computed: {
			...mapState(['shophome', 'tabList', 'shophomeWheelimg', 'used', 'Modularsli', 'nearbyli', 'nearbyshop', 'location'])
		},
	created() {
		console.log(this.tabList,"a4a16654a5")
	},
		onLoad: function() {
			
			let loca = this.Location;
			this.amapPlugin = new amap.AMapWX({
				key: this.key
			});
			uni.showLoading({
				title: '获取定位中...'
			});
			var that = this;
			var myAmapFun = new amap.AMapWX({
				key: '602542b03b0eca67a24e5badc7b34660'
			});
			myAmapFun.getRegeo({
				success: function(data) {
					//成功回调
					// console.log(data[0]);
					// that.setlocation(data[0]);
					that.getnearbyshop(data[0]);
				},
				fail: function(info) {
					//失败回调
				}
			});
			uni.hideLoading();
		},
		onShow: function() {
			this.getclassification();
			this.getWheel();
		},
		onHide: function() {
			this.page = 8;
			// console.log(111111111111);
		},
		methods: {
			...mapActions(['getclassification', 'getnearbyshop', 'getclassshop']),
			...mapMutations(['settypeclass']),
			scroll: function(e) {
				let i = this.page;
				uni.showLoading({
					title: '加载中...'
				});
				setTimeout(() => {
					i = i + 8;
					this.page = i;
					// console.log(this.page)
					uni.hideLoading();
				}, 1000)
				// let i = this.page;
				// i++;
				// this.page = i;
				// console.log(this.page)
			},
			tabChange(index) {
				// console.log(index)
				if (index == 0) {
					uni.navigateTo({
						url: '../Seckill/Seckill'
					});
					this.TabCur = 1;
				} else if (index == 1) {

				} else if (index == 2) {
					uni.navigateTo({
						url: '../Spelllist/Spelllist'
					});
				} else if (index == 9) {
					uni.navigateTo({
						url: '../secondhandindex/secondhandindex'
					});
				} else {
					this.settypeclass(index);
					this.getclassshop({
						id: this.tabList[index].id
					});
					// console.log(arr[index].id);
				}
				// this.TabCur = index;
			},
			searchs: function() {
				uni.navigateTo({
					url: '../Search/Search'
				});

			},
			locationcity: function() {
				uni.navigateTo({
					url: '../Locationselection/Locationselection'
				});
			}
			// swiperChange(e) {
			// 	this.tabChange(e.detail.current)
			// },
		},
		components: {
			WucTab,
			Seckill,
			Modulars,
			Second,
			Nearby
		},
	}
</script>

<style>
	.shophome .fixedate scroll-view .mokuai {
		padding: 17rpx;
	}

	.shophome .fixedate scroll-view {
		height: 100%;
		background-color: #f8f8f8;
	}

	.shophome .fixedate {
		flex: 1;
		overflow: auto;
	}

	.shophome .custom .navs .city div {
		height: 0;
		width: 0;
		border-bottom: 10rpx solid #efefef;
		border-top: 10rpx solid #000;
		border-left: 10rpx solid #efefef;
		border-right: 10rpx solid #efefef;
		margin-top: 18rpx;
		margin-left: 5rpx;
	}

	.shophome .custom .navs .city span {
		width: 70rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin: auto 0;
	}


	.shophome .custom .navs .city {
		/* width: 100rpx; */
		padding: 0 15rpx;
		height: 40rpx;
		background-color: #efefef;
		border-radius: 20rpx;
		margin: auto 20rpx;
		display: flex;
		justify-content: center;
	}

	.shophome .custom .navs {
		height: 88rpx;
		display: flex;
	}

	.shophome .custom .Navigation div:last-child input {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
		margin: auto 0;
	}

	.shophome .custom .Navigation div:last-child image {
		width: 24rpx;
		margin: auto 0;
		margin-left: 30rpx;
		margin-right: 10rpx;
	}

	.shophome .custom .Navigation div:last-child {
		width: 340rpx;
		height: 64rpx;
		background-color: #efefef;
		border-radius: 32rpx;
		margin: auto 0;
		margin-right: 30rpx;
		display: flex;
	}

	.shophome .custom .Navigation div:first-child {
		font-family: PingFang-SC-Bold;
		font-size: 32rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #000000;
		margin: auto 0;
		margin-right: 30rpx;
	}

	.shophome .custom .Navigation {
		height: 90rpx;
		display: flex;
		padding: 0 16rpx;
		background-color: #fff;
		border-bottom: 1rpx solid #f8f8f8;
	}

	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
	}

	page {
		height: 100vh;
	}

	.shophome {
		height: 100vh;
		display: flex;
		flex-direction: column;
	}
</style>
