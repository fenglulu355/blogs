<template>
	<view class="about">
		<Navigation></Navigation>
		<view class="aboutdetail">
			<view class="abouttop">
				<view class="aboutimg">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				</view>
				<view class="aboutbrief">
					<view class="aboutitle">
						公司简介
					</view>
					<view class="aboutxt">
						 本城商铺小程序是成都本城电子商务有限公司旗下的同城商家与客户端交易平台，于2018年6月上线运营。主要服务是提供吃、穿、住、行、用、旧、花等日常与生活息息相关的商家平台服务。可入住商家没有行业限制，只要入驻将会为你的商铺带来更多的用户群体。
					</view>
				</view>
				<view class="aboutinfo">
					<div>
						<p>客服电话</p>
						<p>028-1111 1111</p>
					</div>
					<div>
						<p>工作时间</p>
						<p>9:00-18:00</p>
					</div>
					<div>
						<p>客服邮箱</p>
						<p>ssss@bcdz.com</p>
					</div>
				</view>
			</view>
			<view class="aboutbottom">
				最终解释权归成都本城电子商务有限公司所有
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		components: {
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	
	.about .aboutdetail .abouttop .aboutinfo div:first-child p:last-child{
		color: #f5bc32;
	}
	
	.about .aboutdetail .abouttop .aboutinfo div:last-child{
		border: none;
	}
	
	.about .aboutdetail .abouttop .aboutinfo div p:last-child{
		color: #4d4d4d;
		font-size: 28rpx;
		margin: 0;
		line-height: 98rpx;
	}
	
	.about .aboutdetail .abouttop .aboutinfo div p:first-child{
		color: #999999;
		font-size: 24rpx;
		margin: 0;
		line-height: 98rpx;
	}
	
	.about .aboutdetail .abouttop .aboutinfo div{
		height: 98rpx;
		display: flex;
		justify-content: space-between;
		border-bottom: 1rpx solid #f2f2f2;
		padding: 0 18rpx;
	}
	
	.about .aboutdetail .abouttop .aboutinfo{
		display: flex;
		flex-direction: column;
	}
	
	.about .aboutdetail .abouttop .aboutbrief .aboutxt{
		color: #222222;
		font-size: 24rpx;
		text-indent: 1rem;
	}
	
	.about .aboutdetail .abouttop .aboutbrief .aboutitle{
		color: #222222;
		font-size: 36rpx;
		font-weight: bold;
		text-align: center;
		margin-bottom: 28rpx;
	}
	
	.about .aboutdetail .abouttop .aboutbrief{
		padding: 0 18rpx;
		margin-bottom: 22rpx;
	}
	
	.about .aboutdetail .abouttop .aboutimg image{
		width: 110rpx;
		height: 110rpx;
		background-color: #000000;
		border-radius: 10rpx;
		margin: auto 0;
	}
	
	.about .aboutdetail .abouttop .aboutimg{
		height: 300rpx;
		display: flex;
		justify-content: center;
	}
	
	.about .aboutdetail .abouttop{
		flex: 1;
	}

	.about .aboutdetail .aboutbottom {
		height: 90rpx;
		background-color: #f7f7f7;
		color: #999999;
		font-size: 24rpx;
		text-align: center;
		line-height: 90rpx;
	}

	.about .aboutdetail {
		flex: 1;
		background-color: #fff;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.about {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
