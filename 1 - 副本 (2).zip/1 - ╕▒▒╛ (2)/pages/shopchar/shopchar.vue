<template>
	<view class="shopchar">
		<view class="char">
			<view class="goods" v-for="item in 10">
				<view class="goodleft">
					<div>
						<radio value="r2" color="#F5BC32" />
					</div>
				</view>
				<view class="goodright">
					<view class="tops">
						<view class="dianpu">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
							<div>童趣玩具专营店</div>
							<Iconfonts name="icon-you" size="30rpx" colors="#999999" />
						</view>
						<view class="miaosha">
							秒杀  距离结束还有24:59:59
						</view>
					</view>
					<view class="bottoms">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<view class="bottomright">
							<view class="goodtitle">儿童大块积木桶装1-2-3-6周岁益智早教婴儿宝宝男女孩木头玩具 </view>
							<view class="Setmeal">全部套装【68块】</view>
							<view class="goodsnum">
								<view class="totals">
									￥128
								</view>
								<view class="nums">
									<div>-</div>
									<div>1</div>
									<div>+</div>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="Settlement">
			<view class="settleleft">
				<label class="radio">
					<radio value="r2" color="#F5BC32" />全选</label>
			</view>
			<view class="settleright">
				<div>合计:￥0</div>
				<div>结算(0)</div>
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		components: {
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.char .goods .goodright .bottoms .bottomright .goodsnum .nums div:last-child {
		border: none;
	}

	.char .goods .goodright .bottoms .bottomright .goodsnum .nums div {
		width: 40rpx;
		border-right: 1rpx solid #bbbbbb;
		text-align: center;
		line-height: 36rpx;
		color: #666666;
		font-size: 22rpx;
	}

	.char .goods .goodright .bottoms .bottomright .goodsnum .nums {
		margin: auto 0;
		display: flex;
		height: 36rpx;
		background-color: #f9f9f9;
		border-radius: 5rpx;
		border: solid 1rpx #bbbbbb;
	}

	.char .goods .goodright .bottoms .bottomright .goodsnum .totals {
		margin: auto 0;
		color: #ff643a;
		font-size: 24rpx;
	}

	.char .goods .goodright .bottoms .bottomright .goodsnum {
		display: flex;
		justify-content: space-between;
	}

	.char .goods .goodright .bottoms .bottomright .Setmeal {
		width: 188rpx;
		height: 40rpx;
		background-color: #f9f9f9;
		border-radius: 5rpx;
		text-align: center;
		line-height: 40rpx;
		color: #999999;
		font-size: 22rpx;
	}

	.char .goods .goodright .bottoms .bottomright .goodtitle {
		color: #000000;
		font-size: 24rpx;
	}

	.char .goods .goodright .bottoms .bottomright {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.char .goods .goodright .bottoms image {
		width: 150rpx;
		height: 150rpx;
		background-color: #ff6501;
		border-radius: 5rpx;
		margin-right: 20rpx;
		flex-shrink: 0;
	}

	.char .goods .goodright .bottoms {
		display: flex;
	}
	.char .goods .goodright .tops .miaosha{
		padding: 0 10rpx;
		height: 31rpx;
		background-color: #ffefeb;
		color: #ff643a;
		font-size: 20rpx;
		text-align: center;
		line-height: 31rpx;
	}

	.char .goods .goodright .tops Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.char .goods .goodright .tops div {
		color: #333333;
		margin: auto 0;
		font-size: 24rpx;
		margin-right: 20rpx;
	}

	.char .goods .goodright .tops image {
		width: 32rpx;
		height: 32rpx;
		background-color: #f5bc32;
		border-radius: 5rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}

	.char .goods .goodright .tops .dianpu {
		display: flex;
	}

	.char .goods .goodright .tops {
		display: flex;
		margin-bottom: 30rpx;
		justify-content: space-between;
	}

	.char .goods .goodright {
		display: flex;
		flex-direction: column;
	}

	.char .goods .goodleft {
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 20rpx;
	}

	.char .goods:last-child {
		margin-bottom: 18rpx;
	}

	.char .goods {
		width: 654rpx;
		height: 224rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 18rpx;
		padding: 25rpx 30rpx;
		display: flex;
	}

	.Settlement .settleright div:last-child {
		width: 150rpx;
		height: 60rpx;
		background-color: #ff643a;
		border-radius: 30rpx;
		color: #ffffff;
		font-size: 24rpx;
		text-align: center;
		line-height: 60rpx;
		margin: auto 0;
	}

	.Settlement .settleright div:first-child {
		color: #ff643a;
		font-size: 24rpx;
		margin: auto 0;
		margin-right: 20rpx;
	}

	.Settlement .settleright {
		display: flex;
		margin: auto 0;
		margin-right: 30rpx;
	}

	.Settlement .settleleft .radio radio {
		margin-right: 10rpx;
	}

	.Settlement .settleleft .radio {
		color: #666666;
		font-size: 24rpx;
	}

	.Settlement .settleleft {
		display: flex;
		margin: auto 0;
		margin-left: 60rpx;
	}

	.Settlement {
		width: 100%;
		height: 90rpx;
		background-color: #ffffff;
		border-bottom: #f8f8f8 solid 1rpx;
		border-top: 1rpx solid #dddddd;
		position: fixed;
		bottom: 0;
		display: flex;
		justify-content: space-between;
	}

	.char {
		flex: 1;
		background-color: #f8f8f8;
		margin-bottom: 92rpx;
		overflow: auto;
	}

	.shopchar {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
