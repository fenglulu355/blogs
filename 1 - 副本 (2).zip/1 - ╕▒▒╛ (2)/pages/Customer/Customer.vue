<template>
	<view class="customer">
		<Navigation></Navigation>
		<view class="chat">
			<scroll-view scroll-y :scroll-into-view="chatid" scroll-with-animation>
				<view :id="'A'+index" v-for="(item,index) in shownews">
					<Chatnews :isme="item.static" :addimg="item.addimg" :txt="item.txt" :img="item.img"></Chatnews>
				</view>
				
				<!-- <Chatnews isme="1" txt="一giao喔里giaogiao~~giao!!" img="../static/images/orders.jpg"></Chatnews> -->
			</scroll-view>
		</view>
		<view class="chatinp">
			<view class="chatadd" @click="addimg">+</view>
			<view class="chattxt"><input type="text" :disabled="isinp" v-model="value" placeholder="请输入您要发送的信息"></view>
			<view class="chatsub" @click="sub">
				<Iconfonts name="icon-emizhifeiji" size="40rpx" colors="#fff" />
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import Chatnews from '../../components/chatnews.vue'
	export default {
		data() {
			return {
				shownews: [],
				value: '',
				addimage:[],
				isinp:false,
				chatid:''
			}
		},
		onShow: function() {
			uni.getStorage({
				key: 'news',
				success:(res)=> {
					this.shownews = res.data;
					this.chatid = 'A'+(res.data.length-1)
					// console.log(res.data);
				}
			});
			this.chatid = 'A'+(this.shownews.length-1);
		},
		methods: {
			addimg:function(){
				uni.chooseImage({
				    count: 6, //默认9
				    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				    sourceType: ['album'], //从相册选择
				    success: (res)=> {
						this.addimage = res.tempFilePaths;
				        console.log(res);
				    }
				});
				console.log(this.shownews);
			},
			times:function(){
				var date = new Date();
				var year = date.getFullYear();
				var month = date.getMonth();
				var day = date.getDate();
				var hour = date.getHours();
				var minute = date.getMinutes();
				var second = date.getSeconds();
				//这样写显示时间在1~9会挤占空间；所以要在1~9的数字前补零;
				if (hour < 10) {
					hour = '0' + hour;
				}
				if (minute < 10) {
					minute = '0' + minute;
				}
				if (second < 10) {
					second = '0' + second;
				}
				var x = date.getDay(); //获取星期
				var time = year + '/' + month + '/' + day + '/' + hour + ':' + minute + ':' + second;
				return time
			},
			sub: function() {
				if(this.value == ''){
					// console.log(this.addimage );
					this.shownews.push({
						img: '../static/images/orders.jpg',
						addimg: this.addimage,
						static: 0,
						time:this.times()
					});
					this.chatid = 'A'+(this.shownews.length-1);
				}else{
					this.shownews.push({
						img: '../static/images/orders.jpg',
						txt: this.value,
						static: 0,
						time:this.times()
					});
					this.value = ''
				}
				this.chatid = 'A'+(this.shownews.length-1)
				uni.setStorage({
				    key: 'news',
				    data: this.shownews,
				    success: function () {
				        // console.log('success');
				    }
				});
				// console.log(this.shownews);
			}
		},
		components: {
			Navigation,
			Iconfonts,
			Chatnews
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.customer .chatinp .chatsub Iconfonts {
		margin: auto 0;
	}
	
	scroll-view{
		height: 100%;
	}

	.customer .chatinp .chatsub {
		width: 128rpx;
		background-color: #f5bc32;
		display: flex;
		justify-content: center;
	}

	.customer .chatinp .chattxt input {
		flex: 1;
		margin: auto 0;
		color: #cccccc;
		font-size: 24rpx;
		margin-left: 1rem;
	}

	.customer .chatinp .chattxt {
		flex: 1;
		display: flex;
	}

	.customer .chatinp .chatadd {
		width: 94rpx;
		border-right: 2rpx solid #f8f8f8;
		font-size: 60rpx;
		font-weight: bold;
		text-align: center;
		line-height: 87rpx;
		color: #f5bc32;
	}

	.customer .chatinp {
		width: 100%;
		height: 87rpx;
		background-color: #ffffff;
		box-shadow: 0rpx 1rpx 20rpx 0rpx rgba(195, 195, 195, 0.35);
		display: flex;
		position: fixed;
		bottom: 0;
	}

	.customer .chat {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
		padding: 50rpx 0rpx;
		padding-bottom: 100rpx;
	}

	.customer {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
