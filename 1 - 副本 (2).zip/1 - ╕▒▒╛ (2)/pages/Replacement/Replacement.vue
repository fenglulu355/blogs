<template>
	<view class="leavpag">
		<Navigation></Navigation>
		<view class="tonzi">
			<Iconfonts name="icon-laba" size="26rpx" colors="#ff643a" />
			<div>遇到售后困难可以联系我们协助沟通！</div>
		</view>
		<view class="leaving">
			<view class="leavtitle">
				请选择您的售后申请类型（必选）
			</view>
			<view class="leavcontent">
				<view class="leaclabol">
					<div>退货</div>
					<div>换货</div>
				</view>
				<view class="Reasontitle">
					退换原因
				</view>
				<view class="reason">
					<div>质量问题</div>
					<radio value="r2" color="#F5BC32"/>
				</view>
				<view class="reason">
					<div>质量问题</div>
					<radio value="r2" color="#F5BC32"/>
				</view>
				<view class="reason">
					<div>质量问题</div>
					<radio value="r2" color="#F5BC32"/>
				</view>
				<view class="leactext">
					<textarea placeholder-style="color:#999999" maxlength="400" v-model="leactxt" @input="textare" placeholder="描述详细的原因更有助于你进行退换哦…"/>
					<div>{{txtlength}}/400</div>
				</view>
				<view class="leacimg">
					<view class="imgli">
						
						<div @click="addimg"><image mode="widthFix" src="../../static/images/jia.png"></image></div>
						<view v-if="imageli == ''">
							
						</view>
						<view class="imgone" v-else v-for="item in imageli">
							<image mode="widthFix" :src="item"></image>
						</view>
					</view>
					<div>最多上传9张</div>
				</view>
			</view>
			<view class="leacsub">
				提交申请
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				leactxt:'',
				txtlength:0,
				imageli:''
			}
		},
		methods: {
			textare:function(){
				this.txtlength = this.leactxt.length
				// console.log(this.leactxt.length)
			},
			addimg:function(){
				uni.chooseImage({
				    count: 9, //默认9
				    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				    sourceType: ['album'], //从相册选择
				    success: (res)=> {
						this.imageli = res.tempFilePaths
				        console.log(this.imageli);
				    }
				});
			}
		},
		components:{
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.reason radio{
	margin: auto 0;
}
.reason div{
	margin: auto 0;
	color: #222222;
	font-size: 24rpx;
}
.reason{
	height: 97rpx;
	margin: 0 18rpx;
	border-bottom: 1rpx solid #f8f8f8;
	display: flex;
	justify-content: space-between;
}
.Reasontitle{
	color: #222222;
	font-size: 28rpx;
	line-height: 70rpx;
	padding: 0 18rpx;
	border-bottom: 1rpx solid #f8f8f8;
}
.tonzi div{
	margin: auto 0;
	color: #ff643a;
	font-size: 20rpx;
}
.tonzi Iconfonts{
	margin: auto 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
	margin-right: 10rpx;
}
.tonzi{
	height: 60rpx;
	padding: 0 18rpx;
	background-color: #f9e9e5;
	display: flex;
	flex-shrink: 0;
}
.leaving .leacsub{
	margin: 45rpx auto;
	width: 400rpx;
	height: 80rpx;
	background-color: #f5bc32;
	border-radius: 40rpx;
	color: #222222;
	font-size: 28rpx;
	text-align: center;
	line-height: 80rpx;
}

.leaving .leavcontent .leacimg .imgli .imgone image{
	width: 100%;
}
.leaving .leavcontent .leacimg .imgli .imgone{
	width: 100rpx;
	height: 100rpx;
	margin-right: 12rpx;
	margin-bottom: 15rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
}
.leaving .leavcontent .leacimg .imgli{
	display: flex;
	flex-wrap: wrap;
}
.leaving .leavcontent .leacimg div:last-child{
	color: #999999;
	font-size: 24rpx;
}
.leaving .leavcontent .leacimg div:first-child image{
	width: 100rpx;
}
.leaving .leavcontent .leacimg div:first-child{
	width: 100rpx;
	height: 100rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
	margin-bottom: 15rpx;
	margin-right: 12rpx;
}
.leaving .leavcontent .leacimg{
	margin: 15rpx 18rpx;
}
.leaving .leavcontent .leactext div{
	position: absolute;
	right: 15rpx;
	bottom: 18rpx;
	color: #cccccc;
	font-size: 20rpx;
}
.leaving .leavcontent .leactext textarea{
	width: 100%;
	height: 100%;
}
.leaving .leavcontent .leactext{
	margin: 25rpx auto;
	width: 684rpx;
	height: 324rpx;
	border-radius: 5rpx;
	border: solid 1rpx #e5e5e5;
	padding: 18rpx 15rpx;
	color: #999999;
	font-size: 24rpx;
	position: relative;
}
.leaving .leavcontent .leaclabol div:last-child{
	border-radius: 25rpx;
	border: solid 1rpx #e5e5e5;
	background-color: #fff;
	color: #999999;
}
.leaving .leavcontent .leaclabol div{
	width: 150rpx;
	height: 50rpx;
	background-color: #f5bc32;
	border-radius: 25rpx;
	color: #222222;
	font-size: 24rpx;
	text-align: center;
	line-height: 50rpx;
	margin-right: 34rpx;
}
.leaving .leavcontent .leaclabol {
	display: flex;
	flex-wrap: wrap;
	padding: 0 18rpx;
}
.leaving .leavcontent{
	padding: 25rpx 0rpx;
	background-color: #fff;
}
.leaving .leavtitle{
	height: 85rpx;
	color: #666666;
	font-size: 24rpx;
	padding: 0 18rpx;
	line-height: 85rpx;
}
.leaving{
	flex: 1;
	background-color: #f8f8f8;
	overflow: auto;
}
.leavpag{
	height: 100%;
	display: flex;
	flex-direction: column;
}
</style>
