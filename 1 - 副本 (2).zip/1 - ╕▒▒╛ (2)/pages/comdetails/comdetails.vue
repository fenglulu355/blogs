<template>
	<view class="comdetails">
		<div class='comswiper'>
			<swiper class="swiper" autoplay="true" interval="5000" duration="300" @change="swiperchange">
				<swiper-item v-for="(item,index) in swiperimg" :key="index">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				</swiper-item>
			</swiper>
			<div class='indicator'>{{nums}}/{{swiperimg.length}}</div>
		</div>
		<div class='cominfo'>
			<div class='cominfoleft'>
				<div class='cominfotop'>
					<div>酸辣土豆丝</div>
					<div>月售55</div>
				</div>
				<div class='cominfobottom'>￥<span>10.6</span></div>
			</div>
			<div class='cominforight'>
				<div>
					<image mode="widthFix" src="../../static/images/zhuanfa.png"></image>
					<span>分享</span>
				</div>
				<div>
					<image mode="widthFix" src="../../static/images/shoucang.png"></image>
					<span>收藏</span>
				</div>
			</div>
		</div>
		<div class='position'>
			<div class='posleft'>
				<image mode="widthFix" src="../../static/images/orders.jpg"></image>
			</div>
			<div class='posright'>
				<div class='Shopname'>
					<div class='name'>嘎嘎鸭(科华店)</div>
					<div class='bq'>
						<div>订</div>
						<div>买</div>
					</div>
				</div>
				<div class='postow'>
					<image mode="widthFix" src="../../static/images/waimai(1)@3x.png"></image>
					<span>人均￥75</span>
					<span>川菜</span>
				</div>
				<div class='postow'>
					<image mode="widthFix" src="../../static/images/shijian@3x.png"></image>
					<span>营业时间 6:00-20:30</span>
				</div>
				<div class='posthree'>
					<image mode="widthFix" src="../../static/images/weizhi(1)@3x.png"></image>
					<div class='addr'>人民南路北段4号</div>
					<div>{{distance}}</div>
				</div>
			</div>
		</div>
		<div class='modify' @click="modifying">修改商品</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				swiperimg: ['../../static/images/orders.jpg', '../../static/images/orders.jpg', '../../static/images/orders.jpg'],
				nums: 1,
				distance: '<50m'
			}
		},
		methods: {
			swiperchange: function(e) {
				this.nums = e.detail.current + 1
				// console.log(e.detail.current);
			},
			modifying:function(){
				uni.navigateTo({
					url: '../Modifying/Modifying'
				});
			}
		}
	}
</script>

<style>
	.modify {
		width: 100%;
		height: 100rpx;
		background-color: #f5bc32;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: bold;
		font-stretch: normal;
		line-height: 100rpx;
		letter-spacing: 0rpx;
		color: #222222;
		text-align: center;
		position: fixed;
		bottom: 0;
	}

	.position .posright .posthree .addr {
		flex: 1;
	}

	.position .posright .posthree div {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.position .posright .posthree image {
		width: 25rpx;
		margin: auto 0;
		margin-right: 12rpx;
	}

	.position .posright .posthree {
		display: flex;
		justify-content: space-between;
	}

	.position .posright .postow span {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin-right: 24rpx;
	}

	.position .posright .postow image {
		width: 25rpx;
		margin: auto 0;
		margin-right: 12rpx;
	}

	.position .posright .postow {
		display: flex;
	}

	.position .posright .Shopname .name {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.position .posright .Shopname .bq div:last-child {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #f5bc32;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		text-align: center;
		line-height: 34rpx;
		color: #f5bc32;
		margin-left: 8rpx;
	}

	.position .posright .Shopname .bq div:first-child {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #23c88c;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		text-align: center;
		line-height: 34rpx;
		color: #23c88c;
	}

	.position .posright .Shopname .bq {
		display: flex;
	}

	.position .posright .Shopname {
		display: flex;
		justify-content: space-between;
	}

	.position .posright {
		flex: 1;
		margin-left: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.position .posleft image {
		width: 100%;
	}

	.position .posleft {
		width: 100rpx;
		height: 100rpx;
	}

	.position {
		margin-top: 20rpx;
		height: 170rpx;
		background-color: #ffffff;
		display: flex;
		padding: 30rpx 20rpx;
	}

	.cominfo .cominforight div span {
		font-family: PingFang-SC-Regular;
		font-size: 22rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.cominfo .cominforight div image {
		width: 37rpx;
		margin-bottom: 10rpx;
	}

	.cominfo .cominforight div:first-child {
		margin-right: 40rpx;
	}

	.cominfo .cominforight div {
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
	}

	.cominfo .cominforight {
		display: flex;
	}

	.cominfo .cominfoleft .cominfobottom span {
		font-size: 32rpx;
	}

	.cominfo .cominfoleft .cominfobottom {
		font-family: PingFang-SC-Bold;
		font-size: 22rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
	}

	.cominfo .cominfoleft .cominfotop div:last-child {
		font-family: PingFang-SC-Medium;
		font-size: 22rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.cominfo .cominfoleft .cominfotop div:first-child {
		font-family: PingFang-SC-Bold;
		font-size: 32rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.cominfo .cominfoleft {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.cominfo {
		height: 144rpx;
		background-color: #ffffff;
		display: flex;
		justify-content: space-between;
		padding: 25rpx 16rpx;
	}

	.indicator {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		text-align: center;
		line-height: 50rpx;
		color: #eeeeee;
		width: 80rpx;
		height: 50rpx;
		background-color: #000000;
		border-radius: 25rpx;
		opacity: 0.4;
		position: absolute;
		z-index: 1;
		bottom: 17rpx;
		right: 17rpx;
	}

	.comswiper .swiper image {
		width: 100%;
	}

	.comswiper .swiper {
		height: 100%;
	}

	.comswiper {
		height: 506rpx;
		position: relative;
	}



	page {
		height: 100%;
		background-color: #f8f8f8;
	}
</style>
