<template>
	<view class="seckillxq">
		<Navigation></Navigation>
		<view class="commodity">
			<view class="commodWheel">
				<swiper class="swiper" autoplay="true" interval="3000" duration="300" @change="wheelsa">
					<swiper-item v-for="(item,index) in wheelimg" :key="item" :style="{backgroundImage: 'url(' + item + ')'}">
						<!-- <image mode="widthFix" :src="item"></image> -->
					</swiper-item>
				</swiper>
				<div class="currents">{{current}}/{{wheelimg.length}}</div>
			</view>
			<view class="Limited">
				<view class="limimg">
					<view class="limtotal">￥<span>299</span></view>
					<view class="limOriginal">
						<div>2人团</div>
						<div>原价699.9</div>
					</view>
				</view>
				<view class="daojishi">
					<view class="djstxt">拼单结束后恢复日常价格</view>
					<view class="tiemout">
						距离拼单结束<span>{{time}}:{{branch}}:{{second}}</span>
					</view>
				</view>
			</view>
			<view class="timeout">
				<view class="timetitle">九阳5L电饭煲煮饭锅升家用大容量智能2多功能3全自动4正品5-6-8人</view>
				<view class="timedate">
					<view class="timedateleft">
						<div>拼单立省￥200.00</div>
						<div>已拼：55件</div>
					</view>
					<view class="timedateright">
						<div>
							<Iconfonts name="icon-fenxiang" size="30rpx" colors="#dddddd" />
							<span>分享</span>
						</div>
						<div>
							<Iconfonts name="icon-xingxing" size="30rpx" colors="#dddddd" />
							<span>收藏</span>
						</div>
					</view>
				</view>
			</view>
			<view class="Choice">
				<view class="choicetitle">2人正在拼单，可直接参与</view>
				<view class="choiceSpell" v-for="item in 2" :key="item">
					<view class="choicespeleft">
						<div style="background-image: url('../../static/images/orders.jpg');"></div>
						<div>心愿春晓</div>
					</view>
					<view class="choicesperight">
						<view class="choleft">
							<div>还差 <span>1人</span> 成功</div>
							<div>剩余00:35:47</div>
						</view>
						<view class="choright">去拼单</view>
					</view>
				</view>
			</view>
			<view class="comment">
				<view class="commentitle">
					<div>用户评论</div>
					<div>全部评论（ 145 条）</div>
				</view>
				<view class="commentlabol">
					<view class="commentlis" v-for="item in 3" :key="item">晒图评价 99</view>
				</view>
				<view class="details">
					<view class="detailsli">
						<view class="userdetail" v-for="item in 3" :key="item">
							<view class="portrait" style="background-image: url('../../static/images/orders.jpg');"></view>
							<view class="usercontent">
								<view class="username">
									<div>流沙包</div>
									<div>2019.03.16</div>
								</view>
								<view class="Stars">
									<Iconfonts name="icon-xingxing" size="20rpx" :colors="item" v-for="item in imgcolor" />
								</view>
								<view class="userComments">
									<div class='usertext'>味道非常好，好吃得快飞起来了！</div>
									<div class='userimg'>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									</div>
								</view>
							</view>
						</view>
					</view>
					<view class="detailMore">查看全部评论{{right}}</view>
				</view>
			</view>
			<view class="Shopowner">
				<view class="shopimg" style="background-image: url('../../static/images/orders.jpg');"></view>
				<view class="shopnames">
					<view class="shoptitle">
						<view class="shopleft">永丰百货(科华店)</view>
						<view class="shopright">
							<div>订</div>
							<div>买</div>
						</view>
					</view>
					<view class="shoptime">
						<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
						<div>营业时间 6:00-20:30</div>
					</view>
					<view class="shopaddr">
						<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
						<div class="addr">人民南路北段4号</div>
						<div>{{left}}50m</div>
					</view>
				</view>
			</view>
			<view class="Commoditydetails">
				<div class='commoditydetailstitle'>
					<div class="comleft">
						<image mode="widthFix" src="../../static/images/zuo.png"></image>
					</div>
					<div class="comdeta">商品详情</div>
					<div class="comleft">
						<image mode="widthFix" src="../../static/images/you.png"></image>
					</div>
				</div>
				<view>详情富文本</view>
			</view>
			<view class="purchase">
				<view class="purleft">
					<div>299</div>
					<div>单独购买</div>
				</view>
				<view class="puright">
					<div>399</div>
					<div>拼单购买</div>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				wheelimg: ['../../static/images/orders.jpg', '../../static/images/orders.jpg', '../../static/images/orders.jpg',
					'../../static/images/orders.jpg'
				],
				current: 1,
				right: '>',
				imgcolor: ['#999999', '#999999', '#999999', '#999999', '#999999'],
				left: '<',
				time: 0,
				branch: 1,
				second: 30
			}
		},
		created: function() {
			let funtime = setInterval(() => {
				let seconds = this.second;
				let branchs = this.branch;
				let times = this.time;
				seconds--;
				if (seconds == 0) {
					if (branchs == 0) {
						if (times == 0) {
							clearInterval(funtime)
						} else {
							times -= 1;
							branchs = 59;
						}
					} else {
						seconds = 59;
						branchs -= 1;
					}
				}
				this.second = seconds;
				this.branch = branchs;
				this.time = times;
			}, 1000)
		},
		methods: {
			wheelsa: function(e) {
				this.current = e.detail.current + 1;
				// console.log(e.detail.current);
			},
			timeup: () => {
				uni.showToast({
					title: '时间到'
				})
			}
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	.seckillxq .commodity .purchase .puright {
		width: 50%;
		height: 100%;
		background-color: #ff643a;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.seckillxq .commodity .purchase .purleft {
		width: 50%;
		height: 100%;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		background-color: #f5bc32;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.seckillxq .commodity .purchase {
		height: 100rpx;
		width: 100%;
		display: flex;
		position: fixed;
		bottom: 0;
	}

	.seckillxq .commodity .Commoditydetails .commoditydetailstitle .comdeta {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin: auto 20rpx;
	}

	.seckillxq .commodity .Commoditydetails .commoditydetailstitle .comleft image {
		width: 100%;
		margin: auto 0;
	}

	.seckillxq .commodity .Commoditydetails .commoditydetailstitle .comleft {
		width: 90rpx;
		margin: auto 0;
		display: flex;
	}

	.seckillxq .commodity .Commoditydetails .commoditydetailstitle {
		height: 84rpx;
		display: flex;
		justify-content: center;
	}

	.seckillxq .commodity .Commoditydetails {
		background-color: #fff;
		margin-bottom: 120rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shopaddr div {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin: auto 0;
	}

	.seckillxq .commodity .Shopowner .shopnames .shopaddr .addr {
		flex: 1;
	}

	.seckillxq .commodity .Shopowner .shopnames .shopaddr Iconfonts {
		margin-right: 15rpx;
		line-height: 22rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shopaddr {
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptime Iconfonts {
		line-height: 22rpx;
		margin-right: 15rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptime div {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin: auto 0;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptime {
		display: flex;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright div {
		text-align: center;
		line-height: 34rpx;
		font-size: 24rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright div:last-child {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #f5bc32;
		color: #f5bc32;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright div:first-child {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #23c88c;
		color: #23c88c;
		font-size: 24rpx;
		margin-right: 10rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright {
		display: flex;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopleft {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle {
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .Shopowner .shopnames {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.seckillxq .commodity .Shopowner .shopimg {
		width: 100rpx;
		height: 100rpx;
		background-color: #dcdcdc;
		border-radius: 5rpx;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
		margin-right: 20rpx;
	}

	.seckillxq .commodity .Shopowner {
		margin: 18rpx 0;
		height: 124rpx;
		background-color: #ffffff;
		padding: 30rpx 18rpx;
		display: flex;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments .userimg image {
		width: 141rpx;
		height: 141rpx;
		border-radius: 10rpx;
		border-radius: 5rpx;
		margin-right: 15rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments .userimg {
		display: flex;
		flex-wrap: wrap;
		margin: 15rpx 0;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments .usertext {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #2d2d2d;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments {
		margin: 15rpx 0;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .Stars Iconfonts {
		line-height: 40rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .Stars {
		display: flex;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .username div:last-child {
		font-size: 24rpx;
		letter-spacing: 0rpx;
		color: #b3b3b3;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .username div:first-child {
		font-size: 28rpx;
		font-weight: bold;
		letter-spacing: 0rpx;
		color: #2d2d2d;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .username {
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent:last-child {
		margin: 0;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent {
		flex: 1;
		border-bottom: 1rpx solid #f8f8f8;
		padding-bottom: 15rpx;
		margin-bottom: 25rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .portrait {
		width: 82rpx;
		height: 82rpx;
		border-radius: 50%;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
		margin-right: 20rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail {
		display: flex;
		margin-top: 20rpx;
	}

	.seckillxq .commodity .comment .details .detailsli {
		display: flex;
		flex-direction: column;
	}

	.seckillxq .commodity .comment .details .detailMore {
		line-height: 84rpx;
		text-align: center;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seckillxq .commodity .comment .details {}

	.seckillxq .commodity .comment .commentlabol .commentlis:last-child {
		margin: 0;
	}

	.seckillxq .commodity .comment .commentlabol .commentlis {
		padding: 0 32rpx;
		height: 50rpx;
		border-radius: 25rpx;
		border: solid 1rpx #cccccc;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		text-align: center;
		line-height: 50rpx;
		margin-right: 30rpx;
	}

	.seckillxq .commodity .comment .commentlabol {
		display: flex;
		margin: 40rpx 0;
	}

	.seckillxq .commodity .comment .commentitle div:last-child {
		color: #999999;
		font-size: 24rpx;
	}

	.seckillxq .commodity .comment .commentitle div:first-child {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seckillxq .commodity .comment .commentitle {
		margin-top: 30rpx;
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .comment {
		background-color: #fff;
		padding: 0 18rpx;
		display: flex;
		flex-direction: column;
	}
	
	.seckillxq .commodity .Choice .choiceSpell .choicesperight .choright{
		width: 118rpx;
		height: 50rpx;
		border-radius: 5rpx;
		border: solid 1rpx #ff643a;
		text-align: center;
		line-height: 50rpx;
		color: #ff643a;
		font-size: 24rpx;
		margin: auto 0;
	}
	
	.seckillxq .commodity .Choice .choiceSpell .choicesperight .choleft div:last-child{
		color: #cccccc;
		font-size: 22rpx;
	}
	
	.seckillxq .commodity .Choice .choiceSpell .choicesperight .choleft div:first-child span{
		color: #ff643a;
	}
	
	.seckillxq .commodity .Choice .choiceSpell .choicesperight .choleft div:first-child{
		color: #222222;
		font-size: 24rpx;
	}
	.seckillxq .commodity .Choice .choiceSpell .choicesperight .choleft{
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-right: 20rpx;
	}
	
	.seckillxq .commodity .Choice .choiceSpell .choicesperight{
		margin: auto 0;
		display: flex;
	}
	
	.seckillxq .commodity .Choice .choiceSpell .choicespeleft div:last-child{
		color: #222222;
		font-size: 24rpx;
		margin: auto 0;
	}

	.seckillxq .commodity .Choice .choiceSpell .choicespeleft div:first-child {
		width: 76rpx;
		height: 76rpx;
		background-color: #000000;
		border-radius: 50%;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
		margin: auto 0;
		margin-right: 20rpx;
	}

	.seckillxq .commodity .Choice .choiceSpell .choicespeleft {
		display: flex;
		margin: auto 0;
	}

	.seckillxq .commodity .Choice .choiceSpell:last-child {
		border: none;
	}

	.seckillxq .commodity .Choice .choiceSpell {
		display: flex;
		justify-content: space-between;
		height: 135rpx;
		border-bottom: 1rpx solid #f2f2f2;
	}

	.seckillxq .commodity .Choice .choicetitle {
		color: #222222;
		font-size: 28rpx;
	}

	.seckillxq .commodity .Choice {
		margin: 17rpx 0;
		background-color: #ffffff;
		display: flex;
		justify-content: space-between;
		flex-direction: column;
		padding: 0rpx 18rpx;
		padding-top: 30rpx;
	}

	.seckillxq .commodity .timeout .timedate .timedateright div:last-child {
		margin: 0;
	}

	.seckillxq .commodity .timeout .timedate .timedateright div {
		display: flex;
		flex-direction: column;
		margin-right: 40rpx;
	}

	.seckillxq .commodity .timeout .timedate .timedateright div span {
		text-align: center;
		color: #666666;
		font-size: 22rpx;
	}

	.seckillxq .commodity .timeout .timedate .timedateright div Iconfonts {
		margin: 0 auto;
	}

	.seckillxq .commodity .timeout .timedate .timedateright {
		display: flex;
	}

	.seckillxq .commodity .timeout .timedate .timedateleft div:last-child {
		color: #999999;
		font-size: 22rpx;
		/* margin: auto 0; */
	}

	.seckillxq .commodity .timeout .timedate .timedateleft div:first-child {
		width: 183rpx;
		height: 31rpx;
		background-color: #ffefeb;
		color: #ff643a;
		font-size: 20rpx;
		text-align: center;
		line-height: 31rpx;
		/* margin: auto 0 */
		;
		margin-right: 18rpx;

	}

	.seckillxq .commodity .timeout .timedate .timedateleft {
		display: flex;
		align-items: flex-end;
	}

	.seckillxq .commodity .timeout .timedate {
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .timeout .timetitle {
		color: #222222;
		font-size: 32rpx;
		font-weight: bold;
	}

	.seckillxq .commodity .timeout {
		/* height: 144rpx; */
		background-color: #ffffff;
		padding: 25rpx 16rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.seckillxq .commodity .Limited .daojishi .tiemout span {
		font-size: 36rpx;
	}

	.seckillxq .commodity .Limited .daojishi .tiemout {
		font-family: PingFang-SC-Regular;
		font-size: 22rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.seckillxq .commodity .Limited .daojishi .djstxt {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #fff;
		text-align: center;
	}

	.seckillxq .commodity .Limited .daojishi {
		margin: auto 0;
		z-index: 2;
		margin-right: 15rpx;
	}

	.seckillxq .commodity .Limited .limimg .limtotal span {
		font-size: 40rpx;
	}

	.seckillxq .commodity .Limited .limimg .limtotal {
		color: #222222;
		font-size: 22rpx;
		font-weight: bold;
		margin: auto 0;
		display: flex;
		align-items: flex-end;
		line-height: 1rpx;
		margin-right: 18rpx;
	}

	.seckillxq .commodity .Limited .limimg .limOriginal div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 22rpx;
		font-weight: normal;
		font-stretch: normal;
		text-decoration: line-through;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.seckillxq .commodity .Limited .limimg .limOriginal div:first-child {
		width: 80rpx;
		height: 30rpx;
		background-color: #ffffff;
		border-radius: 15rpx;
		color: #222222;
		font-size: 22rpx;
		text-align: center;
		line-height: 30rpx;
	}

	.seckillxq .commodity .Limited .limimg .limOriginal {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.seckillxq .commodity .Limited .limimg {
		display: flex;
		margin: auto 0;
		margin-left: 18rpx;
	}

	.seckillxq .commodity .Limited {
		height: 89rpx;
		padding: 5rpx;
		background-color: #f5bc32;
		display: flex;
		justify-content: space-between;
		overflow: hidden;
		position: relative;
	}

	.seckillxq .commodity .commodWheel .currents {
		position: relative;
		width: 80rpx;
		height: 50rpx;
		background-color: #000000;
		border-radius: 25rpx;
		opacity: 0.4;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #eeeeee;
		text-align: center;
		line-height: 50rpx;
		bottom: 68rpx;
		right: -643rpx;
	}

	.seckillxq .commodity .commodWheel .swiper swiper-item {
		background-color: #666666;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
	}

	.seckillxq .commodity .commodWheel .swiper {
		width: 100%;
		height: 100%;
	}

	.seckillxq .commodity .commodWheel {
		height: 500rpx;
		background-color: #ffffff;
		position: relative;
	}

	.seckillxq .commodity {
		flex: 1;
		overflow: auto;
		background-color: #f8f8f8;
	}

	.seckillxq {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100vh;
	}
</style>
