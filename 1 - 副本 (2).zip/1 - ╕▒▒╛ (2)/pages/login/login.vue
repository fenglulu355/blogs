<template>
	<view class='login'>
		<div class='loginlog'>
			<div>
				<image mode="widthFix" src="../../static/images/orders.jpg"></image>
			</div>
			<div>
				<h2>本城商铺</h2>
				<span>身边的本地服务平台</span>
			</div>
		</div>
		<div class='logininp'>
			<div><input type="text" placeholder="请输入你的手机号" v-model="phones"></div>
			<div>
				<input type="text" placeholder="请输入手机验证码" v-model="usercode">
				<view @click="Code">获取</view>
			</div>
		</div>
		<div class='wxlogin' @click="phonelogin">快捷登录</div>
		<button class='wxlogin' open-type="getUserInfo" style='background-color: #09ba07;color: #fff;' @getuserinfo="wxlogin">微信登录</button>
	</view>
</template>

<script>
	import {
		mapState,
		mapActions
	} from 'vuex';
	export default {
		data() {
			return {
				mobile: '',
				bashurl: '',
				usercode: '',
				code: '',
				phones: ''
			}
		},
		created: function() {
		},
		computed: {
			...mapState(['avatarUrl', 'login', 'userName'])
		},
		methods: {
			...mapActions(['loginwx','codes','phonelogins']),
			Code:function () {
				this.codes(this.phones);
			},
			phonelogin: function() {
				uni.login({
					provider: 'weixin',
					success: (loginRes) => {
						this.phonelogins({code:this.usercode,phones:this.phones});
					}
				});
			},
			wxlogin: function(e) {
				console.log(e)
				var data = {
					openid: 1,
					user_nickname: e.detail.userInfo.nickName,
					user_sex: e.detail.userInfo.gender,
					user_address: e.detail.userInfo.country,
					user_image: e.detail.userInfo.avatarUrl,
					iv: e.detail.iv,
					edata: e.detail.encryptedData,
					signature: e.detail.signature,
					method: 'user.wxapplogin2'
				};
				uni.login({
					provider: 'weixin',
					success: (loginRes) => {
						this.loginwx({code:loginRes.code,data:data});
					}
				});
			}
		}
	}
</script>

<style>
	page {
		background-color: #fff;
	}

	.login .wxlogin {
		width: 600rpx;
		height: 90rpx;
		background-color: #ffc528;
		border-radius: 45rpx;
		margin: 0 auto;
		margin-bottom: 40rpx;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		text-align: center;
		font-weight: normal;
		font-stretch: normal;
		line-height: 90rpx;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.login .logininp div input {
		margin: auto 0;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0px;
		color: #c2c2c2;
	}

	.login .logininp div view {
		width: 240rpx;
		height: 72rpx;
		background-color: #f3f3f3;
		border-radius: 36rpx;
		line-height: 72rpx;
		text-align: center;
		font-family: PingFang-SC-Regular;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin: auto 0;
	}

	.login .logininp div {
		height: 110rpx;
		margin-top: 30rpx;
		display: flex;
		border-bottom: 1rpx solid #dbdbdb;
		display: flex;
		justify-content: space-between;
	}

	.login .logininp {
		margin-top: 140rpx;
		margin-bottom: 80rpx;
	}

	.login .loginlog div:last-child span {
		font-family: PangMenZhengDao;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #222222;
	}

	.login .loginlog div:last-child h2 {
		font-family: PangMenZhengDao;
		font-size: 60rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 3rpx;
		color: #222222;
	}

	.login .loginlog div:last-child {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-left: 20rpx;
	}

	.login .loginlog div:first-child image {
		width: 100%;
	}

	.login .loginlog div:first-child {
		width: 96rpx;
		height: 96rpx;
		margin: auto 0;
		border-radius: 50%;
		overflow: hidden;
	}

	.login .loginlog {
		display: flex;
		margin-top: 120rpx;
	}

	.login {
		margin: 0 75rpx;
	}
</style>
