<template>
	<view class="location">
		<Navigation></Navigation>
		<view class="selection">
			<view class="selectop">
				<view class="selecinp">
					<Iconfonts name="icon-sousuo" size="25rpx" colors="#9a9a9a" />
					<input type="text" placeholder="吃喝玩乐随便找" v-model="searchs">
				</view>
				<view class="quxiao">
					取消
				</view>
			</view>
			<view class="selecbottom">
				<scroll-view class="scroll-view_H" scroll-top="0" scroll-y scroll-with-animation @scroll="scroll" :scroll-into-view="scroolid">
					<view class="current">
						<view class="currenposition">
							当前位置：{{location.regeocodeData.addressComponent.city}}
						</view>
						<view class="Locations">
							<div id="map">{{location.desc}}</div>
							<div @click="Location">
								<Iconfonts name="icon-miaozhunjing2" size="21rpx" colors="#f5bc32" />
								<div>重新定位</div>
							</div>
						</view>
					</view>
					<view class="scrollcurr" v-for="item in addrli">
						<view class="scrollone" :id="item.zm">
							{{item.zm}}
						</view>
						<view class="scrolltow" @click="setaddr(items)" v-for="items in item.city">
							{{items.name}}
						</view>
					</view>
				</scroll-view>
			</view>
		</view>
		<view class="Letter">
			<div v-for="item in addrli" @click="Anchor(item.zm)">{{item.zm}}</div>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import amap from '../../components/demo/utils/amap-wx.js'
	// import maps from '../../components/demo/utils/maps.js'
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				amapPlugin: null,
				key: '602542b03b0eca67a24e5badc7b34660',
				scroolid: '',
				weather: {
					hasData: false,
					data: []
				},
			}
		},
		computed: {
			...mapState(['location', 'addrli','addr'])
		},
		onShow: function() {
			this.amapPlugin = new amap.AMapWX({
				key: this.key
			});
			this.getaddrli();
		},
		methods: {
			...mapActions(['getnearbyshop', 'getaddrli']),
			Location: function() {
				uni.showLoading({
					title: '获取定位中...'
				});
				this.amapPlugin.getRegeo({
					success: (data) => {
						this.getnearbyshop(data[0]);
						uni.hideLoading();
					}
				});
			},
			setaddr: function(e) {
				let arr = this.addr;
				console.log(e.name);
				let str = '';
				for (let i in arr) {
					for (let j in arr[i].child) {
						for (let k in arr[i].child[j].child) {
							if(e.name == arr[i].child[j].child[k].name){
								str = arr[i].name + arr[i].child[j].name + arr[i].child[j].child[k].name
							}
						}
					}
				}
				console.log(str);
				uni.request({
					url: 'https://restapi.amap.com/v3/geocode/geo?parameters', //仅为示例，并非真实接口地址。
					method:'GET',
					data:{
						key:'602542b03b0eca67a24e5badc7b34660',
						address:str
					},
					success: (res) => {
						console.log(res.data);
					}
				});
			},
			Anchor: function(e) {
				this.scroolid = e
				// console.log(e);
				// console.log(this.scroolid);
			},
			scroll: function(e) {

			}
		},
		components: {
			Navigation,
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	.scroll-view_H {
		height: 100%;
	}

	.scrollcurr .scrolltow {
		padding: 0 18rpx;
		height: 80rpx;
		line-height: 80rpx;
		background-color: #ffffff;
		margin-bottom: 1rpx;
		font-size: 24rpx;
		color: #666666;
	}

	.scrollcurr .scrollone {
		height: 80rpx;
		line-height: 80rpx;
		width: 100%;
		font-size: 25rpx;
		color: #666666;
		padding: 0 18rpx;
	}

	.Letter div {
		width: 50rpx;
		text-align: center;
		color: #999999;
		font-size: 24rpx;
		line-height: 40rpx;
	}

	.Letter {
		position: fixed;
		top: 250rpx;
		right: 10rpx;
	}

	.current .Locations div:last-child {
		display: flex;
	}

	.current .Locations div Iconfonts {
		margin-right: 15rpx;
	}

	.current .Locations div {
		color: #f5bc32;
		font-size: 28rpx;
		margin: auto 0;
	}

	.current .Locations {
		height: 80rpx;
		background-color: #ffffff;
		display: flex;
		justify-content: space-between;
		padding: 0 18rpx;
		padding-right: 70rpx;
	}

	.current .currenposition {
		height: 80rpx;
		line-height: 80rpx;
		color: #666666;
		font-size: 24rpx;
		padding: 0 18rpx;
	}

	/* .location .selection .selecbottom .current {
		padding: 0 18rpx;
	} */

	.location .selection .selecbottom {
		flex: 1;
		overflow: auto;
	}

	.location .selection .selectop .quxiao {
		margin: auto 0;
		margin-right: 15rpx;
		color: #222222;
		font-size: 28rpx;
	}

	.location .selection .selectop .selecinp input {
		margin: auto 0;
		margin-left: 10rpx;
		color: #999999;
		font-size: 24rpx;
	}

	.location .selection .selectop .selecinp {
		width: 560rpx;
		height: 60rpx;
		background-color: #efefef;
		border-radius: 30rpx;
		padding: 0 30rpx;
		display: flex;
		margin: auto 0;
	}

	.location .selection .selectop {
		height: 85rpx;
		background-color: #fff;
		padding: 0 18rpx;
		display: flex;
		justify-content: space-between;
	}

	.location .selection {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.location {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
