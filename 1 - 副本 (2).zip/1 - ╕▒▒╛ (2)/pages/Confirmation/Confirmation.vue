<template>
	<view class="orderdeliver">
		<div class='LogisticsChoice'>
			<div class='logistitle'>发货选择</div>
			<div class='logistxt'>
				<div>配送方式</div>
				<div class='logist'>物流配送</div>
				<div><img src="../../static/images/right.png" alt=""></div>
			</div>
			<div class='logistxt'>
				<div>快递公司</div>
				<div class='logist logistkd'>请选择快递公司</div>
				<div><img src="../../static/images/right.png" alt=""></div>
			</div>
			<div class='logistxt'>
				<div>快递单号</div>
				<div class='logist logistkd'><input type="text" name="" id="" placeholder="请输入或扫描快递单号"></div>
				<div style="width: 40rpx;height: 40rpx;" @click="Sweepcode"><img src="../../static/images/saomiao.png" alt=""></div>
			</div>
		</div>
		<div class='logistics'>
			<div class='logs'>
				<div class="logtxt">收货人信息</div>
			</div>
			<div class='information'>
				<div class='infoimg'><img src="../../static/images/dv.png" alt=""></div>
				<div class='infotxt'>
					<div>杨YY 156 6666 6666</div>
					<div>地址：四川省成都市武侯区人民南路北段新希望大厦7楼704室</div>
				</div>
			</div>
			<div class='message'>
				<div class='messimg'><img src="../../static/images/xx.png" alt=""></div>
				<div class='messtxt'>
					<div>买家留言</div>
					<div>需要包装好些</div>
				</div>
			</div>
		</div>
		<div class='briefintroduction'>
			<div class='briefconfir'>订单信息</div>
			<div class='briertow'>
				<div class='brierimg'>
					<img src="../../static/images/orders.jpg" alt="">
				</div>
				<div class='briertxt'>
					<div class='briertitle'>
						<div>休闲卤味风味鸭头</div>
						<div>规格：1份</div>
					</div>
					<div class='brierbottom'>
						<div>￥9.90</div>
						<div>x1</div>
					</div>
				</div>
			</div>
			<div class='payments'>
				<div>订单编号：21313124524</div>
				<div>下单时间：2019-06-16 18:59:59</div>
			</div>
			<div class='payments'>
				<div>付款方式：微信支付</div>
				<div>付款时间：2019-06-16 19:02:30</div>
			</div>
			<div class='confirPrice'>
				<div class='confirsa'>
					<div>商品总额</div>
					<div>￥9.90</div>
				</div>
				<div class='confirsa'>
					<div>运费</div>
					<div>+￥5</div>
				</div>
				<div class='confirsa'>
					<div>使用优惠券</div>
					<div>-￥5</div>
				</div>
			</div>
			<div class='totals'>
				<div></div>
				<div class='Immediatedelivery'>立即发货</div>
				<div>实付款<span>￥9.90</span></div>
			</div>

		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
            customConduct(){
                console.log("ssssss")
            }
		}
	}
</script>

<style>
	page {
		height: 100%;
	}

	.briersa {
		border-bottom: 1rpx solid #f2f2f2;
	}

	.orderdeliver .briefintroduction .totals .Immediatedelivery {
		width: 250rpx;
		height: 70rpx;
		background-color: #ff683a;
		box-shadow: 0rpx 5rpx 20rpx 0rpx #ff683a;
		border-radius: 35rpx;
		font-family: PingFang-SC-Bold;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 70rpx;
		position: absolute;
		left: 0;
		right: 0;
		top: 0;
		bottom: 0;
		margin:auto;
	}

	.orderdeliver .briefintroduction .totals div:last-child span {
		color: #ff643a;
	}

	.orderdeliver .briefintroduction .totals div:last-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.orderdeliver .briefintroduction .totals {
		display: flex;
		justify-content: flex-end;
		position: relative;
		padding: 50rpx 0;
	}

	.orderdeliver .briefintroduction .confirPrice .confirsa div:last-child {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
	}

	.orderdeliver .briefintroduction .confirPrice .confirsa div:first-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.orderdeliver .briefintroduction .confirPrice .confirsa {
		display: flex;
		justify-content: space-between;
		margin: 10rpx 0;
	}

	.orderdeliver .briefintroduction .confirPrice {
		padding: 20rpx 0;
		border-bottom: 1rpx solid #f2f2f2;
	}

	.orderdeliver .briefintroduction .payments div {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .briefintroduction .payments {
		border-bottom: 1rpx solid #f2f2f2;
		height: 140rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.orderdeliver .briefintroduction .briefconfir {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		line-height: 78rpx;
		color: #ff643a;
	}


	body .orderdeliver .LogisticsChoice .logistxt .logistkd input {
		margin: auto 0;
	}

	body .orderdeliver .LogisticsChoice .logistxt .logistkd {
		color: #999999;
		display: flex;

	}

	.orderdeliver .LogisticsChoice .logistxt .logist {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
		line-height: 75rpx;
		flex: 1;
		margin-left: 20rpx;
	}

	.orderdeliver .LogisticsChoice .logistxt div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		line-height: 75rpx;
	}

	.orderdeliver .LogisticsChoice .logistxt div:last-child img {
		width: 100%;
		height: 100%;
		margin: auto 0;
	}

	.orderdeliver .LogisticsChoice .logistxt div:last-child {
		width: 28rpx;
		height: 34rpx;
		display: flex;
		margin: auto 0;
	}

	.orderdeliver .LogisticsChoice .logistxt {
		height: 75rpx;
		display: flex;
		justify-content: space-between;
	}

	.orderdeliver .LogisticsChoice .logistitle {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
		line-height: 84rpx;
	}

	.orderdeliver .LogisticsChoice {
		width: 674rpx;
		flex-shrink: 0;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		padding: 0 20rpx;
		padding-bottom: 20rpx;
	}

	.orderdeliver .briefintroduction .brierinfo {
		line-height: 96rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .briefintroduction .briermessage div {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.orderdeliver .briefintroduction .briermessage {
		padding: 35rpx 0;
		border-bottom: 1rpx solid #f2f2f2;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .brierbottom div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .brierbottom div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff683a;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .brierbottom {
		display: flex;
		justify-content: space-between;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .briertitle div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.orderdeliver .briefintroduction .briertow .briertxt .briertitle div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;

	}

	.orderdeliver .briefintroduction .briertow .briertxt {
		margin-left: 20rpx;
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.orderdeliver .briefintroduction .briertow .brierimg img {
		width: 100%;
		height: 100%;
	}

	.orderdeliver .briefintroduction .briertow .brierimg {
		width: 160rpx;
		height: 160rpx;
	}

	.orderdeliver .briefintroduction .briertow {
		display: flex;
		padding-bottom: 46rpx;
		border-bottom: 1rpx solid #f2f2f2;
	}


	.orderdeliver .briefintroduction {
		width: 664rpx;
		/* height: 566rpx; */
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		padding: 0 22rpx;
		margin-bottom: 20rpx;
	}

	.orderdeliver .logistics .message .messtxt div:last-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #f5bc32;
	}

	.orderdeliver .logistics .message .messtxt div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.orderdeliver .logistics .message .messtxt {
		display: flex;
		flex-direction: column;
		margin-left: 20rpx;
	}

	.orderdeliver .logistics .message .messimg img {
		width: 100%;
		height: 100%;
	}

	.orderdeliver .logistics .message .messimg {
		width: 34rpx;
		height: 34rpx;
	}

	.orderdeliver .logistics .message {
		display: flex;
	}

	.orderdeliver .logistics .information .infotxt div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.orderdeliver .logistics .information .infotxt div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}


	.orderdeliver .logistics .information .infotxt {
		flex: 1;
		display: flex;
		flex-direction: column;
		margin-left: 20rpx;
	}

	.orderdeliver .logistics .information .infoimg img {
		width: 100%;
		height: 100%;
	}

	.orderdeliver .logistics .information .infoimg {
		width: 34rpx;
		height: 34rpx;
	}

	.orderdeliver .logistics .information {
		display: flex;
		margin: 40rpx 0;
	}

	.orderdeliver .logistics .logs .logtxt {
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
	}

	.orderdeliver .logistics .logs {
		display: flex;
		justify-content: space-between;
	}

	.orderdeliver .logistics {
		width: 664rpx;
		/* height: 262rpx; */
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		padding: 50rpx 25rpx;
	}

	.orderdeliver {
		/* height: 100%; */
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}
</style>
