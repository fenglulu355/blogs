<template>
	<view class="Orders">
		<div class="Onlineretailers" @click="orderstate(0)">
			<div class='onlinezuo'>
				<div class="onlinecircular"><image mode="widthFix" src="../../static/images/tzb.png"></image></div>
				<div class='onlinetxt'>
					<div>电商订单</div>
					<div>电商订单管理处理</div>
				</div>
			</div>
			<div class='onlineyou'>
				<img src="../../static/images/right.png" alt="">
			</div>
		</div>
		<div class="Onlineretailers" @click="orderstate(1)">
			<div class='onlinezuo'>
				<div class="onlinecircular Takeout"><image mode="widthFix" src="../../static/images/tza.png"></image></div>
				<div class='onlinetxt'>
					<div>外卖订单</div>
					<div>电商订单管理处理</div>
				</div>
			</div>
			<div class='onlineyou'>
				<img src="../../static/images/right.png" alt="">
			</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				Deliverid:''
			}
		},
		methods: {
			orderstate:function(e){
				uni.navigateTo({
					url: `../Orderstate/Orderstate?stateid=${this.Deliverid}&typeid=${e}`
				});
			}
		},
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
			this.Deliverid = option.id;
			// console.log(this.Deliverid);
		}
	}
</script>

<style>
	page {
		height: 100%;
	}

	body .Orders .Onlineretailers .onlinezuo .Takeout {
		background-color: #23c88c;
	}

	.Orders {
		height: 100%;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.Orders .Onlineretailers .onlinezuo .onlinetxt div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.Orders .Onlineretailers .onlinezuo .onlinetxt div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.Orders .Onlineretailers .onlinezuo .onlinetxt {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 30rpx 25rpx;
	}

	.Orders .Onlineretailers .onlinezuo .onlinecircular image {
		width: 100%;
		margin: auto 0;
	}

	.Orders .Onlineretailers .onlinezuo .onlinecircular {
		width: 80rpx;
		height: 80rpx;
		border-radius: 50%;
		margin: auto 0;
		display: flex;
		justify-content: center;
	}

	.Orders .Onlineretailers .onlinezuo {
		display: flex;
	}

	.Orders .Onlineretailers .onlineyou img {
		width: 100%;
		height: 100%;
		margin: auto 0;
	}

	.Orders .Onlineretailers .onlineyou {
		width: 28rpx;
		height: 34rpx;
		margin: auto 0;
		display: flex;
	}

	.Orders .Onlineretailers {
		width: 674rpx;
		height: 140rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		padding: 0 20rpx;
		display: flex;
		justify-content: space-between;
	}
</style>
