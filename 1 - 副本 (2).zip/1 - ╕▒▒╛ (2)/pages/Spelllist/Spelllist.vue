<template>
	<view class="spelllist">
		<Navigation></Navigation>
		<view class="spelldetail">
			<view class="spellWheel">
				<swiper class="swiper" autoplay interval="3000" duration="300" previous-margin="60rpx" next-margin="50rpx" circular
				 @change="change">
					<swiper-item v-for="item in indicator">
						<view class="swiper-items">
							<view class="swiperleft" :style="{backgroundImage: 'url(' + item.image + ')'}"></view>
							<view class="swiperight">
								<div class='swipertitle'>小姐姐专用防晒保湿护肤霜</div>
								<div class="swiperlabol">精选拼单</div>
								<div class="swipermon">￥<span>1</span></div>
								<div class="swipernum">
									2人团丨已拼130单
								</div>
							</view>
						</view>
					</swiper-item>
				</swiper>
				<view class="indicators">
					<div class="dian" v-for="item in indicator" :style="'background-color:'+item.color"></div>
				</view>
			</view>
			<view class="Spellul">
				<view class="spellli" v-for="item in 6" @click="spellist">
					<view class="spelimg" style="background-image: url('../../static/images/orders.jpg');"></view>
					<view class="speldeta">
						<view class="speltop">神仙姐姐专用护肤保湿卸妆霜 小巧可随身携带</view>
						<view class="spelbottom">
							<view class="speltotal">
								<div>￥<span>5.9</span></div>
								<div>单买价:￥9.9</div>
							</view>
							<view class="immediately">
								<div class='immedbtn'>立即拼单</div>
								<div class="immedtxt">2人团丨已拼60单</div>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				indicator: [{
						image: '../../static/images/orders.jpg',
						color: '#d8ebff'
					},
					{
						image: '../../static/images/orders.jpg',
						color: '#fff'
					},
					{
						image: '../../static/images/orders.jpg',
						color: '#fff'
					},
					{
						image: '../../static/images/orders.jpg',
						color: '#fff'
					}
				]
			}
		},
		methods: {
			change: function(e) {
				let arr = this.indicator;
				for (let i in arr) {
					arr[i].color = '#fff'
					if (i == e.detail.current) {
						arr[i].color = '#d8ebff';
					}
				}
				this.indicator = arr;
				// console.log(e.detail.current);
			},
			spellist:function(){
				uni.navigateTo({
					url: '../Spelllistxq/Spelllistxq'
				});
			}
		},
		components: {
			Navigation
		}
	}
</script>

<style>
	.spelldetail .Spellul .spellli .speldeta .spelbottom .immediately .immedtxt{
		color: #8d8d8d;
		font-size: 24rpx;
	}
	.spelldetail .Spellul .spellli .speldeta .spelbottom .immediately .immedbtn{
		width: 182rpx;
		height: 52rpx;
		background-color: #f5bc32;
		border-radius: 2rpx 10rpx 2rpx 10rpx;
		color: #000022;
		font-size: 28rpx;
		text-align: center;
		line-height: 52rpx;
		margin-bottom: 16rpx;
	}
	.spelldetail .Spellul .spellli .speldeta .spelbottom .speltotal div:last-child{
		color: #8d8d8d;
		font-size: 24rpx;
	}
	.spelldetail .Spellul .spellli .speldeta .spelbottom .speltotal div:first-child span{
		font-size: 28rpx;
	}
	.spelldetail .Spellul .spellli .speldeta .spelbottom .speltotal div:first-child{
		font-size: 24rpx;
		color: #ff643a;
	}
	.spelldetail .Spellul .spellli .speldeta .spelbottom .speltotal{
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
	}
	.spelldetail .Spellul .spellli .speldeta .spelbottom{
		display: flex;
		justify-content: space-between;
	}
	.spelldetail .Spellul .spellli .speldeta .speltop{
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #161616;
	}
	.spelldetail .Spellul .spellli .speldeta{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-left: 20rpx;
	}
	.spelldetail .Spellul .spellli .spelimg {
		width: 160rpx;
		height: 160rpx;
		background-color: #ffffff;
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		border: solid 1rpx #f2f2f2;
		margin: auto 0;
	}

	.spelldetail .Spellul .spellli {
		height: 160rpx;
		background-color: #ffffff;
		padding: 30rpx 18rpx;
		display: flex;
		margin-bottom: 15rpx;
		flex-shrink: 0;
	}

	.spelldetail .Spellul {
		display: flex;
		flex-direction: column;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items .swiperight .swipernum {
		color: #999999;
		font-size: 24rpx;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items .swiperight .swipermon span {
		font-size: 36rpx;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items .swiperight .swipermon {
		color: #ff643a;
		font-size: 24rpx;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items .swiperight .swiperlabol {
		width: 125rpx;
		height: 40rpx;
		background-color: #d8ebff;
		border-radius: 20rpx;
		color: #3c9cff;
		font-size: 24rpx;
		text-align: center;
		line-height: 40rpx;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items .swiperight .swipertitle {
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #000000;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items .swiperight {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items .swiperleft {
		width: 260rpx;
		height: 260rpx;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
		margin-right: 20rpx;
	}

	.spelldetail .spellWheel .indicators .dian {
		width: 40rpx;
		height: 6rpx;
		border-radius: 3rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}

	.spelldetail .spellWheel .indicators {
		width: 100%;
		height: 38rpx;
		background-color: #f8f8f8;
		position: absolute;
		bottom: 0;
		display: flex;
		justify-content: center;
	}

	.spelldetail .spellWheel .swiper swiper-item .swiper-items {
		width: 564rpx;
		height: 264rpx;
		padding: 28rpx;
		background-color: #fff;
		position: absolute;
		box-shadow: 0rpx 10rpx 30rpx 0rpx rgba(3, 0, 0, 0.03);
		border-radius: 8rpx;
		display: flex;
		top: 10rpx;
		left: 10rpx;
	}

	.spelldetail .spellWheel .swiper swiper-item {
		/* border: 1rpx solid #0081FF; */
		position: relative;
	}

	.spelldetail .spellWheel .swiper {
		height: 100%;
		/* border: 1rpx solid red; */
	}

	.spelldetail .spellWheel {
		padding: 20rpx 0;
		height: 350rpx;
		background-color: #f8f8f8;
		position: relative;
		/* border: 1rpx solid #000; */
	}

	.spelldetail {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
		display: flex;
		flex-direction: column;
	}

	.spelllist {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100vh;
	}
</style>
