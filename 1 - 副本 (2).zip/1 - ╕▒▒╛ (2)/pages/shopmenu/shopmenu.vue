<template>
	<view class="shopmenupage">
		<Navigation></Navigation>
		<view class="shopmenu">
			<view class="shopmenuleft">
				<div v-for="(item,index) in menutype" :style="'background-color:'+item.color+';border-left-color:'+item.bordercolor" @click="setmenu(index)">{{item.name}}</div>
			</view>
			<view class="shopmenuright">
				<view class="shopmebuli" v-for="item in 10" @click="shopmenuxq">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<div>酸辣土豆丝</div>
					<div>月售55</div>
					<div>￥<span>10.6</span></div>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				menutype:[
					{
						name:'热门推荐',
						color:'#fff',
						bordercolor:'#ff643a'
					},
					{
						name:'精品小炒',
						color:'#f4f4f4',
						bordercolor:'#f4f4f4'
					},
					{
						name:'特色硬菜',
						color:'#f4f4f4',
						bordercolor:'#f4f4f4'
					},
					{
						name:'酒水饮料',
						color:'#f4f4f4',
						bordercolor:'#f4f4f4'
					}
				]
			}
		},
		methods: {
			setmenu:function(e){
				let arr = this.menutype
				for(let i in arr){
					arr[i].color = '#f4f4f4'
					arr[i].bordercolor = '#f4f4f4'
				}
				arr[e].color = '#fff'
				arr[e].bordercolor = '#ff643a'
			},
			shopmenuxq:function(){
				uni.navigateTo({
					url: '../shopmenuxq/shopmenuxq'
				});
			}
		},
		components:{
			Navigation
		}
	}
</script>

<style>
page{
	height: 100vh;
}
.shopmenupage{
	display: flex;
	flex-direction: column;
	height: 100%;
}
.shopmenu{
	flex: 1;
	display: flex;
}

.shopmenu .shopmenuright .shopmebuli div:last-child span{
		color: #ff643a;
		font-size: 32rpx;
}

.shopmenu .shopmenuright .shopmebuli div:last-child{
	color: #ff643a;
	font-size: 22rpx;
	font-weight: bold;
	margin-top: 30rpx;
}

.shopmenu .shopmenuright .shopmebuli div:first-child{
	color: #222222;
	font-size: 24rpx;
	margin: 10rpx 0;
}

.shopmenu .shopmenuright .shopmebuli div{
	color: #999999;
	font-size: 22rpx;
}

.shopmenu .shopmenuright .shopmebuli image{
	width: 250rpx;
	height: 250rpx;
	border-radius: 5rpx;
	border: solid 1rpx #f8f8f8;
}
.shopmenu .shopmenuright .shopmebuli{
	margin: 0 12rpx;
	margin-bottom: 50rpx;
}
.shopmenu .shopmenuright{
	flex: 1;
	overflow: auto;
	padding: 40rpx 15rpx;
	display: flex;
	flex-wrap: wrap;
}
.shopmenu .shopmenuleft div{
	height: 100rpx;
	background-color: #f4f4f4;
	border-left: 4rpx solid #f4f4f4;
	text-align: center;
	line-height: 100rpx;
	border-bottom: 1rpx solid #fff;
	color: #222222;
	font-size: 24rpx;
}
.shopmenu .shopmenuleft{
	background-color: #f4f4f4;
	width: 160rpx;
}
</style>
