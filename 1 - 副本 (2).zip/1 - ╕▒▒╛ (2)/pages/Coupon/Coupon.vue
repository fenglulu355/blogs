<template>
	<view class="coupons">
		<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
		<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
			<swiper-item id="1">
				<div class="commodity">
					<div class='oneCoupon'>
						<div class="couright">
							<div class='courtop'>商品券</div>
							<div class='courbottom'>
								<div>全场满100减50</div>
								<div>有效期：2019-03-20至2019-04-20</div>
								<div>适用品类：服装、鞋靴</div>
							</div>
						</div>
						<div class='couleft'>
							<div><span>50</span>元</div>
							<div>满100可使用</div>
						</div>
						<div class='Semicircle'></div>
						<div class='semic'></div>
					</div>
				</div>
				<div class='addCoupon' @click="addCoupons">增加优惠券</div>
			</swiper-item>
			<swiper-item id="2">
				<div class="commodity">
					<div class='oneCoupon'>
						<div class="couright">
							<div class='courtop foodtop'>外卖券</div>
							<div class='courbottom'>
								<div>全场满100减50</div>
								<div>有效期：2019-03-20至2019-04-20</div>
								<div>适用品类：服装、鞋靴</div>
							</div>
						</div>
						<div class='couleft food'>
							<div><span>50</span>元</div>
							<div>满100可使用</div>
						</div>
						<div class='Semicircle'></div>
						<div class='semic'></div>
					</div>
				</div>
				<div class='addCoupon addfood' @click="addCoupons">增加优惠券</div>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';

	export default {
		data() {
			return {
				TabCur: 0,
				tabList: [{
					name: '商品'
				}, {
					name: '外卖'
				}],
			}
		},
		components: {
			WucTab
		},
		methods: {
			tabChange(index) {
				this.TabCur = index;
			},
			swiperChange(e) {
				this.tabChange(e.detail.current)
			},
			addCoupons:function(){
				uni.navigateTo({
					url:'../Preferential/Preferential'
				});
			}
		}
	}
</script>

<style>
	body .addfood {
		background-color: #ff643a;
	}

	body .commodity .oneCoupon .couright .foodtop {
		background-color: #ff643a;
	}

	body .commodity .oneCoupon .food {
		background-color: #ff643a;
	}

	.addCoupon {
		width: 100%;
		height: 100rpx;
		background-color: #f5bc32;
		position: fixed;
		bottom: 0;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 44rpx;
		letter-spacing: 0px;
		color: #222222;
		text-align: center;
		line-height: 100rpx;
	}

	page {
		height: 100%;
	}

	.coupons {
		display: flex;
		flex-direction: column;
		height: 100%;
	}

	.swip {
		background-color: #f8f8f8;
		flex: 1;
	}

	.commodity .oneCoupon .couleft div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.commodity .oneCoupon .couleft div:first-child span {
		font-family: PingFang-SC-Bold;
		font-size: 60rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.commodity .oneCoupon .couleft div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.commodity .oneCoupon .couleft {
		width: 230rpx;
		background-color: #f5bc32;
		border-radius: 14rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		text-align: center;
	}

	.commodity .oneCoupon .semic {
		width: 40rpx;
		height: 40rpx;
		border-radius: 50%;
		background-color: #f8f8f8;
		position: absolute;
		bottom: -20rpx;
		right: 214rpx;
	}

	.commodity .oneCoupon .Semicircle {
		width: 40rpx;
		height: 40rpx;
		border-radius: 50%;
		background-color: #f8f8f8;
		position: absolute;
		top: -20rpx;
		right: 214rpx;
	}

	.commodity .oneCoupon .couright .courtop {
		width: 100rpx;
		height: 40rpx;
		background-color: #f5bc32;
		border-radius: 5rpx 0rpx 5rpx 0rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 40rpx;
	}

	.commodity .oneCoupon .couright .courbottom div:first-child {
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #333333;
	}

	.commodity .oneCoupon .couright .courbottom div {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
	}

	.commodity .oneCoupon .couright .courbottom {
		flex: 1;
		padding: 22rpx 20rpx;
	}

	.commodity .oneCoupon .couright {
		flex: 1;
		border-right: 6rpx dashed #f1f1f1;
		display: flex;
		flex-direction: column;
	}

	.commodity .oneCoupon {
		width: 714rpx;
		height: 182rpx;
		background-color: #fff;
		margin: 0 auto;
		margin-top: 18rpx;
		display: flex;
		border-radius: 14rpx;
		position: relative;
	}
</style>
