<template>
	<view class="main">
		<view class="maintop"></view>
		<view class="mainbottom">
			<view class="mainbottomone">
				<view class="one">
					<view class="Headimg">
						<image mode="widthFix" :src="userinfo.avatar"></image>
					</view>
					<view class="mainame">
						<view class="name">{{userinfo.username}}</view>
						<view class="Administration" @click="account">账号管理{{you}}</view>
					</view>
					<view class="mainnews" @click="news">
						<Iconfonts name="icon-xiaoxi" size="45rpx" colors="#222222" />
						<div>2</div>
					</view>
				</view>
				<view class="tow">
					<view class="towlabol" @click="collection">
						<div><Iconfonts name="icon-dianpu" size="28rpx" colors="#ffffff" /></div>
						<div>店铺收藏</div>
					</view>
					<view class="towlabol" @click="collection">
						<div><Iconfonts name="icon-gouwuche" size="28rpx" colors="#ffffff" /></div>
						<div>商品收藏</div>
					</view>
					<view class="towlabol" @click="footprint">
						<div><Iconfonts name="icon-zuji" size="28rpx" colors="#ffffff" /></div>
						<div>浏览足迹</div>
					</view>
				</view>
			</view>
			<view class="mainbottomtow">
				<view class="mainstate" @click="fullorder">
					<image mode="widthFix" src="../../static/images/dfk.png"></image>
					<div>待付款</div>
				</view>
				<view class="mainstate" @click="fullorder">
					<image mode="widthFix" src="../../static/images/dfh.png"></image>
					<div>待发货</div>
				</view>
				<view class="mainstate" @click="fullorder">
					<image mode="widthFix" src="../../static/images/dsh.png"></image>
					<div>待收货</div>
				</view>
				<view class="mainstate" @click="fullorder">
					<image mode="widthFix" src="../../static/images/kf.png"></image>
					<div>退换货</div>
				</view>
			</view>
			<view class="mainbottomthree">
				<view class="top">
					<view class="threelabol" @click="second">
						<Iconfonts name="icon-jiu" size="38rpx" colors="#5695f5" />
						<div>旧物发布</div>
					</view>
					<view class="threelabol" @click="addr">
						<Iconfonts name="icon-dizhi" size="42rpx" colors="#9b9bf3" />
						<div>收货地址</div>
					</view>
					<view class="threelabol" @click="coupon">
						<Iconfonts name="icon-youhuiquan" size="35rpx" colors="#ffa37a" />
						<div>优惠券</div>
					</view>
					<view class="threelabol" @click="kefu">
						<Iconfonts name="icon-kefu" size="45rpx" colors="#f6cd60" />
						<div>同城客服</div>
					</view>
				</view>
				<view class="bottom">
					<view class="threelabol">
						<Iconfonts name="icon-dianhua" size="45rpx" colors="#ffa37a" />
						<div>客服电话</div>
					</view>
					<view class="threelabol" @click="about">
						<p>同</p>
						<div>关于同城</div>
					</view>
					<view class="threelabol" @click="feedback">
						<Iconfonts name="icon-yijianfankui" size="40rpx" colors="#f992af" />
						<div>意见反馈</div>
					</view>
					<view class="threelabol">
						
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				you:'>',
				users:''
			}
		},
		computed: {
			...mapState(['userinfo'])
		},
		onShow:function(){
			uni.getStorage({
			    key: 'token',
			    success: (res)=> {
					this.getuserinfo(res.data);
			        // console.log(res.data);
			    }
			});
		},
		methods: {
			...mapActions(['getuserinfo']),
			news:function(){
				uni.navigateTo({
					url: '../shopNews/shopNews'
				});
			},
			account:function(){
				uni.navigateTo({
					url: '../account/account'
				});
			},
			kefu:function(){
				uni.navigateTo({
					url:'../Customer/Customer'
				});
			},
			about:function(){
				uni.navigateTo({
					url:'../aboutcity/aboutcity'
				});
			},
			coupon:function(){
				uni.navigateTo({
					url:'../shopCoupon/shopCoupon'
				});
			},
			feedback:function(){
				uni.navigateTo({
					url:'../feedback/feedback'
				});
			},
			addr:function(){
				uni.navigateTo({
					url:'../Receiving/Receiving'
				});
			},
			collection:function(){
				uni.navigateTo({
					url:'../Collection/Collection'
				});
			},
			footprint:function(){
				uni.navigateTo({
					url:'../footprint/footprint'
				});
			},
			fullorder:function(){
				uni.navigateTo({
					url:'../fullorder/fullorder'
				});
			},
			second:function(){
				uni.navigateTo({
					url:'../shopBusiness/shopBusiness'
				});
			}
		},
		components:{
			Iconfonts
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	.threelabol p{
		width: 38rpx;
		height: 38rpx;
		background-color: #f992af;
		border-radius: 50%;
		display: block;
		text-align: center;
		line-height: 38rpx;
		color: #fff;
		font-size: 24rpx;
		font-weight: bold;
		margin: 0 auto;
		margin-bottom: 15rpx;
	}
	.threelabol Iconfonts{
		text-align: center;
	}
	.threelabol div{
		font-size: 24rpx;
		color: #666666;
		text-align: center;
		margin-top: 5rpx;
	}
	.threelabol{
		width: 150rpx;
		height: 100%;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		
	}
	.main .mainbottom .mainbottomthree .bottom{
		height: 80rpx;
		padding: 40rpx 10rpx;
		display: flex;
		justify-content: space-between;
	}
	.main .mainbottom .mainbottomthree .top{
		border-bottom: 1rpx solid #f2f2f2;
		height: 80rpx;
		padding: 40rpx 10rpx;
		display: flex;
		justify-content: space-between;
	}
	.main .mainbottom .mainbottomthree{
		width: 678rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		padding: 0 18rpx;
		margin: 0 auto;
	}
	.main .mainbottom .mainbottomtow .mainstate div{
		color: #222222;
		font-size: 24rpx;
		text-align: center;
	}
	.main .mainbottom .mainbottomtow .mainstate image{
		width: 44rpx;
		margin: 0 auto;
	}
	.main .mainbottom .mainbottomtow .mainstate{
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
	.main .mainbottom .mainbottomtow{
		width: 634rpx;
		height: 90rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 18rpx auto;
		padding: 35rpx 40rpx;
		display: flex;
		justify-content: space-between;
	}
	.main .mainbottom .mainbottomone .tow .towlabol div:last-child{
		color: #666666;
		font-size: 24rpx;
		margin: auto 0;
	}
	.main .mainbottom .mainbottomone .tow .towlabol div:first-child Iconfonts{
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.main .mainbottom .mainbottomone .tow .towlabol div:first-child{
		width: 50rpx;
		height: 50rpx;
		background-color: #d4c7a6;
		border-radius: 50%;
		text-align: center;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin: auto 20rpx;
	}
	.main .mainbottom .mainbottomone .tow .towlabol:last-child{
		margin: auto 0;
	}
	.main .mainbottom .mainbottomone .tow .towlabol{
		display: flex;
		margin: auto 0;
		margin-right: 50rpx;
	}
	.main .mainbottom .mainbottomone .tow{
		flex: 1;
		display: flex;
	}
	.main .mainbottom .mainbottomone .one .mainnews div{
		width: 34rpx;
		height: 34rpx;
		border-radius: 50%;
		background-color: #ff643a;
		position: absolute;
		top: -12rpx;
		right: -17rpx;
		color: #fff;
		font-size: 22rpx;
		text-align: center;
		line-height: 34rpx;
	}

	.main .mainbottom .mainbottomone .one .mainnews {
		width: 38rpx;
		height: 38rpx;
		margin-right: 10rpx;
		position: relative;
	}
	
	.main .mainbottom .mainbottomone .one .mainame .Administration{
		width: 140rpx;
		height: 40rpx;
		background-color: #ffc528;
		border-radius: 20rpx;
		color: #222222;
		font-size: 20rpx;
		text-align: center;
		line-height: 40rpx;
	}
	
	.main .mainbottom .mainbottomone .one .mainame .name{
		color: #222222;
		font-size: 36rpx;
		font-weight: bold;
		margin-bottom: 18rpx;
	}

	.main .mainbottom .mainbottomone .one .mainame {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.main .mainbottom .mainbottomone .one .Headimg image {
		width: 100%;
		border-radius: 50%;
	}

	.main .mainbottom .mainbottomone .one .Headimg {
		width: 120rpx;
		height: 120rpx;
		background-color: #ffc528;
		border-radius: 50%;
		margin-right: 20rpx;
	}

	.main .mainbottom .mainbottomone .one {
		height: 120rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
		padding: 30rpx 12rpx;
	}

	.main .mainbottom .mainbottomone {
		width: 678rpx;
		height: 280rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: -135rpx;
		padding: 0 18rpx;
		display: flex;
		flex-direction: column;
	}

	.main .mainbottom {
		flex: 1;
		display: flex;
		flex-direction: column;
		background-color: #f8f8f8;
	}

	.main .maintop {
		height: 165rpx;
		background-color: #ffc528;
	}

	.main {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
