<template>
	<view class="collectionpage">
		<Navigation></Navigation>
		<view class="collection">
			<wuc-tab :tab-list="tabList" selectClass="color:#000" :tabCur.sync="TabCur" @change="tabChange"></wuc-tab>
			<swiper class="swip" :current="TabCur" duration="300" @change="swiperChange">
				<swiper-item id="1">
					<view class="resultsdiv" v-for="item in 10">
						<view class="resuleft">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						</view>
						<view class="resuright">
							<view class="resurone">
								<view class="resuroneleft">
									隔壁老王菜店
								</view>
								<view class="resuroneright">
									<div>订</div>
									<div>订</div>
									<div>订</div>
								</view>
							</view>
							<view class="resurtow">
								<view class="resura">
									<Iconfonts name="icon-canju" size="25rpx" colors="#f0cf26" />
									<div>人均￥75 菜场</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
									<div>营业时间 6:00-20:30</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-dizhi" size="25rpx" colors="#f0cf26" />
									<div>营业时间 6:00-20:30</div>
									<p>{{dayu}}50m</p>
								</view>
							</view>
							<view class="resurthree">
								<view class="resurlabol">
									<div>减</div>
									<span>满200减30</span>
								</view>
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item id="2">
					<view class="resultsdiv" v-for="item in 10">
						<view class="resuleft">
							<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						</view>
						<view class="resuright">
							<view class="resurone">
								<view class="resuroneleft">
									隔壁老王菜店
								</view>
								<view class="resuroneright">
									<div>订</div>
									<div>订</div>
									<div>订</div>
								</view>
							</view>
							<view class="resurtow">
								<view class="resura">
									<Iconfonts name="icon-canju" size="25rpx" colors="#f0cf26" />
									<div>人均￥75 菜场</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
									<div>营业时间 6:00-20:30</div>
								</view>
								<view class="resura">
									<Iconfonts name="icon-dizhi" size="25rpx" colors="#f0cf26" />
									<div>营业时间 6:00-20:30</div>
									<p>{{dayu}}50m</p>
								</view>
							</view>
							<view class="resurthree">
								<view class="resurlabol">
									<div>减</div>
									<span>满200减30</span>
								</view>
							</view>
						</view>
					</view>
				</swiper-item>
			</swiper>
		</view>
	</view>
</template>

<script>
	import WucTab from '@/components/wuc-tab/wuc-tab.vue';
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	export default {
		data() {
			return {
				TabCur: 0,
				tabList: [{
					name: '店铺收藏'
				}, {
					name: '商品收藏'
				}],
				dayu: '>'
			}
		},
		methods: {
			tabChange(index) {
				this.TabCur = index;
			},
			swiperChange(e) {
				this.tabChange(e.detail.current)
			},
		},
		components: {
			Navigation,
			Iconfonts,
			WucTab
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}

	swiper-item {
		display: flex;
		flex-direction: column;
		overflow: auto;
	}

	.resultsdiv .resuright .resurthree .resurlabol span {
		color: #666666;
		font-size: 24rpx;
	}

	.resultsdiv .resuright .resurthree .resurlabol div {
		width: 24rpx;
		height: 24rpx;
		background-color: #ff643a;
		border-radius: 3rpx;
		color: #ffffff;
		font-size: 20rpx;
		text-align: center;
		line-height: 24rpx;
		margin: auto 0;
		margin-right: 12rpx;
	}

	.resultsdiv .resuright .resurthree .resurlabol {
		display: flex;
	}

	.resultsdiv .resuright .resurthree {
		padding: 20rpx 0;
	}

	.resultsdiv .resuright .resurtow .resura Iconfonts {
		margin-right: 10rpx;
		line-height: 24rpx;
	}

	.resultsdiv .resuright .resurtow .resura p {
		margin: 0;
		color: #666666;
		font-size: 24rpx;
	}

	.resultsdiv .resuright .resurtow .resura div {
		color: #666666;
		font-size: 24rpx;
		margin-right: 24rpx;
		flex: 1;
	}

	.resultsdiv .resuright .resurtow .resura:last-child {
		margin: 0;
	}

	.resultsdiv .resuright .resurtow .resura {
		display: flex;
		justify-content: space-between;
		margin-bottom: 12rpx;

	}

	.resultsdiv .resuright .resurtow {
		display: flex;
		flex-direction: column;
		border-bottom: 1rpx solid #f2f2f2;
		padding: 22rpx 0;
	}

	.resultsdiv .resuright .resurone .resuroneright div {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #23c88c;
		color: #23c88c;
		font-size: 24rpx;
		text-align: center;
		line-height: 34rpx;
		margin-left: 10rpx;
	}

	.resultsdiv .resuright .resurone .resuroneright {
		display: flex;
	}

	.resultsdiv .resuright .resurone .resuroneleft {
		flex: 1;
		color: #222222;
		font-size: 28rpx;
	}

	.resultsdiv .resuright .resurone {
		display: flex;
		justify-content: space-between;
	}

	.resultsdiv .resuright {
		flex: 1;
	}

	.resultsdiv .resuleft image {
		width: 100%;
	}

	.resultsdiv .resuleft {
		width: 120rpx;
		height: 120rpx;
		border-radius: 5rpx;
		margin-right: 20rpx;
		overflow: hidden;
	}

	.resultsdiv:last-child {
		margin-bottom: 10rpx;
	}

	.resultsdiv {
		margin-top: 10rpx;
		padding: 18rpx;
		display: flex;
		background-color: #fff;
		flex-shrink: 0;
	}


	.collection .swip {
		flex: 1;
	}

	.collection wuc-tab {
		background-color: #fff;
		border-top: 1rpx solid #f8f8f8;
	}

	.collection {
		flex: 1;
		background-color: #f8f8f8;
		display: flex;
		flex-direction: column;
	}

	.collectionpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
