<template>
	<view class="secondhanxqpage">
		<Navigation></Navigation>
		<view class="secondhanxq">
			<view class="secondlb">
				<swiper class="swiper" autoplay="true" interval="3000" duration="300" @change="wheelsa">
					<swiper-item v-for="(item,index) in 5">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					</swiper-item>
				</swiper>
				<div class="currents">{{current}}/5</div>
			</view>
			<view class="secondname">
				<view class="secondnametop">
					<view class="name">
						OPPO R21新款手机 刚激活可验证激活时间
					</view>
					<view class="total">
						<div>￥<span>129</span></div>
						<div>含运费</div>
					</view>
				</view>
				<view class="secondnamebottom">
					<view class="secondone">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<div class="firstdiv">你丑，你先走</div>
						<div>刚刚在线</div>
					</view>
					<view class="secondtow">
						<Iconfonts name="icon-dizhi" size="20rpx" colors="#222222" />
						<div>成都武侯区桐梓林新希望大厦附近</div>
					</view>
				</view>
			</view>
			<view class="Commoditydetails">
				<view class="title">
					商品详情
				</view>
				<view class="texta">
					全新的机器，刚买回来激活了就放在边上没用了 ，有以可以私聊，价格合适就出手。
				</view>
				<view class="imgs">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
				</view>
			</view>
			<view class="aboutshop">
				<view class="about">
					关于卖家
				</view>
				<view class="aboutname">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<div>
						<p>你丑，你先走</p>
						<p>刚刚在线</p>
					</div>
				</view>
				<view class="Onsale">
					<div>
						<p>1</p>
						<p>在售宝贝</p>
					</div>
					<div>
						<p>0</p>
						<p>累计交易</p>
					</div>
					<div>
						<p>100%</p>
						<p>回复率</p>
					</div>
				</view>
			</view>
			<view class="Besimilar">
				<view class="besimilartitle">
					<view class="lefta">
						<view class="xian"></view>
						<view class="fangkuaia"></view>
						<view class="fangkuaib"></view>
					</view>
					<view class="besimilarname">相似商品</view>
					<view class="righta">
						<view class="fangkuaia"></view>
						<view class="fangkuaib"></view>
						<view class="xian"></view>
					</view>
				</view>
				<view class="shopli">
					<view class="towli" v-for="item in 10" @click="aecondxq">
						<image mode="widthFix" src="../../static/images/orders.jpg"></image>
						<view class="towlibottom">
							<view class="towliones">
								<view class="towlionesa">
									西洋风情茶水杯
								</view>
								<view class="towlionesb">
									<div>￥ <span>99</span></div>
									<div>全新未使用</div>
								</view>
							</view>
							<view class="towliname">
								<image mode="widthFix" src="../../static/images/orders.jpg"></image>
								<div>
									<p>你丑你先走</p>
									<p>当前在线</p>
								</div>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="bottomdiv">
			<view class="bottomleft">
				<div>
					<Iconfonts name="icon-fenxiang" size="40rpx" colors="#dddddd" />
					<p>分享</p>
				</div>
				<div>
					<Iconfonts name="icon-xingxing" size="40rpx" colors="#dddddd" />
					<p>收藏</p>
				</div>
			</view>
			<view class="bottomright">
				<div>买前聊一聊</div>
				<div>马上买</div>
			</view>
		</view>
	</view>
</template>

<script>
	import Iconfonts from '../../components/iconfonts.vue'
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				current: 1
			}
		},
		methods: {
			wheelsa: function(e) {
				this.current = e.detail.current + 1
				// console.log(e.detail.current);
			}
		},
		components: {
			Iconfonts,
			Navigation
		}
	}
</script>

<style>
	
	.bottomdiv .bottomright div:last-child{
		width: 220rpx;
		height: 66rpx;
		background-color: #3c9cff;
		border-radius: 10rpx;
		text-align: center;
		line-height: 66rpx;
		color: #ffffff;
		font-size: 28rpx;
		margin: auto 0;
	}
	
	.bottomdiv .bottomright div:first-child{
		margin: auto 0;
		width: 220rpx;
		height: 66rpx;
		background-color: #ffcd55;
		border-radius: 10rpx;
		text-align: center;
		line-height: 66rpx;
		color: #ffffff;
		font-size: 28rpx;
	}
	
	.bottomdiv .bottomright{
		flex: 1;
		display: flex;
		justify-content: space-around;
	}
	
	.bottomdiv .bottomleft div p{
		color: #666666;
		font-size: 22rpx;
		margin: 0 auto;
	}
	
	.bottomdiv .bottomleft div Iconfonts{
		display: flex;
		margin: 0 auto ;
		justify-content: center;
	}
	
	.bottomdiv .bottomleft div{
		margin: auto 0;
	}
	.bottomdiv .bottomleft{
		width: 250rpx;
		margin: auto 0;
		display: flex;
		justify-content: space-around;
	}
	page {
		height: 100vh;
	}

	.towli .towlibottom .towliname div p:last-child {
		color: #999999;
		font-size: 18rpx;
	}

	.towli .towlibottom .towliname div p:first-child {
		color: #222222;
		font-size: 22rpx;
	}

	.towli .towlibottom .towliname div {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.towli .towlibottom .towliname image {
		width: 50rpx;
		height: 50rpx;
		border-radius: 50%;
		margin-right: 12rpx;
	}

	.towli .towlibottom .towliname {
		padding: 20rpx 0;
		display: flex;
	}

	.towli .towlibottom .towliones .towlionesb div:last-child {
		width: 105rpx;
		height: 30rpx;
		background-color: #eaf3fd;
		text-align: center;
		line-height: 30rpx;
		color: #3c9cff;
		font-size: 18rpx;
		margin: auto 0;
	}

	.towli .towlibottom .towliones .towlionesb div:first-child span {
		color: #3c9cff;
		font-size: 28rpx;
	}

	.towli .towlibottom .towliones .towlionesb div:first-child {
		color: #3c9cff;
		font-size: 24rpx;
		margin: auto 0;
		font-weight: bold;
	}

	.towli .towlibottom .towliones .towlionesb {
		display: flex;
		justify-content: space-between;
	}

	.towli .towlibottom .towliones .towlionesa {
		color: #222222;
		font-size: 28rpx;
		margin-bottom: 25rpx;
	}

	.towli .towlibottom .towliones {
		padding: 20rpx 0;
		border-bottom: 1rpx solid #f2f2f2;
	}

	.towli .towlibottom {
		display: flex;
		flex-direction: column;
		padding: 0 20rpx;
	}

	.towli image {
		width: 348rpx;
		height: 348rpx;
		background-color: #3c9cff;
		border-radius: 10rpx 10rpx 0rpx 0rpx;
	}

	.towli {
		/* width: 325rpx; */
		/* height: 560rpx; */
		background-color: #ffffff;
		border-radius: 10rpx;
		margin:15rpx;
	}





	.secondhanxq .Besimilar .shopli {
		display: flex;
		flex-wrap: wrap;
	}

	.secondhanxq .Besimilar .besimilartitle .besimilarname {
		margin: auto 15rpx;
		color: #222222;
		font-size: 32rpx;
		font-weight: bold;
	}

	.secondhanxq .Besimilar .besimilartitle .righta .xian {
		width: 48rpx;
		height: 2rpx;
		background-color: #3c9cff;
		border-radius: 0rpx;
		margin: auto 15rpx;
	}

	.secondhanxq .Besimilar .besimilartitle .righta .fangkuaib {
		width: 13rpx;
		height: 18rpx;
		background-color: #3c9cff;
		border-radius: 5rpx;
		opacity: 0.5;
		margin: auto 0;
		transform: skew(-40deg);
		margin-left: 5rpx;
	}

	.secondhanxq .Besimilar .besimilartitle .righta .fangkuaia {
		width: 13rpx;
		height: 18rpx;
		background-color: #3c9cff;
		border-radius: 5rpx;
		margin: auto 0;
		transform: skew(-40deg);
	}

	.secondhanxq .Besimilar .besimilartitle .righta {
		display: flex;
		margin: auto 0;
	}

	.bottomdiv {
		height: 98rpx;
		background-color: #ffffff;
		box-shadow: 0rpx 1rpx 20rpx 0rpx rgba(195, 195, 195, 0.35);
		display: flex;
	}

	.secondhanxq .Besimilar .besimilartitle .lefta .fangkuaib {
		width: 14rpx;
		height: 19rpx;
		background-color: #3c9cff;
		border-radius: 5rpx;
		opacity: 0.5;
		transform: skew(-40deg);
		margin: auto 5rpx;
	}

	.secondhanxq .Besimilar .besimilartitle .lefta .fangkuaia {
		width: 14rpx;
		height: 19rpx;
		background-color: #3c9cff;
		border-radius: 5rpx;
		transform: skew(-40deg);
		margin: auto 0;
	}

	.secondhanxq .Besimilar .besimilartitle .lefta .xian {
		width: 48rpx;
		height: 2rpx;
		background-color: #3c9cff;
		border-radius: 0rpx;
		margin: auto 15rpx;
	}

	.secondhanxq .Besimilar .besimilartitle .lefta {
		display: flex;
		margin: auto 0;
	}

	.secondhanxq .Besimilar .besimilartitle {
		display: flex;
		justify-content: center;
		margin: 15rpx 0;
	}

	.secondhanxq .Besimilar {
		padding: 20rpx 0;
	}

	.secondhanxq .aboutshop .Onsale div p:last-child {
		text-align: center;
		color: #999999;
		font-size: 20rpx;
	}

	.secondhanxq .aboutshop .Onsale div p:first-child {
		text-align: center;
		color: #222222;
		font-size: 28rpx;
	}

	.secondhanxq .aboutshop .Onsale div {
		border-left: 1rpx solid #eeeeee;
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		width: 33%;
	}

	.secondhanxq .aboutshop .Onsale div:last-child {
		border: none;
	}

	.secondhanxq .aboutshop .Onsale {
		height: 58rpx;
		background-color: #f5f5f5;
		border-radius: 5rpx;
		padding: 15rpx 0;
		display: flex;
	}

	.secondhanxq .aboutshop .aboutname div p:last-child {
		color: #999999;
		font-size: 20rpx;
	}

	.secondhanxq .aboutshop .aboutname div p:first-child {
		color: #222222;
		font-size: 24rpx;
	}

	.secondhanxq .aboutshop .aboutname div {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.secondhanxq .aboutshop .aboutname image {
		width: 70rpx;
		height: 70rpx;
		background-color: #3c9cff;
		border-radius: 50%;
		margin-right: 12rpx;
	}

	.secondhanxq .aboutshop .aboutname {
		margin: 30rpx 0;
		display: flex;
	}

	.secondhanxq .aboutshop .about {
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
	}

	.secondhanxq .aboutshop {
		margin: 18rpx 0;
		background-color: #fff;
		padding: 30rpx 18rpx;
	}

	.secondhanxq .Commoditydetails .imgs image {
		width: 100%;
	}

	.secondhanxq .Commoditydetails .imgs {
		width: 100%;
	}

	.secondhanxq .Commoditydetails .texta {
		margin: 30rpx 0;
		color: #222222;
		font-size: 24rpx;
	}

	.secondhanxq .Commoditydetails .title {
		color: #222222;
		font-size: 28rpx;
		font-weight: bold;
	}


	.secondhanxq .Commoditydetails {
		padding: 30rpx 18rpx;
		background-color: #fff;
	}

	.secondhanxq .secondname .secondnamebottom .secondtow div {
		margin: auto 12rpx;
		color: #999999;
		font-size: 24rpx;
	}

	.secondhanxq .secondname .secondnamebottom .secondtow Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.secondhanxq .secondname .secondnamebottom .secondtow {
		width: 420rpx;
		padding: 0 15rpx;
		height: 50rpx;
		background-color: #f5f5f5;
		border-radius: 25rpx;
		display: flex;
	}

	.secondhanxq .secondname .secondnamebottom .secondone div:last-child {
		margin: auto 0;
		color: #999999;
		font-size: 20rpx;
	}

	.secondhanxq .secondname .secondnamebottom .secondone .firstdiv {
		flex: 1;
		margin: auto 10rpx;
		color: #222222;
		font-size: 24rpx;
	}

	.secondhanxq .secondname .secondnamebottom .secondone image {
		width: 50rpx;
		height: 50rpx;
		background-color: #3c9cff;
		border-radius: 50%;
	}

	.secondhanxq .secondname .secondnamebottom .secondone {
		display: flex;
		justify-content: space-between;
		margin-bottom: 15rpx;
	}

	.secondhanxq .secondname .secondnamebottom {
		padding: 20rpx 0;
	}

	.secondhanxq .secondname .secondnametop .total div:last-child {
		color: #999999;
		font-size: 20rpx;
		margin: auto 0;
	}

	.secondhanxq .secondname .secondnametop .total div:first-child span {
		font-size: 32rpx;
	}

	.secondhanxq .secondname .secondnametop .total div:first-child {
		color: #3c9cff;
		font-size: 22rpx;
		font-weight: bold;
		margin: auto 0;
	}

	.secondhanxq .secondname .secondnametop .total {
		display: flex;
		justify-content: space-between;
	}

	.secondhanxq .secondname .secondnametop .name {
		color: #222222;
		font-size: 32rpx;
		font-weight: bold;
		margin-bottom: 60rpx;
	}

	.secondhanxq .secondname .secondnametop {
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		flex-direction: column;
		padding: 20rpx 0;
	}

	.secondhanxq .secondname {
		padding: 0 18rpx;
		background-color: #fff;
	}

	.secondhanxq .secondlb .swiper {
		width: 100%;
		height: 100%;
	}

	.secondhanxq .secondlb .currents {
		position: absolute;
		width: 80rpx;
		height: 50rpx;
		background-color: #000000;
		border-radius: 25rpx;
		opacity: 0.4;
		bottom: 18rpx;
		right: 18rpx;
		color: #eeeeee;
		font-size: 24rpx;
		text-align: center;
		line-height: 50rpx;
	}

	.secondhanxq .secondlb {
		height: 500rpx;
		background-color: #ffdc28;
		position: relative;
	}

	.secondhanxqpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.secondhanxq {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
	}
</style>
