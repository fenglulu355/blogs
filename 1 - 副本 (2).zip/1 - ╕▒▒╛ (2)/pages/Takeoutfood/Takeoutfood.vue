<template>
	<view class="shopmenupage">
		<Navigation></Navigation>
		<view class="shopmenu">
			<view class="shopmenuleft">
				<div v-for="(item,index) in menutype" :style="'background-color:'+item.color+';border-left-color:'+item.bordercolor"
				 @click="setmenu(index)">{{item.name}}</div>
			</view>
			<view class="shopmenuright">
				<view class="shopmnuli" v-for="(item,index) in shopmnulis">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<view class="shopright">
						<view class="top">
							<div>酸辣土豆丝</div>
							<div>月售55</div>
						</view>
						<view class="bottom">
							<view class="left"><span></span></view>
							<view class="right">
								<view class="jian" v-if="item.num>0" @click="jian(index)">-</view>
								<view class="num" v-if="item.num>0">{{item.num}}</view>
								<view class="jia" @click="jia(index)">+</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="Specifications" :style="'display:'+displays">
			<view class="Eject">
				<view class="cha" @click="guan">
					{{cha}}
				</view>
				<view class="food">
					<image mode="widthFix" src="../../static/images/orders.jpg"></image>
					<view class="foodejc">
						<view class="foodtop">
							<div>特辣干锅兔</div>
							<div>月售55</div>
						</view>
						<view class="foodbottom">￥<span>99</span></view>
					</view>
				</view>
				<view class="Speci">
					<view class="title">
						辣度
					</view>
					<view class="specilabol">
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
					</view>
				</view>
				<view class="Speci">
					<view class="title">
						辣度
					</view>
					<view class="specilabol">
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
						<div>微辣</div>
					</view>
				</view>
				<view class="sub" @click="takeaway">
					选好了
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				cha:'×',
				displays:'none',
				menutype: [{
						name: '热门推荐',
						color: '#fff',
						bordercolor: '#ff643a'
					},
					{
						name: '精品小炒',
						color: '#f4f4f4',
						bordercolor: '#f4f4f4'
					},
					{
						name: '特色硬菜',
						color: '#f4f4f4',
						bordercolor: '#f4f4f4'
					},
					{
						name: '酒水饮料',
						color: '#f4f4f4',
						bordercolor: '#f4f4f4'
					}
				],
				shopmnulis:[
					{
						name:'酸辣土豆丝',
						num:1
					},
					{
						name:'酸辣土豆丝',
						num:0
					},
					{
						name:'酸辣土豆丝',
						num:0
					},
					{
						name:'酸辣土豆丝',
						num:0
					},
					{
						name:'酸辣土豆丝',
						num:0
					},{
						name:'酸辣土豆丝',
						num:0
					}
				]
			}
		},
		methods: {
			setmenu: function(e) {
				let arr = this.menutype
				for (let i in arr) {
					arr[i].color = '#f4f4f4'
					arr[i].bordercolor = '#f4f4f4'
				}
				arr[e].color = '#fff'
				arr[e].bordercolor = '#ff643a'
			},
			jia:function(e){
				let num = this.shopmnulis[e].num;
				num = num + 1;
				this.shopmnulis[e].num = num;
				this.displays = 'flex'
			},
			jian:function(e){
				let num = this.shopmnulis[e].num;
				num = num - 1;
				this.shopmnulis[e].num = num;
			},
			guan:function(){
				this.displays = 'none'
			},
			takeaway:function(){
				uni.navigateTo({
					url: '../Takeawayorder/Takeawayorder'
				});
			}
		},
		components: {
			Navigation
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	
	.Specifications .Eject .sub{
		margin: 0 auto;
		width: 714rpx;
		height: 80rpx;
		background-color: #f5bc32;
		border-radius: 5rpx;
		text-align: center;
		line-height: 80rpx;
		color: #222222;
		font-size: 28rpx;
		margin-top: 35rpx;
	}
	
	.Specifications .Eject .Speci .specilabol div{
		margin: 10rpx;
		width: 220rpx;
		height: 50rpx;
		background-color: #efefef;
		border-radius: 25rpx;
		text-align: center;
		line-height: 50rpx;
		color: #222222;
		font-size: 24rpx;
	}
	
	.Specifications .Eject .Speci .specilabol{
		display: flex;
		flex-wrap: wrap;
	}
	
	.Specifications .Eject .Speci .title{
		height: 70rpx;
		line-height: 70rpx;
		color: #222222;
		font-size: 24rpx;
	}
	
	.Specifications .Eject .Speci{
		margin-bottom: 30rpx;
	}
	
	.Specifications .Eject .food .foodejc .foodbottom span{
		font-size: 32rpx;
	}
	
	.Specifications .Eject .food .foodejc .foodbottom{
		font-weight: bold;
		color: #ff643a;
		font-size: 22rpx;
	}
	
	.Specifications .Eject .food .foodejc .foodtop div:last-child{
		color: #999999;
		font-size: 22rpx;
	}
	
	.Specifications .Eject .food .foodejc .foodtop div:first-child{
		color: #222222;
		font-size: 24rpx;
	}
	
	.Specifications .Eject .food .foodejc{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
	
	.Specifications .Eject .food image{
		width: 160rpx;
		height: 160rpx;
		border-radius: 5rpx;
		border: solid 1rpx #f8f8f8;
		margin-right: 20rpx;
	}
	
	.Specifications .Eject .food{
		display: flex;
		margin-bottom: 15rpx;
	}
	
	.Specifications .Eject .cha{
		position: absolute;
		font-size: 40rpx;
		color: #222222;
		right: 40rpx;
		top: 10rpx;
	}

	.Specifications .Eject {
		height: 740rpx;
		background-color: #ffffff;
		padding: 30rpx 18rpx;
		position: relative;
	}

	.Specifications {
		width: 100%;
		height: 89%;
		position: fixed;
		bottom: 0;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
	}

	.shopmenupage {
		display: flex;
		flex-direction: column;
		height: 100%;
	}

	.shopmenu {
		flex: 1;
		display: flex;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .bottom .right .jia {
		width: 46rpx;
		height: 46rpx;
		background-color: #f5bc32;
		border-radius: 50%;
		margin: auto 0;
		font-size: 28rpx;
		color: #222222;
		text-align: center;
		line-height: 46rpx;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .bottom .right .num {
		margin: auto 10rpx;
		color: #222222;
		font-size: 28rpx;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .bottom .right .jian {
		width: 46rpx;
		height: 46rpx;
		border: solid 2rpx #f2f2f2;
		border-radius: 50%;
		margin: auto 0;
		font-size: 28rpx;
		color: #999999;
		text-align: center;
		line-height: 46rpx;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .bottom .right {
		display: flex;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .bottom .left span {
		font-size: 32px;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .bottom .left {
		color: #ff643a;
		font-size: 22rpx;
		font-weight: bold;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .bottom {
		display: flex;
		justify-content: space-between;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .top div:last-child {
		color: #999999;
		font-size: 22rpx;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright .top div:first-child {
		color: #222222;
		font-size: 24rpx;
	}

	.shopmenu .shopmenuright .shopmnuli .shopright {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.shopmenu .shopmenuright .shopmnuli image {
		width: 160rpx;
		height: 160rpx;
		border-radius: 5rpx;
		border: solid 1rpx #f8f8f8;
		margin-right: 20rpx;
	}

	.shopmenu .shopmenuright .shopmnuli {
		display: flex;
		margin-bottom: 30rpx;
	}


	.shopmenu .shopmenuright {
		flex: 1;
		overflow: auto;
		padding: 40rpx 15rpx;
	}

	.shopmenu .shopmenuleft div {
		height: 100rpx;
		background-color: #f4f4f4;
		border-left: 4rpx solid #f4f4f4;
		text-align: center;
		line-height: 100rpx;
		border-bottom: 1rpx solid #fff;
		color: #222222;
		font-size: 24rpx;
	}

	.shopmenu .shopmenuleft {
		background-color: #f4f4f4;
		width: 160rpx;
	}
</style>
