<template>
	<view class="newamendpage">
		<Navigation></Navigation>
		<view class="newamend">
			<view class="Location" @click="location">
				<Iconfonts name="icon-miaozhunjing2" size="25rpx" colors="#f5bc32" />
				<div>定位到当前位置</div>
			</view>
			<view class="information">
				<view class="infoname">
					<div>收货人</div>
					<div><input type="text" placeholder="请填写姓名"></div>
				</view>
				<view class="infoname">
					<div>联系电话</div>
					<div><input type="text" placeholder="请填写联系电话"></div>
				</view>
				<view class="infoname" @click="open">
					<div>配送地址</div>
					<div>
						<p>请选择省、市、区</p>
						<Iconfonts name="icon-you" size="32rpx" colors="#999999" />
					</div>
				</view>
				<view class="detaiaddr">
					<input type="text" placeholder="请填写详细地址(街道、楼牌号等)">
				</view>
				<view class="infoname">
					<div>设为默认地址</div>
					<div @click="Takeinverse">
						<radio value="r1" color="#F5BC32" :checked="istrue" />
					</div>
				</view>
			</view>
			<Levelthree :sty="stys" @Close="Close"></Levelthree>
			<view class="Sure">
				确定
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import Levelthree from '../../components/Levelthree.vue'
	import amap from '../../components/demo/utils/amap-wx.js'
	export default {
		data() {
			return {
				amapPlugin: null,
				key: '602542b03b0eca67a24e5badc7b34660',
				scroolid: '',
				stys: 'none',
				istrue:false,
				weather: {
					hasData: false,
					data: []
				}
			}
		},
		onShow: function() {
			this.amapPlugin = new amap.AMapWX({
				key: this.key
			});
		},
		methods: {
			location: function() {
				uni.showLoading({
					title: '获取定位中...'
				});
				this.amapPlugin.getRegeo({
					success: (data) => {
						// console.log(data);
						// console.log(data[0].regeocodeData.addressComponent);
						// this.city = data[0].regeocodeData.addressComponent.city+data[0].regeocodeData.addressComponent.district;
						// this.addr = data[0].desc;
						uni.hideLoading();
					}
				});
			},
			open: function() {
				this.stys = 'flex'
			},
			Close: function() {
				this.stys = 'none'
			},
			Takeinverse:function(){
				this.istrue = !this.istrue
			}
		},
		components: {
			Navigation,
			Iconfonts,
			Levelthree
		}
	}
</script>

<style>
	page {
		height: 100vh;
	}
	.Sure{
		height: 96rpx;
		background-color: #f5bc32;
		position: fixed;
		bottom: 0;
		width: 100%;
		text-align: center;
		line-height: 96rpx;
		color: #222222;
		font-size: 32rpx;
	}

	.newamendpage {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.newamend .information .detaiaddr {
		height: 96rpx;
		line-height: 96rpx;
		color: #999999;
		font-size: 24rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		border-bottom: 1rpx solid #f2f2f2;
	}
	
	.newamend .information .infoname:last-child{
		border: none;
	}

	.newamend .information .infoname div:last-child Iconfonts {
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.newamend .information .infoname div:last-child input {
		font-size: 24rpx;
		text-align: right;
		color: #999999;
	}

	.newamend .information .infoname div:last-child p {
		margin: auto 0;
	}

	.newamend .information .infoname div:last-child {
		color: #999999;
		margin: auto 0;
		font-size: 24rpx;
		text-align: right;
		display: flex;
	}

	.newamend .information .infoname div:first-child {
		margin: auto 0;
		color: #222222;
		font-size: 24rpx;
	}

	.newamend .information .infoname {
		height: 96rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.newamend .information {
		background-color: #ffffff;
		padding: 0 18rpx;
	}

	.newamend .Location div {
		margin: auto 0;
		color: #f5bc32;
		font-size: 28rpx;
	}

	.newamend .Location Iconfonts {
		margin: auto 14rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.newamend .Location {
		margin: 18rpx 0;
		height: 96rpx;
		background-color: #ffffff;
		display: flex;
		justify-content: center;
	}

	.newamend {
		flex: 1;
		background-color: #f8f8f8;
		overflow: auto;
		display: flex;
		flex-direction: column;
	}
</style>
