<template>
	<view class="withpage">
		<Navigation></Navigation>
		<view class="withdraw">
			<view class="waitfor">
				<div>退</div>
				<div>
					<h2>等待商家处理</h2>
					<p>如果商家同意：申请将达成，请尽快退回商品如果商家拒绝：你可以再次申请，或者申请平台介入如果商家未处理：超过4天23时59分申请达成，系统会发送默认地址，请尽快寄回商品</p>
				</div>
			</view>
			<view class="waitdetails">
				退款详情
			</view>
			<view class="refund">
				<div>退款类型</div>
				<div>我要退货</div>
			</view>
			<view class="refund">
				<div>退款金额</div>
				<div style="color: #ff643a;">¥199.99</div>
			</view>
			<view class="refund">
				<div>退款原因</div>
				<div>质量问题</div>
			</view>
		</view>
		<view class="cancel">
			取消申请
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		components:{
			Navigation
		}
	}
</script>

<style>
	.cancel{
		width: 100%;
		height: 96rpx;
			background-color: #f5bc32;
			text-align: center;
			line-height: 96rpx;
			color: #222222;
			font-size: 32rpx;
			position: fixed;
			bottom: 0;
	}
page{
	height: 100vh;
}
.withdraw .refund div:last-child{
	color: #222222;
	font-size: 28rpx;
	margin: auto 0;
}
.withdraw .refund div:first-child{
	color: #999999;
	font-size: 28rpx;
	margin: auto 0;
}
.withdraw .refund{
	height: 100rpx;
	padding: 0 18rpx;
	background-color: #fff;
	margin-bottom: 1rpx;
	display: flex;
	justify-content: space-between;
}
.withdraw .waitdetails{
	height: 72rpx;
	line-height: 72rpx;
	padding: 0 18rpx;
	color: #999999;
	font-size: 24rpx;
}
.withpage{
	height: 100%;
	display: flex;
	flex-direction: column;
}
.withdraw .waitfor div:last-child p{
	color: #666666;
	font-size: 24rpx;
}
.withdraw .waitfor div:last-child h2{
	color: #222222;
	font-size: 32rpx;
	font-weight: bold;
	margin-bottom: 25rpx;
}
.withdraw .waitfor div:last-child{
	display: flex;
	flex-direction: column;
	justify-content: space-between;
}
.withdraw .waitfor div:first-child{
	width: 40rpx;
	height: 40rpx;
	border: solid 2rpx #222222;
	color: #222222;
	font-size: 26rpx;
	font-weight: bold;
	text-align: center;
	line-height: 40rpx;
	border-radius: 50%;
	margin-right: 20rpx;
	flex-shrink: 0;
}
.withdraw .waitfor{
	padding: 40rpx 18rpx;
	/* height: 196rpx; */
	background-color: #F8F2E4;
	display: flex;
}
.withdraw{
	flex: 1;
	background-color: #f8f8f8;
}
</style>
