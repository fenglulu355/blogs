<template>
	<view class="seckillxq">
		<Navigation></Navigation>
		<view class="commodity">
			<view class="commodWheel">
				<swiper class="swiper" autoplay="true" interval="3000" duration="300" @change="wheelsa">
					<swiper-item v-for="(item,index) in wheelimg" :key="item" :style="{backgroundImage: 'url(' + item + ')'}">
						<!-- <image mode="widthFix" :src="item"></image> -->
					</swiper-item>
				</swiper>
				<div class="currents">{{current}}/{{wheelimg.length}}</div>
			</view>
			<view class="Limited">
				<view class="limimg">
					<image mode="widthFix" src="../../static/images/miaosha.png"></image>
				</view>
				<view class="Countdown"></view>
				<view class="daojishi">
					<view class="djstxt">距秒杀结束还有</view>
					<uni-countdown :second="1000" @timeup="timeup" />
				</view>
			</view>
			<view class="timeout">
				<view class="timeoutop">
					<div>九阳5L智能电饭煲</div>
					<div>已抢：55件</div>
				</view>
				<view class="timeoubottom">
					<view class="timeleft">
						<div>￥<span>299</span></div>
						<div>秒杀立省￥200.00</div>
					</view>
					<view class="timeright">
						<div>
							<Iconfonts name="icon-fenxiang" size="35rpx" colors="#dddddd" />
							<span>分享</span>
						</div>
						<div>
							<Iconfonts name="icon-xingxing" size="35rpx" colors="#dddddd" />
							<span>收藏</span>
						</div>
					</view>
				</view>
			</view>
			<view class="Choice">
				<view class="choiceleft">已选：</view>
				<view class="choicezhon">九阳5L智能电饭煲</view>
				<view class="choiceright">
					<image mode="widthFix" src="../../static/images/right.png"></image>
				</view>
			</view>
			<view class="comment">
				<view class="commentitle">
					<div>用户评论</div>
					<div>全部评论（ 145 条）</div>
				</view>
				<view class="commentlabol">
					<view class="commentlis" v-for="item in 3" :key="item">晒图评价 99</view>
				</view>
				<view class="details">
					<view class="detailsli">
						<view class="userdetail" v-for="item in 3" :key="item">
							<view class="portrait" style="background-image: url('../../static/images/orders.jpg');"></view>
							<view class="usercontent">
								<view class="username">
									<div>流沙包</div>
									<div>2019.03.16</div>
								</view>
								<view class="Stars">
									<Iconfonts name="icon-xingxing" size="20rpx" :colors="item" v-for="item in imgcolor" :key="item" />
								</view>
								<view class="userComments">
									<div class='usertext'>味道非常好，好吃得快飞起来了！</div>
									<div class='userimg'>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
										<image mode="widthFix" src="../../static/images/orders.jpg"></image>
									</div>
								</view>
							</view>
						</view>
					</view>
					<view class="detailMore">查看全部评论{{right}}</view>
				</view>
			</view>
			<view class="Shopowner">
				<view class="shopimg" style="background-image: url('../../static/images/orders.jpg');"></view>
				<view class="shopnames">
					<view class="shoptitle">
						<view class="shopleft">永丰百货(科华店)</view>
						<view class="shopright">
							<div>订</div>
							<div>买</div>
						</view>
					</view>
					<view class="shoptime">
						<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
						<div>营业时间 6:00-20:30</div>
					</view>
					<view class="shopaddr">
						<Iconfonts name="icon-shijian" size="25rpx" colors="#f0cf26" />
						<div class="addr">人民南路北段4号</div>
						<div>{{left}}50m</div>
					</view>
				</view>
			</view>
			<view class="Commoditydetails">
				<div class='commoditydetailstitle'>
					<div class="comleft">
						<image mode="widthFix" src="../../static/images/zuo.png"></image>
					</div>
					<div class="comdeta">商品详情</div>
					<div class="comleft">
						<image mode="widthFix" src="../../static/images/you.png"></image>
					</div>
				</div>
				<view>详情富文本</view>
			</view>
			<view class="purchase">
				<view class="purleft">加入购物车</view>
				<view class="puright">立即购买</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Navigation from '../../components/Navigation.vue'
	import Iconfonts from '../../components/iconfonts.vue'
	import uniCountdown from "../../components/uni-countdown/uni-countdown.vue"
	export default {
		data() {
			return {
				wheelimg: ['../../static/images/orders.jpg', '../../static/images/orders.jpg', '../../static/images/orders.jpg',
					'../../static/images/orders.jpg'
				],
				current: 1,
				right: '>',
				imgcolor: ['#999999', '#999999', '#999999', '#999999', '#999999'],
				left: '<'
			}
		},
		methods: {
			wheelsa: function(e) {
				this.current = e.detail.current + 1;
				// console.log(e.detail.current);
			},
			timeup: () => {
				uni.showToast({
					title: '时间到'
				})
			}
		},
		components: {
			Navigation,
			uniCountdown,
			Iconfonts
		}
	}
</script>

<style>
	.seckillxq .commodity .purchase .puright{
		width: 50%;
		height: 100%;
		background-color: #ff643a;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 100rpx;
	}
	.seckillxq .commodity .purchase .purleft{
		width: 50%;
		height: 100%;
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 100rpx;
		background-color: #f5bc32;
	}
	.seckillxq .commodity .purchase{
		height: 100rpx;
		width: 100%;
		display: flex;
		position: fixed;
		bottom: 0;
	}
	.seckillxq .commodity .Commoditydetails .commoditydetailstitle .comdeta{
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin: auto 20rpx;
	}
	.seckillxq .commodity .Commoditydetails .commoditydetailstitle .comleft image{
		width: 100%;
		margin: auto 0;
	}
	.seckillxq .commodity .Commoditydetails .commoditydetailstitle .comleft{
		width: 90rpx;
		margin: auto 0;
		display: flex;
	}
	.seckillxq .commodity .Commoditydetails .commoditydetailstitle{
		height: 84rpx;
		display: flex;
		justify-content: center;
	}
	.seckillxq .commodity .Commoditydetails{
		background-color: #fff;
		margin-bottom: 120rpx;
	}
	.seckillxq .commodity .Shopowner .shopnames .shopaddr div {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin: auto 0;
	}

	.seckillxq .commodity .Shopowner .shopnames .shopaddr .addr {
		flex: 1;
	}

	.seckillxq .commodity .Shopowner .shopnames .shopaddr Iconfonts {
		margin-right: 15rpx;
		line-height: 22rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shopaddr {
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptime Iconfonts {
		line-height: 22rpx;
		margin-right: 15rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptime div {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin: auto 0;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptime {
		display: flex;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright div {
		text-align: center;
		line-height: 34rpx;
		font-size: 24rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright div:last-child {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #f5bc32;
		color: #f5bc32;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright div:first-child {
		width: 34rpx;
		height: 34rpx;
		border-radius: 3rpx;
		border: solid 1rpx #23c88c;
		color: #23c88c;
		font-size: 24rpx;
		margin-right: 10rpx;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopright {
		display: flex;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle .shopleft {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seckillxq .commodity .Shopowner .shopnames .shoptitle {
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .Shopowner .shopnames {
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.seckillxq .commodity .Shopowner .shopimg {
		width: 100rpx;
		height: 100rpx;
		background-color: #dcdcdc;
		border-radius: 5rpx;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
		margin-right: 20rpx;
	}

	.seckillxq .commodity .Shopowner {
		margin: 18rpx 0;
		height: 124rpx;
		background-color: #ffffff;
		padding: 30rpx 18rpx;
		display: flex;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments .userimg image {
		width: 141rpx;
		height: 141rpx;
		border-radius: 10rpx;
		border-radius: 5rpx;
		margin-right: 15rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments .userimg {
		display: flex;
		flex-wrap: wrap;
		margin: 15rpx 0;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments .usertext {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #2d2d2d;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .userComments {
		margin: 15rpx 0;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .Stars Iconfonts {
		line-height: 40rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .Stars {
		display: flex;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .username div:last-child {
		font-size: 24rpx;
		letter-spacing: 0rpx;
		color: #b3b3b3;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .username div:first-child {
		font-size: 28rpx;
		font-weight: bold;
		letter-spacing: 0rpx;
		color: #2d2d2d;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent .username {
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent:last-child {
		margin: 0;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .usercontent {
		flex: 1;
		border-bottom: 1rpx solid #f8f8f8;
		padding-bottom: 15rpx;
		margin-bottom: 25rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail .portrait {
		width: 82rpx;
		height: 82rpx;
		border-radius: 50%;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
		margin-right: 20rpx;
	}

	.seckillxq .commodity .comment .details .detailsli .userdetail {
		display: flex;
		margin-top: 20rpx;
	}

	.seckillxq .commodity .comment .details .detailsli {
		display: flex;
		flex-direction: column;
	}

	.seckillxq .commodity .comment .details .detailMore {
		line-height: 84rpx;
		text-align: center;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seckillxq .commodity .comment .details {}

	.seckillxq .commodity .comment .commentlabol .commentlis:last-child {
		margin: 0;
	}

	.seckillxq .commodity .comment .commentlabol .commentlis {
		padding: 0 32rpx;
		height: 50rpx;
		border-radius: 25rpx;
		border: solid 1rpx #cccccc;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		text-align: center;
		line-height: 50rpx;
		margin-right: 30rpx;
	}

	.seckillxq .commodity .comment .commentlabol {
		display: flex;
		margin: 40rpx 0;
	}

	.seckillxq .commodity .comment .commentitle div:last-child {
		color: #999999;
		font-size: 24rpx;
	}

	.seckillxq .commodity .comment .commentitle div:first-child {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.seckillxq .commodity .comment .commentitle {
		margin-top: 30rpx;
		display: flex;
		justify-content: space-between;
	}

	.seckillxq .commodity .comment {
		background-color: #fff;
		padding: 0 18rpx;
		display: flex;
		flex-direction: column;
	}

	.seckillxq .commodity .Choice .choiceright image {
		width: 100%;
		margin: auto 0;
	}

	.seckillxq .commodity .Choice .choiceright {
		width: 24rpx;
		display: flex;
		margin: auto 0;
	}

	.seckillxq .commodity .Choice .choicezhon {
		flex: 1;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 96rpx;
		letter-spacing: 0rpx;
		color: #333333;
	}

	.seckillxq .commodity .Choice .choiceleft {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 96rpx;
		letter-spacing: 0rpx;
		color: #999999;
	}

	.seckillxq .commodity .Choice {
		margin: 17rpx 0;
		height: 96rpx;
		background-color: #ffffff;
		display: flex;
		justify-content: space-between;
		padding: 0 18rpx;
	}
	.seckillxq .commodity .timeout .timeoubottom .timeright div Iconfonts{
		margin: 0 auto;
		text-align: center;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeright div span{
		color: #666666;
		font-size: 22rpx;
		text-align: center;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeright div{
		display: flex;
		flex-direction: column;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeright div:first-child{
		margin-right: 40rpx;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeright{
		display: flex;
		align-items: flex-end;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeleft div:last-child{
		width: 183rpx;
		height: 31rpx;
		background-color: #ffefeb;
		color: #ff643a;
		font-size: 20rpx;
		text-align: center;
		line-height: 31rpx;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeleft div:first-child span{
		font-size: 32rpx;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeleft div:first-child{
		color: #ff643a;
		font-size: 22rpx;
		margin-right: 10rpx;
	}
	
	.seckillxq .commodity .timeout .timeoubottom .timeleft{
		display: flex;
		align-items: flex-end;
	}
	
	.seckillxq .commodity .timeout .timeoubottom{
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
	}
	
	.seckillxq .commodity .timeout .timeoutop div:last-child{
		color: #999999;
		font-size: 22rpx;
	}
	
	.seckillxq .commodity .timeout .timeoutop div:first-child{
		color: #222222;
		font-size: 32rpx;
		font-weight: bold;
	}

	.seckillxq .commodity .timeout {
		background-color: #ffffff;
		padding: 25rpx 16rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.seckillxq .commodity .Limited .daojishi .djstxt {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #222222;
		text-align: center;
	}

	.seckillxq .commodity .Limited .daojishi {
		margin: auto 0;
		z-index: 2;
		margin-right: 15rpx;
	}

	.seckillxq .commodity .Limited .Countdown {
		width: 435rpx;
		height: 240rpx;
		border-radius: 50%;
		background-color: #fff;
		top: -35rpx;
		right: -20rpx;
		position: absolute;
	}

	.seckillxq .commodity .Limited .limimg image {
		width: 100%;
		margin: auto 0;
	}

	.seckillxq .commodity .Limited .limimg {
		width: 266rpx;
		display: flex;
		margin: auto 0;
		margin-left: 40rpx;
	}

	.seckillxq .commodity .Limited {
		height: 89rpx;
		padding: 5rpx;
		background-color: #f5bc32;
		display: flex;
		justify-content: space-between;
		overflow: hidden;
		position: relative;
	}

	.seckillxq .commodity .commodWheel .currents {
		position: relative;
		width: 80rpx;
		height: 50rpx;
		background-color: #000000;
		border-radius: 25rpx;
		opacity: 0.4;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #eeeeee;
		text-align: center;
		line-height: 50rpx;
		bottom: 68rpx;
		right: -643rpx;
	}
	
	.seckillxq .commodity .commodWheel .swiper swiper-item{
		background-color: #666666;
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
	}

	.seckillxq .commodity .commodWheel .swiper {
		width: 100%;
		height: 100%;
	}

	.seckillxq .commodity .commodWheel {
		height: 500rpx;
		background-color: #ffffff;
		position: relative;
	}

	.seckillxq .commodity {
		flex: 1;
		overflow: auto;
		background-color: #f8f8f8;
	}

	.seckillxq {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	page {
		height: 100vh;
	}
</style>
