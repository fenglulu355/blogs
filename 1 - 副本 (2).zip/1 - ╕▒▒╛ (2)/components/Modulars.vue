<template>
	<view class="modulars">
		<view class="modtitle">
			<div class='modLabel' :style="'background:'+ content.color">{{content.title}}</div>
			<div class='modlab' v-for="item in content.child" :key="item" :style="'background:'+ content.color"  @click="toSearchResult(item,index)">
			{{item.title}}</div>
			<div class='modlab' :style="'background:'+ content.color">其他</div>
		</view>
		<view class='modtext'> 
			<view class="modleft">
				<div class='modone' v-for="(item,index) in content.child[0].goods" :key="item">
					<image mode="scaleToFill" :src="bashurl+item.thumb"></image>
				
					<div>{{item.title}}</div>
				</div>
			</view>
			<view class="modright">
				<div class='modrightli' v-if="modrightlis" v-for="item in modrightlis" :key="item">
					<image mode="scaleToFill" :src="bashurl+item.image_url"></image>
					<view class='modname'>{{item.name}}</view>
					<view class='modtotal'>
						<view>￥<span>{{item.price}}</span></view>
						<view>￥<span>{{item.mktprice}}</span></view>
					</view>
					<view style="display: flex;flex-wrap: wrap;">
						<div class='modlabol' v-for="items in item.tags" :key="items">{{items}}</div>
					</view>
				</div>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState,
		mapActions
	} from 'vuex';
	export default {
		data() {
			return {
				modones:[],
				modrightlis:[]
			};
		},
		computed: {
			...mapState(['Modularsli','bashurl'])
		},
		created:function(){
		this.modrightlis=this.Modularsli
		// console.log(this.modrightlis,"this.modrightlis")

		},
		methods:{
			toSearchResult(item,index){
				// let
				uni.navigateTo({
					url: `../searchResult/searchResult?id=${item.id}`
				});
				console.log(item,"123165464")
			}
		},
		props:['content']
	}
</script>

<style>
	.modulars .modtext .modright .modrightli .modlabol {
		/* width: 120rpx; */
		padding: 0 20rpx;
		height: 30rpx;
		margin: 0 3rpx;
		background-color: #fef2ee;
		font-family: PingFang-SC-Regular;
		font-size: 18rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff683a;
		text-align: center;
		line-height: 30rpx;
	}

	.modulars .modtext .modright .modrightli .modtotal view:last-child span {
		font-size: 24rpx;
	}

	.modulars .modtext .modright .modrightli .modtotal view:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		letter-spacing: 0rpx;
		color: #999999;
		text-decoration: line-through;
		text-indent: 8rpx;
	}

	.modulars .modtext .modright .modrightli .modtotal view:first-child span {
		font-family: San-Francisco-Display-Medium;
		font-size: 24rpx;
		font-weight: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
	}

	.modulars .modtext .modright .modrightli .modtotal view:first-child {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ff643a;
	}

	.modulars .modtext .modright .modrightli .modtotal {
		display: flex;
	}

	.modulars .modtext .modright .modrightli .modname {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
	}

	.modulars .modtext .modright .modrightli image {
		width: 100%;
		height: 200rpx;
		background-color: #222222;
		border-radius: 5rpx;
	}
	
	.modulars .modtext .modright .modrightli:last-child{
		margin: 0;
	}

	.modulars .modtext .modright .modrightli {
		width: 200rpx;
		flex-shrink: 0;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-right: 15rpx;
	}

	.modulars .modtext .modright {
		flex: 1;
		margin-left: 4rpx;
		background-color: #fff;
		display: flex;
		flex-wrap: nowrap;
		overflow: auto;
		padding: 15rpx;
	}

	.modulars .modtext .modleft .modone div {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.modulars .modtext .modleft .modone image {
		width: 100%;
		height: 82rpx;
		border-radius: 5rpx;
	}

	.modulars .modtext .modleft .modone {
		max-height: 50%;
		width: 146rpx;
		background-color: #fff;
		margin-right: 2rpx;
		margin-bottom: 2rpx;
		padding: 15rpx;
	}

	.modulars .modtext .modleft {
		width: 360rpx;
		display: flex;
		flex-wrap: wrap;
	}

	.modulars .modtext {
		width: 100%;
		display: flex;
	}

	.modulars .modtitle .modlab {
		padding: 0 20rpx;
		height: 40rpx;
		border-radius: 20rpx;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 40rpx;
		margin: auto 0;
		margin-right: 16rpx;
	}

	.modulars .modtitle .modLabel {
		width: 80rpx;
		height: 80rpx;
		border-radius: 0rpx 0rpx 20rpx 0rpx;
		margin-right: 16rpx;
		font-family: PingFang-SC-Bold;
		font-size: 36rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 80rpx;
	}

	.modulars .modtitle {
		width: 100%;
		height: 80rpx;
		background-color: #ffffff;
		display: flex;
		margin-bottom: 5rpx;
	}

	.modulars {
		width: 714rpx;
		margin: 0 auto;
		margin-bottom: 17rpx;
	}
</style>
