<template>
	<view>
		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
		<view class="navsw">
			<view class='Jump'>
				<div @click="rights">
					<image mode="widthFix" src="../static/images/nav1.png"></image>
				</div>
				<div @click="homes">
					<image mode="widthFix" src="../static/images/nav2.png"></image>
				</div>
			</view>
			<view class='pagetitle'>本城商铺</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		},
		methods: {
			rights: function() {
				uni.navigateBack({
					delta: 1
				});
			},
			homes: function() {
				uni.switchTab({
					url: '/pages/shophome/shophome'
				});
			}
		}
	}
</script>

<style>
	.pagetitle {
		font-family: PingFang-SC-Bold;
		font-size: 36rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0px;
		color: #000000;
		margin: auto 0;
	}

	.navsw .Jump div:last-child image {
		width: 34rpx;
		margin: auto 0;
	}

	.navsw .Jump div:last-child {
		width: 49%;
		display: flex;
		justify-content: center;
	}

	.navsw .Jump div:first-child image {
		width: 24rpx;
		margin: auto 0;
	}

	.navsw .Jump div:first-child {
		display: flex;
		justify-content: center;
		width: 49%;
		border-right: 1rpx solid #e2e2e2;
	}

	.navsw .Jump {
		width: 176rpx;
		height: 39rpx;
		background-color: #ffffff;
		border-radius: 32rpx;
		border: solid 1rpx #ebebeb;
		display: flex;
		padding: 12rpx 0;
		margin: auto 0;
		position: absolute;
		left: 18rpx;
		top: 0;
		bottom: 0;
		margin: auto 0;
	}

	.navsw {
		height: 90rpx;
		background-color: #fff;
		display: flex;
		padding: 0 15rpx;
		position: relative;
		justify-content: center;
	}

	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
	}
</style>
