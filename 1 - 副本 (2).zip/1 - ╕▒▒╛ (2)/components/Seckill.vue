<template>
	<view>
		<swiper class="swiper" autoplay="true" interval="3000" duration="300" indicator-dots="true" indicator-active-color="#fff">
			<swiper-item v-for="item in seckillimg" :key="item" @click="setsrc(item.position_id)">
				<image mode="widthFix" :src="bashurl+item.cover"></image>
			</swiper-item>
		</swiper>
		<view class='chard'>
			<div class='chardli'>
				<div class='charleft'>
					<div>低至9.9元</div>
					<span>每日更新</span>
					<div>秒杀</div>
				</div>
				<div class='charright'>
					<image mode="widthFix" src="../static/images/orders.jpg"></image>
				</div>
			</div>
			<div class='chardli'>
				<div class='charleft'>
					<div>低至9.9元</div>
					<span>每日更新</span>
					<div>拼单</div>
				</div>
				<div class='charright'>
					<image mode="widthFix" src="../static/images/orders.jpg"></image>
				</div>
			</div>
		</view>
	</view>
</template>

<script>
	import {
		mapState,
		mapActions
	} from 'vuex';
	export default {
		data() {
			return {
				seckillimg: [],
			};
		},
		computed: {
			...mapState(['shophomeWheelimg','bashurl'])
		},
		created:function(){
		//获取首页轮播图
		uni.request({
			url: `${this.bashurl}/index/api/get_banner`, //仅为示例，并非真实接口地址。
			method:'POST',
			success: (res) => {
				this.seckillimg = res.data.data
			}
		});
		},
		methods:{
			setsrc:function(e){
				console.log(e)
				//let url='/pages/'
			}
		}
	}
</script>

<style>
	.chard .chardli .charleft span {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #8e9198;
	}

	.chard .chardli .charleft div:last-child {
		width: 60rpx;
		height: 30rpx;
		background-color: #ffdc28;
		border-radius: 15rpx;
		font-family: PingFang-SC-Regular;
		font-size: 18rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		text-align: center;
		line-height: 30rpx;
	}

	.chard .chardli .charleft div:first-child {
		font-family: PingFang-SC-Bold;
		font-size: 30rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}
	
	.chard .chardli .charleft{
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.chard .chardli .charright image {
		width: 100%;
	}

	.chard .chardli .charright {
		width: 120rpx;
		margin: auto 0;
	}

	.chard .chardli {
		margin: auto 0;
		width: 312rpx;
		height: 160rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		display: flex;
		justify-content: space-between;
		padding: 0 20rpx;
	}

	.chard {
		height: 180rpx;
		background-color: #fceeac;
		padding: 0 17rpx;
		display: flex;
		justify-content: space-between;
	}

	.swiper {
		height: 320rpx;
	}

	swiper-item image {
		width: 100%;
	}
</style>
