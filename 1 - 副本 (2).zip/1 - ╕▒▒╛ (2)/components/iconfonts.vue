<template>
	<span class="iconfont" :class="name" :style="'font-size:'+size+';color:'+colors"></span>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		props:['name','size','colors']
	}
</script>

<style>
	
</style>
