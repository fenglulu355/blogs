<template>
	<view class="levelthree" :style="'display:'+sty">
		<view class="levetop" @click="switchs">
			
		</view>
		<view class="Popup">
			<view class="popuptitle">
				<div>已选择：{{one}}-{{tow}}-{{three}}</div>
				<div @click="switchs">关闭</div>
			</view>
			<view class="addressa">
				<scroll-view class="scroll-view_H" show-scrollbar :scroll-into-view="provinceid" scroll-y scroll-with-animation>
					<view class="scrollli" :id="'A'+index" :style="'color:'+item.sty" v-for="(item,index) in provli" @click="provin(index)">
						{{item.name}}
					</view>
				</scroll-view>
				<scroll-view class="scroll-view_H" show-scrollbar :scroll-into-view="cityid" scroll-y scroll-with-animation>
					<view class="scrollli" :id="'B'+index" :style="'color:'+item.sty" v-for="(item,index) in cityli" @click="citys(index)">
						{{item.name}}
					</view>
				</scroll-view>
				<scroll-view class="scroll-view_H" show-scrollbar :scroll-into-view="areaid" scroll-y scroll-with-animation>
					<view class="scrollli" :id="'C'+index" :style="'color:'+item.sty" v-for="(item,index) in areali" @click="areas(index)">
						{{item.name}}
					</view>
				</scroll-view>
			</view>

		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				provinceid: 'A' + 0,
				cityid: 'B' + 0,
				areaid: 'C' + 0,
				one:'四川',
				tow:'成都',
				three:'青羊区',
				provli: [{
						name: '四川',
						sty: '#f5bc32'
					},
					{
						name: '上海',
						sty: '#999999'
					},
					{
						name: '北京',
						sty: '#999999'
					},
					{
						name: '新疆',
						sty: '#999999'
					},
					{
						name: '河北',
						sty: '#999999'
					},
					{
						name: '河南',
						sty: '#999999'
					},
					{
						name: '海南',
						sty: '#999999'
					}
				],
				cityli: [{
						name: '成都',
						sty: '#f5bc32'
					},
					{
						name: '绵阳',
						sty: '#999999'
					},
					{
						name: '宜宾',
						sty: '#999999'
					},
					{
						name: '德阳',
						sty: '#999999'
					},
					{
						name: '九寨沟',
						sty: '#999999'
					},
					{
						name: '乌鲁木齐',
						sty: '#999999'
					},
					{
						name: '资阳',
						sty: '#999999'
					}
				],
				areali: [{
						name: '青羊区',
						sty: '#f5bc32'
					},
					{
						name: '金牛区',
						sty: '#999999'
					},
					{
						name: '龙泉驿区',
						sty: '#999999'
					},
					{
						name: '郫都区',
						sty: '#999999'
					},
					{
						name: '锦江区',
						sty: '#999999'
					},
					{
						name: '高新区',
						sty: '#999999'
					},
					{
						name: '武侯区',
						sty: '#999999'
					}
				]
			};
		},
		props:['sty'],
		methods: {
			provin: function(e) {
				// console.log('A'+(e-2));
				for (let i in this.provli) {
					this.provli[i].sty = '#999999'
					if (i == e) {
						this.provinceid = 'A' + (i - 2);
						this.provli[i].sty = '#f5bc32';
						this.one = this.provli[i].name
					}
				}
			},
			citys: function(e) {
				for (let i in this.cityli) {
					this.cityli[i].sty = '#999999'
					if (i == e) {
						this.cityid = 'B' + (i - 2);
						this.cityli[i].sty = '#f5bc32';
						this.tow = this.cityli[i].name
					}
				}
			},
			areas: function(e) {
				for (let i in this.areali) {
					this.areali[i].sty = '#999999'
					if (i == e) {
						this.areaid = 'C' + (i - 2);
						this.areali[i].sty = '#f5bc32';
						this.three = this.areali[i].name
					}
				}
			},
			switchs:function(e){
				this.$emit('Close')
			}
		}
	}
</script>

<style>
	.levelthree .Popup .addressa .scroll-view_H .scrollli {
		text-align: center;
		line-height: 60rpx;
		font-size: 24rpx;
	}

	.levelthree .Popup .addressa .scroll-view_H {
		height: 100%;
	}

	.levelthree .Popup .addressa {
		flex: 1;
		display: flex;
		padding: 30rpx 20rpx;
	}

	.levelthree .Popup .popuptitle {
		height: 70rpx;
		line-height: 70rpx;
		color: #222222;
		font-size: 24rpx;
		border-bottom: 1rpx solid #f2f2f2;
		display: flex;
		justify-content: space-between;
	}

	.levelthree .Popup {
		height: 420rpx;
		background-color: #fff;
		padding: 15rpx 18rpx;
		display: flex;
		flex-direction: column;
	}
	.levelthree .levetop{
		flex: 1;
	}

	.levelthree {
		height: 89%;
		background-color: rgba(0, 0, 0, 0.5);
		width: 100%;
		position: fixed;
		z-index: 2;
		top: 152rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
</style>
