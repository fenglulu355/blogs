<template>
	<view class="classinfo">
		<scroll-view scroll-y scroll-into-view="a4" class="classinfoleft">
			<view @click="setclassinfo(index)" class="classinfoli" v-for="(item,index) in classinfoli" :style="'background-color:'+item.back+';border-left-color:'+item.backleft">
				{{item.name}}
			</view>
		</scroll-view>
		<scroll-view scroll-y scroll-into-view="a4" class="classinforight">
			<view class="classinforightli" v-for="item in 10">
				<view class="title">
					家具
				</view>
				<view class="lis" >
					<div v-for="item in 6">桌子</div>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				classinfoli:[
					{
						name:'家居用品',
						back:'#fff',
						backleft:'#3c9cff'
					},
					{
						name:'企业用品',
						back:'#f4f4f4',
						backleft:'#f4f4f4'
					},
					{
						name:'古玩乐器',
						back:'#f4f4f4',
						backleft:'#f4f4f4'
					},
					{
						name:'手机数码',
						back:'#f4f4f4',
						backleft:'#f4f4f4'
					},
					{
						name:'鞋靴箱包',
						back:'#f4f4f4',
						backleft:'#f4f4f4'
					},
					{
						name:'男女服装',
						back:'#f4f4f4',
						backleft:'#f4f4f4'
					}
				]
			};
		},
		methods:{
			setclassinfo:function(e){
				let arr = this.classinfoli;
				for(let i in arr){
					arr[i].back = '#f4f4f4'
					arr[i].backleft = '#f4f4f4'
				}
				arr[e].back = '#fff'
				arr[e].backleft = '#3c9cff'
			}
		}
	}
</script>

<style>
	.classinfo .classinforight .classinforightli .lis div{
		margin:5rpx 12rpx;
		width: 210rpx;
		height: 60rpx;
		background-color: #ffffff;
		border-radius: 5rpx;
		color: #222222;
		font-size: 24rpx;
		text-align: center;
		line-height: 60rpx;
		flex-shrink: 0;
	}
	.classinfo .classinforight .classinforightli .lis{
		display: flex;
		flex-wrap: wrap;
		margin-bottom: 20rpx;
	}
	.classinfo .classinforight .classinforightli .title{
		height: 97rpx;
		line-height: 97rpx;
		padding: 0 15rpx;
		color: #3c9cff;
		font-size: 24rpx;
	}
	.classinfo .classinforight .classinforightli{
		display: flex;
		flex-direction: column;
	}
	.classinfo .classinforight {
		flex: 1;
		padding: 0 23rpx;
	}

	.classinfo .classinfoleft .classinfoli {
		width: 220rpx;
		height: 100rpx;
		background-color: #ffffff;
		text-align: center;
		line-height: 100rpx;
		color: #222222;
		font-size: 24rpx;
		border-bottom: 1rpx solid #fff;
		border-left: 4rpx solid #f4f4f4;
	}

	.classinfo .classinfoleft {
		width: 220rpx;
		background-color: #f4f4f4;
	}

	.classinfo {
		height: 100%;
		display: flex;
	}
</style>
