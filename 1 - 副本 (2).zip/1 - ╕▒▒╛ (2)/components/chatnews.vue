<template>
	<view class="chatnews" :style="'justify-content:'+ flex" :id="dataid">
		<view class="chatleft" v-if="isme=='0'">
			<image mode="widthFix" :src="img"></image>
			<div v-if="txt">{{txt}}</div>
			<view class="images" v-else>
				<image mode="widthFix" :src="item" v-for="item in addimg"></image>
			</view>
		</view>
		<view class="chatright" v-else>
			<div style="background-color:#f5bc32;"  v-if="txt">{{txt}}</div>
			<view class="images" v-else>
				<image mode="widthFix" :src="item" v-for="item in addimg"></image>
			</view>
			<image mode="widthFix" :src="img"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				flex:'flex-end'
			};
		},
		props:['isme','img','txt','addimg','dataid'],
		created(){
			if(this.isme == 0){
				this.flex = 'flex-start'
			}else{
				this.flex = 'flex-end'
			}
			console.log(this.dataid);
		},
		methods:{
			
		}
	}
</script>

<style>
	image {
		width: 73rpx;
		height: 73rpx;
		border-radius: 50%;
		margin: 0 20rpx;
	}
	
	.images image{
		width:100%;
		margin: 0 ;
		height: auto;
		border-radius: 0;
	}
	
	.images{
		background-color: #ffffff;
		box-shadow: 0px 1rpx 20rpx 0rpx 
			rgba(195, 195, 195, 0.35);
		border-radius: 20rpx;
		padding: 20rpx 20rpx;
		width: 230rpx;
	}
	
	div{
		padding: 20rpx 25rpx;
		background-color: #ffffff;
		box-shadow: 0px 1rpx 20rpx 0rpx 
			rgba(195, 195, 195, 0.35);
		border-radius: 20rpx;
		color: #222222;
		font-size: 28rpx;
	}

	.chatnews {
		display: flex;
		width: 100%;
		margin: 30rpx 0;
	}

	.chatleft {
		display: flex;
	}

	.chatright {
		display: flex;
	}
</style>
