<template>
	<view class="modulars">
		<view class="modtitle">
			<div class='modLabel' :style="'background:'+ content.color">{{content.name}}</div>
			<div class='modlab' v-for="item in content.child" :key="item" :style="'background:'+ content.color">{{item.name}}</div>
			<div class='modlab' :style="'background:'+ content.color">其他</div>
		</view>
		<view class='modtext'>
			<view class='modli' v-for="item in modlis" :key="item">
				<image mode="scaleToFill" :src="item.image_url"></image>
				<view class='modtit'>{{item.name}}</view>
				<view class='modnum'>￥<span>{{item.price}}</span></view>
				<view style="display: flex;flex-wrap: wrap;">
					<div v-if="item.cat_name">{{item.cat_name}}</div>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState,
		mapActions
	} from 'vuex';
	export default {
		data() {
			return {
				modlis:[]
			};
		},
		computed: {
			...mapState(['bashurl'])
		},
		created:function(){
			uni.request({
				url: this.bashurl, //仅为示例，并非真实接口地址。
				data:{
					limit: 8,
					method: "goods.getlist",
					order: "sort asc",
					page: 1,
					where: {cat_id:this.content.id}
				},
				success: (res) => {
					console.log(res.data.data.list);
					this.modlis = res.data.data.list
				}
			});
			
		},
		props: ['content']
	}
</script>

<style>
	.modulars .modtext .modli .modnum span {
		font-size: 24rpx;
	}

	.modulars .modtext .modli .modnum {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #3c9cff;
	}

	.modulars .modtext .modli .modtit {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
	}

	.modulars .modtext .modli div {
		padding: 0 10rpx;
		height: 30rpx;
		margin: 0 3rpx;
		text-align: center;
		line-height: 30rpx;
		background-color: #eaf3fd;
		font-family: PingFang-SC-Regular;
		font-size: 18rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #3c9cff;
	}

	.modulars .modtext .modli image {
		width: 100%;
		height: 200rpx;
		border-radius: 5rpx;
	}

	.modulars .modtext .modli {
		width: 207rpx;
		height: 328rpx;
		padding: 15rpx;
		background-color: #ffffff;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-right: 2rpx;
		flex-shrink: 0;
	}

	.modulars .modtext {
		width: 100%;
		display: flex;
		overflow: auto;
	}

	.modulars .modtitle .modlab {
		padding: 0 20rpx;
		height: 40rpx;
		border-radius: 20rpx;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 40rpx;
		margin: auto 0;
		margin-right: 16rpx;
	}

	.modulars .modtitle .modLabel {
		width: 80rpx;
		height: 80rpx;
		border-radius: 0rpx 0rpx 20rpx 0rpx;
		margin-right: 16rpx;
		font-family: PingFang-SC-Bold;
		font-size: 36rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
		text-align: center;
		line-height: 80rpx;
	}

	.modulars .modtitle {
		width: 100%;
		height: 80rpx;
		background-color: #ffffff;
		display: flex;
		margin-bottom: 5rpx;
	}

	.modulars {
		width: 714rpx;
		margin: 0 auto;
		margin-bottom: 17rpx;
	}
</style>
