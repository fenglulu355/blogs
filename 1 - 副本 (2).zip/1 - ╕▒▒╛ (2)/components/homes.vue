<template>
	<view class="content">
		<div class="bg">
			<div class='Headlines'>
				<div><image mode="widthFix" src="../static/images/sjtt.png"></image></div>
				<div>新上线商家单品置顶功能，快去试试吧！</div>
			</div>
		</div>
		<div class='contents'>
			<div class='datas'>
				<div class='datatop'>今日数据</div>
				<div class='databottom'>
					<div class="Quota">
						<div>30,000</div>
						<div class='elements'>销售额(元)</div>
						<div>昨日60,000</div>
					</div>
					<div class="Quota">
						<div>30,000</div>
						<div class='elements'>销售额(元)</div>
						<div>昨日60,000</div>
					</div>
					<div class="Quota">
						<div>30,000</div>
						<div class='elements'>销售额(元)</div>
						<div>昨日60,000</div>
					</div>
				</div>
			</div>
			<div class='Orders'>
				<div class='ordtop'>订单管理</div>
				<div class='ordbottom'>
					<div class='ordModular' @click="order(0)">
						<image mode="widthFix" src="../static/images/dfk.png"></image>
						<span>待付款</span>
					</div>
					<div class='ordModular' @click="order(1)">
						<image mode="widthFix" src="../static/images/dfh.png"></image>
						<span>待发货</span>
					</div>
					<div class='ordModular' @click="order(2)">
						<image mode="widthFix" src="../static/images/dsh.png"></image>
						<span>待收货</span>
					</div>
					<div class='ordModular' @click="order(3)">
						<image mode="widthFix" src="../static/images/kf.png"></image>
						<span>退换货</span>
					</div>
				</div>
			</div>
			<div class="Impurity">
				<div class='impleft' @click="upload">
					<div class='imptitle'>上传商品</div>
					<div class='imptxt'>商品编辑、商品管理</div>
				</div>
				<div class='impright'>
					<div class='imptop'>
						<div class='imptopdiv imptopone' @click="manage">
							<div class='imptitle'>分类管理</div>
							<div class='imptxt'>便捷操作管理</div>
						</div>
						<div class='imptopdiv imptoptow' @click="busine">
							<div class='imptitle'>商铺介绍</div>
							<div class='imptxt'>商铺信息管理</div>
						</div>
					</div>
					<div class='impbottom' @click="coupons">
						<div class='imptitle'>优惠券</div>
						<div class='imptxt'>一键生成优惠信息</div>
					</div>
				</div>
			</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			upload:function(){
				uni.navigateTo({
					url: '../commodities/commodities'
				});
			},
			coupons: function() {
				uni.navigateTo({
					url: '../Coupon/Coupon'
				});
			},
			order: function(e) {
				uni.navigateTo({
					url: `../Orders/Orders?id=${e}`
				});
			},
			busine: function() {
				uni.navigateTo({
					url: '../business/business'
				});
			},
			manage: function() {
				uni.navigateTo({
					url: '../management/management'
				});
			}
		}
	}
</script>

<style>
page {
		height: 100%;
		background-color: #f8f8f8;
	}
	
	.imptoptow{
		background-image: url('../static/images/shangpu.png');
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
	}
	
	.imptopone{
		background-image: url('../static/images/fenlei.png');
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
	}

	.Headlines div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin-left: 15rpx;
	}
	
	.Headlines div:first-child image{
		width: 100%;
	}

	.Headlines div:first-child {
		width: 95rpx;
		margin: auto 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		padding-right: 15rpx;
		border-right: 3rpx solid #f5f5f5;
	}

	.Headlines {
		width: 654rpx;
		height: 30rpx;
		padding: 20rpx 30rpx;
		background-color: #ffffff;
		border-radius: 35rpx;
		margin: 0 auto;
		margin-top: 22rpx;
		display: flex;
		overflow: hidden;
	}

	.datas .databottom .Quota .elements {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
		text-align: center;
		margin: 5rpx 0;
	}

	.datas .databottom .Quota div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #999999;
		text-align: center;
	}

	.datas .databottom .Quota div:first-child {
		font-family: Bahnschrift-Bold;
		font-size: 40rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		text-align: center;
	}

	.datas .databottom .Quota {
		justify-content: center;
	}

	.datas .databottom {
		display: flex;
		justify-content: space-between;
	}

	.datas .datatop {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin-bottom: 50rpx;
	}

	.datas {
		width: 654rpx;
		height: 204rpx;
		padding: 30rpx;
		background-color: #ffffff;
		border-radius: 20rpx;
		margin: 0 auto;
		margin-top: -88rpx;
	}

	.Orders .ordbottom .ordModular span {
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		text-align: center;
	}

	.Orders .ordbottom .ordModular image {
		width: 43rpx;
		margin: 0 auto;
		margin-bottom: 18rpx;
	}

	.Orders .ordbottom .ordModular {
		display: flex;
		flex-direction: column;
		text-align: center;
		justify-content: flex-end;
	}

	.Orders .ordbottom {
		display: flex;
		justify-content: space-between;
	}

	.Orders .ordtop {
		font-family: PingFang-SC-Bold;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin-bottom: 50rpx;
	}

	.Orders {
		width: 654rpx;
		height: 180rpx;
		background-color: #ffffff;
		border-radius: 20rpx;
		margin: 18rpx auto;
		padding: 30rpx;
	}

	.contents .Impurity {
		width: 714rpx;
		margin: 0 auto;
		margin-bottom: 18rpx;
		display: flex;
		justify-content: space-between;
	}

	.contents .Impurity .impright .impbottom {
		height: 140rpx;
		/* background-color: #23c88c; */
		background-image: url('../static/images/quan.png');
		background-position: center;
		background-size: cover;
		background-repeat: no-repeat;
		border-radius: 10px;
		padding: 30rpx 24rpx;
	}

	.contents .Impurity .impright .imptop .imptopdiv {
		width: 166rpx;
		height: 141rpx;
		background-color: #3c9cff;
		border-radius: 10rpx;
		padding: 30rpx 20rpx;
	}

	.contents .Impurity .impright .imptop {
		display: flex;
		justify-content: space-between;
	}

	.contents .Impurity .impright {
		width: 424rpx;
		/* background-color: #23c88c; */
		border-radius: 10rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.imptxt {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		letter-spacing: 0rpx;
		color: #ffffff;
	}

	.imptitle {
		font-family: PingFang-SC-Medium;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		line-height: 40rpx;
		letter-spacing: 0rpx;
		color: #ffffff;
		margin-bottom: 16rpx;
	}

	.contents .Impurity .impleft {
		width: 223rpx;
		height: 358rpx;
		/* background-color: #ff643a; */
		border-radius: 10rpx;
		padding: 26rpx;
		background-image: url('../static/images/scsp.png');
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
	}

	.contents {
		display: flex;
		flex-direction: column;
	}

	.bg {
		height: 200rpx;
		background-color: #ffc528;
		display: flex;
	}
</style>
