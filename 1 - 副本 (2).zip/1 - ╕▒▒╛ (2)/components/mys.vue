<template>
	<view class='my'>
		<div class='users'>
			<div class='Headportrait'></div>
			<div class='headname'>
				<div>特福莱汽车服务中心</div>
				<div>商家管理{{you}}</div>
			</div>
		</div>
		<div class='Customerservice'>
			<div class='cusleft'>
				<div><image mode="widthFix" src="../static/images/ton2.png"></image></div>
				<div>联系客服</div>
			</div>
			<div class='cusright'>
				<img src="../static/images/right.png" alt="">
			</div>
		</div>
		<div class='Customerservice'>
			<div class='cusleft'>
				<div><image mode="widthFix" src="../static/images/ton1.png"></image></div>
				<div>关于同城</div>
			</div>
			<div class='cusright'>
				<img src="../static/images/right.png" alt="">
			</div>
		</div>
		<div class='Sign'>退出登录</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				you:'>'
			};
		}
	}
</script>

<style>
.my .Sign {
		width: 400rpx;
		height: 88rpx;
		background-color: #ffffff;
		border-radius: 44rpx;
		border: solid 1rpx #eeeeee;
		margin: 20rpx auto;
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		text-align: center;
		line-height: 88rpx;
	}

	.my .Customerservice .cusleft div:first-child img {
		width: 26rpx;
		height: 32rpx;
	}
	.my .Customerservice .cusright img{
		width: 100%;
		height: 100%;
	}
	.my .Customerservice .cusright{
		width: 28rpx;
		height: 34rpx;
	}

	.my .Customerservice .cusleft div:last-child {
		margin: auto 0;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		margin-left: 20rpx;
	}
	
	.my .Customerservice .cusleft div:first-child image{
		width: 100%;
	}

	.my .Customerservice .cusleft div:first-child {
		width: 50rpx;
		height: 50rpx;
		border-radius: 50%;
		margin: auto 0;
		text-align: center;
		line-height: 50rpx;
	}

	.my .Customerservice .cusleft {
		display: flex;
	}

	.my .Customerservice {
		width: 654rpx;
		height: 46rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-bottom: 20rpx;
		padding: 25rpx 30rpx;
		display: flex;
		justify-content: space-between;
	}
	.my .users .headname div:last-child img{
		width: 12px;
		height: 10px;
		margin: auto 0;
	}
	.my .users .headname div:last-child {
		width: 140rpx;
		height: 40rpx;
		text-align: center;
		line-height: 40rpx;
		background-color: #ffc528;
		border-radius: 20rpx;
		margin-top: 14rpx;
		font-family: PingFang-SC-Medium;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		display: flex;
		justify-content: center;
	}

	.my .users .headname div:first-child {
		font-family: PingFang-SC-Bold;
		font-size: 36rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.my .users .headname {
		margin-left: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.my .users .Headportrait {
		width: 120rpx;
		height: 120rpx;
		background-color: #ffc528;
		border-radius: 50%;
		margin: auto 0;
	}

	.my .users {
		width: 654rpx;
		height: 120rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 20rpx auto;
		display: flex;
		padding: 30rpx;
	}

	.my {
		height: 100vh;
		background-color: #F8F8F8;
		display: flex;
		flex-direction: column;
	}
</style>
