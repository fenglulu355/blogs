<template>
	<view class="news">
		<div class='notice'>
			<img src="../static/images/tz.png" alt="">
			<p>关注本城商铺公众号，不错过一个消息</p>
		</div>
		<div class='newscontent' @click="secondchat">
			<div class='newone'>
				<image mode="widthFix" src="../static/images/xx3.png"></image>
				<div class='Number'>99</div>
			</div>
			<div class='newtow'>
				<div>订单消息</div>
				<div>你有5笔订单信息可以查看</div>
			</div>
			<div class='newthree'>今天 15:20</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		},
		methods:{
			secondchat:function(){
				uni.navigateTo({
				    url: '/pages/secondchat/secondchat'
				});
			}
		}
	}
</script>

<style>
	.newscontent .newtow div:last-child {
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #999999;
	}

	.newscontent .newtow div:first-child {
		font-family: PingFang-SC-Regular;
		font-size: 32rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 2rpx;
		color: #222222;
	}

	.newscontent .newtow {
		flex: 1;
		margin: auto 24rpx;
	}

	.newscontent .newthree {
		width: 140rpx;
		font-family: PingFang-SC-Regular;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 1rpx;
		color: #999999;
		line-height: 70rpx;
	}

	.newscontent .newone image {
		width: 100%;
		height: 100%;
	}

	.newscontent .newone .Number {
		width: 34rpx;
		height: 34rpx;
		position: absolute;
		border-radius: 50%;
		background-color: #ff643a;
		top: -5rpx;
		right: -5rpx;
		font-family: PingFang-SC-Bold;
		font-size: 22rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0px;
		color: #ffffff;
		text-align: center;
		line-height: 34rpx;

	}

	.newscontent .newone {
		width: 80rpx;
		height: 80rpx;
		margin: auto 0;
		position: relative;
	}

	.newscontent {
		height: 100rpx;
		background-color: #ffffff;
		padding: 25rpx 20rpx;
		display: flex;
		border-radius: 10rpx;
	}

	.news {
		background-color: #F8F8F8;
		height: 100vh;
	}

	.notice {
		height: 60rpx;
		background-color: rgba(60, 156, 255, 0.1);
		padding: 0 18rpx;
		display: flex;
	}

	.notice p {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #3c9cff;
		margin: auto 0;
	}

	.notice img {
		width: 26rpx;
		height: 26rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}
</style>
