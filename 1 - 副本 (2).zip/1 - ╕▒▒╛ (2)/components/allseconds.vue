<template>
	<view class="allseconds">
		<view class="top" :style="'display:'+display">
			<view class="allsecondslabol" v-for="item in secondlabol" :style="'background-color:'+item.background">
				<div :style="'background-color:'+item.labolcolor">{{item.name}}</div>
				<image mode="widthFix" :src="item.img"></image>
			</view>
		</view>
		<view class="bottom">
			<view class="one">
				<view class="tab">
					<view class="tabli" @click="settab(index)" v-for="(item,index) in tab">
						<p>{{item.name}}</p>
						<div :style="'background-color:'+item.color"></div>
					</view>
				</view>
				<view class="labol">
					<div v-for="item in 8">苹果</div>
				</view>
			</view>
			<view class="tow">
				<view class="towli" v-for="item in 10" @click="aecondxq">
					<image mode="widthFix" src="../static/images/orders.jpg"></image>
					<view class="towlibottom">
						<view class="towliones">
							<view class="towlionesa">
								西洋风情茶水杯
							</view>
							<view class="towlionesb">
								<div>￥ <span>99</span></div>
								<div>全新未使用</div>
							</view>
						</view>
						<view class="towliname">
							<image mode="widthFix" src="../static/images/orders.jpg"></image>
							<div>
								<p>你丑你先走</p>
								<p>当前在线</p>
							</div>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				display:'flex',
				secondlabol: [{
						name: '鞋靴箱包',
						background: '#ffc18e',
						img: '../static/images/orders.jpg',
						labolcolor: '#ff9f6f'
					},
					{
						name: '鞋靴箱包',
						background: '#c3e569',
						img: '../static/images/orders.jpg',
						labolcolor: '#a4cd38'
					},
					{
						name: '鞋靴箱包',
						background: '#7bb6ff',
						img: '../static/images/orders.jpg',
						labolcolor: '#579aed'
					}
				],
				tab:[
					{
						name:'附近宝贝',
						color:'#3c9cff'
					},
					{
						name:'家具用品',
						color:'#fff'
					},
					{
						name:'企业用品',
						color:'#fff'
					},
					{
						name:'古玩乐器',
						color:'#fff'
					},
					{
						name:'手机数码',
						color:'#fff'
					}
				]
			};
		},
		methods:{
			settab:function(e){
				this.display = 'none'
				let arr = this.tab;
				for(let i in arr){
					arr[i].color = '#fff'
				}
				arr[e].color = '#3c9cff'
			},
			aecondxq:function(){
				uni.navigateTo({
					url: '/pages/secondhanxq/secondhanxq'
				});
			}
		}
	}
</script>

<style>
	.allseconds .bottom .tow .towli .towlibottom .towliname div p:last-child{
		color: #999999;
		font-size: 18rpx;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliname div p:first-child{
		color: #222222;
		font-size: 22rpx;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliname div{
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliname image{
		width: 50rpx;
		height: 50rpx;
		border-radius: 50%;
		margin-right: 12rpx;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliname{
		padding: 20rpx 0;
		display: flex;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliones .towlionesb div:last-child{
		width: 105rpx;
		height: 30rpx;
		background-color: #eaf3fd;
		text-align: center;
		line-height: 30rpx;
		color: #3c9cff;
		font-size: 18rpx;
		margin: auto 0;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliones .towlionesb div:first-child span{
		color: #3c9cff;
		font-size: 28rpx;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliones .towlionesb div:first-child{
		color: #3c9cff;
		font-size: 24rpx;
		margin: auto 0;
		font-weight: bold;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliones .towlionesb{
		display: flex;
		justify-content: space-between;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliones .towlionesa{
		color: #222222;
		font-size: 28rpx;
		margin-bottom: 25rpx;
	}
	.allseconds .bottom .tow .towli .towlibottom .towliones{
		padding: 20rpx 0;
		border-bottom: 1rpx solid #f2f2f2;
	}
	.allseconds .bottom .tow .towli .towlibottom{
		display: flex;
		flex-direction: column;
		padding:0 20rpx;
	}
	.allseconds .bottom .tow .towli image{
		width: 348rpx;
		height: 348rpx;
		background-color: #3c9cff;
		border-radius: 10rpx 10rpx 0rpx 0rpx;
	}
	.allseconds .bottom .tow .towli{
		/* width: 325rpx; */
		/* height: 560rpx; */
		background-color: #ffffff;
		border-radius: 10rpx;
		margin: 15rpx;
	}
	.allseconds .bottom .tow{
		flex: 1;
		overflow: auto;
		/* padding: 15rpx; */
		display: flex;
		flex-wrap: wrap;
	}
	.allseconds .bottom .one .labol div{
		margin: 10rpx;
		width: 165rpx;
		height: 54rpx;
		background-color: #f4f4f4;
		border-radius: 27rpx;
		text-align: center;
		line-height: 54rpx;
		color: #222222;
		font-size: 24rpx;
	}
	.allseconds .bottom .one .labol{
		display: flex;
		flex-wrap: wrap;
		padding: 15rpx 10rpx;
	}
	.allseconds .bottom .one .tab .tabli div{
		width: 54rpx;
		height: 7rpx;
		background-color: #3c9cff;
		border-radius: 4rpx;
		margin-top: 12rpx;
	}
	.allseconds .bottom .one .tab .tabli p{
		color: #222222;
		font-size: 28rpx;
	}
	.allseconds .bottom .one .tab .tabli{
		padding: 20rpx 0;
		margin: 0 25rpx;
		flex-shrink: 0;
	}
	.allseconds .bottom .one .tab{
		/* padding: 0 18rpx; */
		display: flex;
		overflow: auto !important;
	}
	.allseconds .bottom .one{
		height: 264rpx;
		background-color: #ffffff;
	}
	.allseconds .bottom{
		flex: 1;
		display: flex;
		flex-direction: column;
	}
	.allseconds .top .allsecondslabol image {
		width: 145rpx;
		height: 97rpx;
		align-self: flex-end;
		margin-right: 12rpx;
		margin-bottom: 12rpx;
		margin-top: 12rpx;
	}

	.allseconds .top .allsecondslabol div {
		margin-top: 18rpx;
		margin-left: 18rpx;
		width: 100rpx;
		height: 32rpx;
		border-radius: 5rpx;
		text-align: center;
		line-height: 32rpx;
		color: #ffffff;
		font-size: 20rpx;
	}

	.allseconds .top .allsecondslabol {
		width: 230rpx;
		height: 180rpx;
		border-radius: 0rpx 0rpx 10rpx 10rpx;
		display: flex;
		flex-direction: column;
	}

	.allseconds .top {
		display: flex;
		padding: 18rpx;
		justify-content: space-between;
	}

	.allseconds {
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
