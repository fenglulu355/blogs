<template>
	<view class='nearby'>
		<view class='neartitle'>
			<view class='nearone'>附近店铺</view>
			<view class="nearaddr">
				<div>{{location.desc}}</div>
				<image mode="widthFix" src="../static/images/fujin.png"></image>
			</view>
		</view>
		<scroll-view scroll-top="0" class="scrolls" scroll-y="true" @scrolltolower="scrollbottom">
			<view class="neartext">
				<view class='nearli' v-if="nearlis[index].id" v-for="(item,index) in page" :key="index">
					<image mode="scaleToFill" :src="nearlis[index].logo"></image>
					<view class='title'>{{nearlis[index].store_name}}</view>
					<view>
						<image mode="widthFix" src="../static/images/dv.png"></image>
						<div>}{{nearlis[index].address}}</div>
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import {
		mapState,
		mapActions,
		mapMutations
	} from 'vuex';
	import amap from '../components/demo/utils/amap-wx.js'
	export default {
		data() {
			return {
				bashurl:''
			};
		},
		computed: {
			...mapState(['location'])
		},
		props:['nearlis','page'],
		created: function() {
			console.log(this.nearlis);
		},
		methods: {
			
		}
	}
</script>

<style>
	.scrolls{
		height: 100%;
	}
	.nearby .neartext .nearli view:last-child div {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0px;
		color: #666666;
		margin: auto 0;
	}

	.nearby .neartext .nearli view:last-child image {
		width: 16rpx;
		margin: auto 0;
		margin-right: 10rpx;
	}

	.nearby .neartext .nearli view:last-child {
		display: flex;
	}

	.nearby .neartext .nearli .title {
		font-family: PingFang-SC-Bold;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
	}

	.nearby .neartext .nearli image {
		width: 100%;
		height: 182rpx;
		border-radius: 5rpx;
	}

	.nearby .neartext .nearli {
		padding: 15rpx;
		width: 326rpx;
		height: 270rpx;
		background-color: #ffffff;
		margin-right: 2rpx;
		margin-bottom: 2rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.nearby .neartext {
		display: flex;
		flex-wrap: wrap;
	}

	.nearby .neartitle view:last-child image {
		width: 21rpx;
		margin: auto 0;
	}

	.nearby .neartitle view:last-child div {
		margin: auto 0;
		font-family: PingFang-SC-Medium;
		font-size: 24rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin-right: 12rpx;
		line-height: auto;
	}

	.nearby .neartitle view:last-child {

		padding: 0 15rpx;
		height: 50rpx;
		background-color: #fffbe9;
		border-radius: 25rpx;
		margin: auto 0;
		display: flex;
	}

	.nearby .neartitle .nearone {
		font-family: PingFang-SC-Medium;
		font-size: 28rpx;
		font-weight: bold;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #222222;
		line-height: 80rpx;
	}

	.nearby .neartitle {
		height: 80rpx;
		background-color: #ffffff;
		display: flex;
		justify-content: space-between;
		margin-bottom: 5rpx;
		padding: 0 15rpx;
	}

	.nearby {
		width: 714rpx;
		margin: 0 auto;
		margin-bottom: 17rpx;
	}
</style>
