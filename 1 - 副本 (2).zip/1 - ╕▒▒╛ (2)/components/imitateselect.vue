<template>
	<view class="imita">
		<view></view>
		<view></view>
		<view></view>
		<view></view>
	</view>
</template>

<script>
	
	export default {
		data() {
			return {
				
			};
		},
		components:{
			
		}
	}
</script>

<style>
.imita{
	display: flex;
	height: 100%;
}
</style>
