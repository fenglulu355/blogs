import vue from 'vue';
import Vuex from 'vuex';
vue.use(Vuex)
let bashurl = 'http://bcdz.com'; //线下
//let bashurl = 'http://bcdz.public.5151fw.com/api.html'
const store = new Vuex.Store({
	state: {
		bashurl: bashurl,
		shophome: '',
		tabList: [{
			name: '秒杀'
		}, {
			name: '推荐'
		}, {
			name: '拼单'
		}],
		shophomeWheelimg: [],
		Modularsli: [],
		used: '',
		location: {},
		nearbyshop: [],
		allclass: [],
		userinfo: '',
		classshop: '',
		masklis: [{
			name: '全部'
		}],
		addrli: '',
		addrlist: [{
			name: '附近',
			color: "#ffd168",
		}],
		maskscreens: '',
		addr: '',
		shopxq: '',
		History: '',
		searchpage: 1
	},
	mutations: {
		//吃穿住行模块
		setshophome: function(state, e) {
			state.tabList = [{
				name: '秒杀'
			}, {
				name: '推荐'
			}, {
				name: '拼单'
			}]
			uni.showLoading({
				title: '加载中...'
			});
			let colors = ['#ff683b', '#3c9cff', '#ffbe00', '#23c88c', '#ff683a', '#f95b72', '#3c9cff']
			setTimeout(() => {
				let arr = state.tabList;
				let arr1 = [];
				for (let i in e) {
					arr.push(e[i]);
						e[i].color = colors[i]
						arr1.push(e[i]);
				}
				state.Modularsli = arr1;
				state.tabList = arr;
				uni.hideLoading();
			}, 1000);
		let  a=state.tabList
		// for(let ){}
		console.log(a, "aaaa")

		},
		setshophomeWheelimg: function(state, e) {
			// console.log(e);
			state.shophomeWheelimg = e
		},
		//设置坐标
		setlocation: function(state, e) {
			state.location = e;
			// console.log(state.location);
		},
		setlocationshop: function(state, e) {
			state.nearbyshop = e;
		},
		setallclass: function(state, e) {
			let colorarr = ['#ff683a', '#3c9cff', '#ffbf00', '#23c88c', '#fb683a', '#f85b71', '#3c9cff']
			for (let i in e) {
				e[i].color = colorarr[i];
			}
			state.allclass = e;
			console.log(e);
		},
		setuserinfo: function(state, e) {
			state.userinfo = e
		},
		//跳转对应搜索页
		settypeclass: function(state, e) {
			state.masklis = [{
				name: '全部美食'
			}]
			let arr = state.tabList;
			let arr1 = state.masklis;
			for (let i in arr[e].child) {
				arr1.push(arr[e].child[i]);
			}
			state.masklis = arr1;
			// console.log(arr[e].child);
			uni.navigateTo({
				url: `../searchResult/searchResult?id=${arr[e].id}`
			});
		},
		setclassshop: function(state, e) {
			state.classshop = e;
			// console.log(state)
		},
		setaddrli: function(state, e) {
			state.addrlist = [{
				name: '附近',
				color: "#ffd168",
			}]
			state.addr = e;
			// console.log(state.location.regeocodeData.addressComponent.city);
			let arr = [{
					zm: 'A',
					city: []
				}, {
					zm: 'B',
					city: []
				}, {
					zm: 'C',
					city: []
				}, {
					zm: 'D',
					city: []
				}, {
					zm: 'E',
					city: []
				}, {
					zm: 'F',
					city: []
				}, {
					zm: 'G',
					city: []
				}, {
					zm: 'H',
					city: []
				}, {
					zm: 'I',
					city: []
				}, {
					zm: 'J',
					city: []
				}, {
					zm: 'K',
					city: []
				}, {
					zm: 'L',
					city: []
				}, {
					zm: 'M',
					city: []
				}, {
					zm: 'N',
					city: []
				}, {
					zm: 'O',
					city: []
				}, {
					zm: 'P',
					city: []
				}, {
					zm: 'Q',
					city: []
				}, {
					zm: 'R',
					city: []
				}, {
					zm: 'S',
					city: []
				}, {
					zm: 'T',
					city: []
				}, {
					zm: 'U',
					city: []
				},
				{
					zm: 'V',
					city: []
				},
				{
					zm: 'W',
					city: []
				},
				{
					zm: 'X',
					city: []
				}, {
					zm: 'Y',
					city: []
				}, {
					zm: 'Z',
					city: []
				}
			];
			let arr1 = [];
			for (let i in e) {
				for (let j in e[i].child) {
					if (state.location.regeocodeData.addressComponent.city == e[i].child[j].name) {
						arr1 = e[i].child[j].child
					}
				}
			}
			let arr3 = state.addrlist;
			for (let o in arr1) {
				if (arr1[o].name == '市辖区') {
					// console.log('1111111111111');
				} else {
					arr1[o].color = '#222222';
					arr3.push(arr1[o]);
				}

			}
			state.addrlist = arr3;
			console.log(arr3);
			for (let k in arr1) {
				for (let p in arr) {
					if (arr[p].zm.toLowerCase() == arr1[k].area_pinyin.toLowerCase()) {
						arr[p].city.push(arr1[k]);
					}
				}
			}
			let arr2 = [];
			for (let s in arr) {
				if (arr[s].city.length > 0) {
					arr2.push(arr[s])
				}
			}
			state.addrli = arr2;
			// console.log(arr2);
		},
		setaddrlist: function(state, e) {
			let arr = state.addrlist;
			console.log(arr[e]);
			for (let i in arr) {
				arr[i].color = '#222222'
			}
			arr[e].color = '#ffd168'
			state.addrli = arr;
		},
		setmaskscreens: function(state, e) {
			// console.log(e);
			for (let i in e) {
				for (let j in e[i].child) {
					e[i].child[j].color = '#222222';
					e[i].child[j].background = '#efefef'
				}
				e[i].child[0].color = '#f5bc32';
				e[i].child[0].background = '#fff4d3'
			}
			state.maskscreens = e;
			// console.log(e);
		},
		setmaskcolors: function(state, e) {
			let arr = state.maskscreens;
			for (let j in arr[e.a].child) {
				arr[e.a].child[j].color = '#222222';
				arr[e.a].child[j].background = '#efefef'
				arr[e.a].child[e.b].color = '#f5bc32';
				arr[e.a].child[e.b].background = '#fff4d3'
			}
			state.maskscreens = arr;
			// console.log(e.a,e.b)
		},
		setsort: function(state, e) {
			let arr = state.classshop;
			//评价排序
			uni.showLoading({
				title: '加载中...'
			});
			if (e == 1) {
				for (let i = 0; i < arr.length - 1; i++) {
					for (let j = 0; j < arr.length - 1 - i; j++) {
						if (arr[j].comment > arr[j + 1].comment) {
							var temp = arr[j];
							arr[j] = arr[j + 1];
							arr[j + 1] = temp;
						}
					}
				}
				let arr1 = arr.reverse()
				console.log(arr1); //把排序好的数组进行倒序并输出！
				state.classshop = arr1;
			} else if (e == 2) {
				for (let i = 0; i < arr.length - 1; i++) {
					for (let j = 0; j < arr.length - 1 - i; j++) {
						if (arr[j].num > arr[j + 1].num) {
							var temp = arr[j];
							arr[j] = arr[j + 1];
							arr[j + 1] = temp;
						}
					}
				}
				let arr1 = arr.reverse()
				console.log(arr1); //把排序好的数组进行倒序并输出！
				state.classshop = arr1;
			}
			setTimeout(function() {
				uni.hideLoading();
			}, 500)
			console.log(e);
		},
		setshopxq: function(state, e) {
			state.shopxq = e;
		},
		setHistory: function(state, e) {
			state.History = e;
		},
		setthishistory: function(state, e) {
			let arr = [];
			console.log(e);
			if (e.id == 0) {
				if (state.History.shop) {

				} else {
					state.History.shop = [];
				}
				if (e.searchs) {
					arr = state.History.shop;
					arr.push(e.searchs);
					state.History.shop = arr;
				}
			} else {
				if (state.History.commodity) {

				} else {
					state.History.commodity = [];
				}
				if (e.searchs) {
					arr = state.History.commodity;
					arr.push(e.searchs);
					state.History.commodity = arr;
				}
			}
			// console.log(state.History);
			uni.setStorage({
				key: 'History',
				data: state.History,
				success: function() {
					console.log('success');
				}
			});
		},
		setempty: function(state, e) {
			console.log(e);
			if (e == 0) {
				state.History.shop = []
			} else {
				state.History.commodity = [];
			}
			uni.setStorage({
				key: 'History',
				data: state.History,
				success: function() {
					console.log('success');
				}
			});
		}
	},
	actions: {
		//登录小程序
		loginwx: ({
			commit
		}, data) => {
			uni.request({
				url: bashurl + '/index/login/getopenid', //仅为示例，并非真实接口地址。
				data: {
					method: 'user.wxapplogin1',
					js_code: data.code
				},
				success: (res) => {
					if (res.data.openid) {
						data.data.open_id = res.data.openid;
						console.log(data.data)
						uni.request({
							url: bashurl + '/index/login/addUsern', //仅为示例，并非真实接口地址。
							data: data.data,
							success: (res) => {
								console.log(res)
								if (res.data.code == 200) {
									// console.log(res.data.data.user_wx_id);
									// 判断是否返回了token，如果没有，就说明没有绑定账号，跳转到绑定页面
									if (typeof res.data.token == 'undefined') {
										uni.showToast({
											title: '请绑定手机号',
											duration: 1000,
											image: '../../static/images/pho.png'
										});
										setTimeout(() => {
											uni.navigateTo({
												url: `/pages/newChangeties/newChangeties?id=${res.data.data.user_wx_id}`
											});
										}, 1000);
									} else {
										//登陆成功，设置token，并返回上一页
										uni.request({
											url: bashurl, //仅为示例，并非真实接口地址。
											data: {
												method: "user.info",
												token: res.data.token
											},
											success: (res) => {
												console.log(res.data);
												// console.log(res.data);
											}
										});
										uni.setStorage({
											key: 'userToken',
											data: res.data.token,
											success: function() {
												// console.log('success');
											}
										});
										uni.switchTab({
											url: '/pages/shophome/shophome.vue'
										});
										return false;
									}
								} else {
									uni.showToast({
										title: '登录失败',
										duration: 2000,
										image: '../../static/images/cha.png'
									});
								}
							}
						});
					} else {
						return false;
					}
				}
			});
		},
		//手机快捷登录
		phonelogins: ({
			commit
		}, data) => {
			//console.log(data);
			uni.request({
				url: bashurl + '/index/login/ksUser', //仅为示例，并非真实接口地址。
				data: {
					code: data.code,
					method: "user.smslogin",
					phone: data.phones,
					platform: 2
				},
				success: (res) => {
					//console.log(res.data.data.wx_openi)
					if (res.data.code == 200) {
						uni.setStorage({
							key: 'token',
							data: res.data.data.wx_openi,
							success: function() {
								// console.log('success');
							}
						});
						uni.switchTab({
							url: '/pages/shophome/shophome'
						});
					} else {
						uni.showToast({
							title: '验证失败',
							duration: 1000,
							image: '../../static/images/cha.png'
						});
					}
					// console.log(res.data);
				}
			});
		},
		//获取验证码
		codes: ({
			commit
		}, phone) => {
			var myreg =
				/^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(18[0-9]{1})|(17[0-9]{1})|(19[0-9]{1}))+\d{8})$/;
			if (myreg.test(phone)) {
				uni.request({
					url: bashurl + '/index/login/getRegPhoneCode', //仅为示例，并非真实接口地址。
					data: {
						code: "login",
						method: "user.sms",
						phone: phone
					},
					success: (res) => {
						uni.showToast({
							title: res.data.msg,
							duration: 1000,
							image: '../../static/images/pho.png'
						});
						if (res.data.status) {

						} else {

						}
						console.log(res.data);
					}
				});
			} else {
				uni.showToast({
					title: '手机号不正确',
					duration: 1000,
					image: '../../static/images/pho.png'
				});
			}
		},
		//验证验证码
		isturecode: ({
			commit
		}, data) => {
			// console.log(code, phone);
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					code: data.code,
					method: "user.smslogin",
					mobile: data.phone,
					platform: 2,
					user_wx_id: data.id
				},
				success: (res) => {
					if (res.data.status) {
						uni.request({
							url: bashurl, //仅为示例，并非真实接口地址。
							data: {
								method: "user.info",
								token: res.data.data
							},
							success: (res) => {
								if (res.data.data.store_id > 0) {
									uni.reLaunch({
										url: '/pages/index/index'
									});
								} else {
									uni.switchTab({
										url: '/pages/shophome/shophome'
									});
								}
								console.log(res.data.data.store_id);
								// console.log(res.data);
							}
						});
						uni.setStorage({
							key: 'token',
							data: res.data.data,
							success: function() {
								// console.log('success');
							}
						});
					} else {
						uni.showToast({
							title: '验证失败',
							duration: 1000,
							image: '../../static/images/cha.png'
						});
					}
					// console.log(res.data);
				}
			});
		},
		//获取首页所有分类
		getclassification: ({
			commit
		}) => {
			uni.request({
				url: bashurl + '/index/api/index', //仅为示例，并非真实接口地址。

				success: (res) => {
					commit('setshophome', res.data.data);
					console.log(res.data.data,"aaa111aa");
				}
			});
		},
		//获取首页轮播图
		getWheel: function({
			commit
		}) {
			uni.request({
				url: bashurl + `/index/api/get_banner`, //仅为示例，并非真实接口地址。
				method: 'POST',
				success: (res) => {
					// commit('setshophome', res.data.data);
					let arr = res.data.data.list
					for (let i in arr) {
						if (arr[i].id == 1) {
							uni.request({
								url: bashurl + `/index/api/get_banner`, //仅为示例，并非真实接口地址。
								method: 'POST',
								success: (res) => {
									commit('setshophomeWheelimg', res.data.data.list);
								}
							});
						}
					}
				}
			});
		},
		//获取附近商家和当前位置
		getnearbyshop: function({
			commit
		}, data) {
			//console.log(data)
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: 'store.getstorelist',
					longitude: data.longitude,
					latitude: data.latitude
				},
				success: (res) => {
					commit('setlocation', data);
					commit('setlocationshop', res.data.data);
					// console.log(res.data.data);
				}
			});
		},
		//获取全部分类
		getallclass: function({
			commit
		}) {
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: "categories.getallcat"
				},
				success: (res) => {
					commit('setallclass', res.data.data);
					// console.log(res.data.data);
				}
			});
		},
		//获取地址列表
		getaddrli: function({
			commit
		}) {
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: 'region.list'
				},
				success: (res) => {
					commit('setaddrli', res.data);
					// console.log(res.data);
				}
			});
		},
		//获取用户信息
		getuserinfo: function({
			commit
		}, token) {
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: "user.info",
					token: token
				},
				success: (res) => {
					commit('setuserinfo', res.data.data);
					// console.log(res.data);
				}
			});
		},
		//获取分类商家
		getclassshop: function({
			commit
		}, data) {
			uni.showLoading({
				title: '加载中...'
			});
			let dataclass = '';
			if (data.childid) {
				dataclass = {
					method: 'store.getstorelist',
					store_cat_id: data.childid,
					longitude: store.state.location.longitude,
					latitude: store.state.location.latitude
				}
			} else {
				dataclass = {
					method: 'store.getstorelist',
					store_cat_id: data.id,
					longitude: store.state.location.longitude,
					latitude: store.state.location.latitude
				}
			}

			if (data.addr) {
				dataclass = {
					method: 'store.getstorelist',
					store_cat_id: data.id,
					longitude: data.addr.lng,
					latitude: data.addr.lat
				}
			} else {
				dataclass = {
					method: 'store.getstorelist',
					store_cat_id: data.id,
					longitude: store.state.location.longitude,
					latitude: store.state.location.latitude
				}
			}

			// console.log(store.state.location)
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: dataclass,
				success: (res) => {
					commit('setclassshop', res.data.data);
					commit('setmaskscreens', res.data.filter);
					// console.log(res.data.data);
				}
			});
			setTimeout(function() {
				uni.hideLoading();
			}, 500)
		},
		//获取秒杀列表
		getSeckillli: function({
			commit
		}) {
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: 'group.getlist',
					type: 4
					// stime:,//开始时间
					// etime://结束时间
				},
				success: (res) => {
					// commit('setclassshop', res.data.data);
					// commit('setmaskscreens', res.data.filter);
					console.log(res.data.data);
				}
			});
		},
		//获取店铺详情
		getshopxq: function({
			commit
		}, data) {
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: 'store.getdefaultstore',
					store_id: data.id
				},
				success: (res) => {
					commit('setshopxq', res.data.data);
					// commit('setmaskscreens', res.data.filter);
					// console.log(res.data.data);
				}
			});
		},
		getHistory: function({
			commit
		}) {
			uni.getStorage({
				key: 'History',
				success: function(res) {
					commit('setHistory', res.data);
					// console.log(res.data);
				}
			});
		},
		//搜索（商家/商品）
		getsearchshop: function({
			commit
		}, data) {
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: 'store.getstorelist',
					longitude: store.state.location.longitude,
					latitude: store.state.location.latitude,
					key: data
				},
				success: (res) => {
					commit('setclassshop', res.data.data);
					commit('setmaskscreens', res.data.filter);
					console.log(res.data.data);
				}
			});
			// console.log(data);
		},
		getsearchcomm: function({
			commit
		}, data) {
			uni.request({
				url: bashurl, //仅为示例，并非真实接口地址。
				data: {
					limit: 10,
					method: "goods.getlist",
					page: 1,
					where: {
						search_name: data.data
					}
				},
				success: (res) => {
					// commit('setclassshop', res.data.data);
					// commit('setmaskscreens', res.data.filter);
					console.log(res.data.data);
				}
			});
		}
	}
});
export default store;
