import Vue from 'vue'
import App from './App'
import store from './store' 
import * as navTo from '@/assets/navTo'

Vue.prototype.$store = store
//封装的跳转传参
Vue.prototype.$navTo = navTo

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
