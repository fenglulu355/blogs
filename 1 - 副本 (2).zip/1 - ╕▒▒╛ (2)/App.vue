<template>
	<view class="bottomtar">
		<div>首页</div>
		<div>消息</div>
		<div>我的</div>
	</view>
</template>
<script>
	export default {
		globalData: {
			bashurl:'http://jshop.com/api.html',
			Location:{},
			address:'',
			city:'',
			province:'',
			oneclass: [{
					name: '日化用品',
					time: '2019-06-17  17:21:12',
					sty: 'border-left:2rpx solid #f5bc32;background-color:#fff',
					isinp: true
				},
				{
					name: '日用商品',
					time: '2019-06-17  17:21:12',
					sty: 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4',
					isinp: true
				},
				{
					name: '洗护用品',
					time: '2019-06-17  17:21:12',
					sty: 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4',
					isinp: true
				},
				{
					name: '卫生用品',
					time: '2019-06-17  17:21:12',
					sty: 'border-left:2rpx solid #f4f4f4;background-color:#f4f4f4',
					isinp: true
				}
			],
			addres:[
				{
					name:'二狗',
					phone:'13454754544',
					addr:'成都市武侯区桐梓林新希望大厦16楼8室',
					isdefault:true
				},
				{
					name:'二狗',
					phone:'13454754544',
					addr:'成都市武侯区桐梓林新希望大厦16楼8室',
					isdefault:false
				},
				{
					name:'二狗',
					phone:'13454754544',
					addr:'成都市武侯区桐梓林新希望大厦16楼8室',
					isdefault:false
				}
			],
			startime:{},
			endtime:{},
			day:''
		},
		onLaunch: function() {
			uni.checkSession({
				success:function(res){
					// uni.getStorage({
					//     key: 'token',
					//     success: function (res) {
					// 		if(res){
					// 			console.log('11111');
					// 		}else{
					// 			console.log('0000')
					// 		}
					//         console.log(res);
					//     }
					// });
					// uni.switchTab({
					//     url: '/pages/shophome/shophome'
					// });
					// console.log(res);
				},
				fail:function(res){
					// console.log(res);
				}
			})
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	.bottomtar div {
		font-family: PingFang-SC-Regular;
		font-size: 20rpx;
		font-weight: normal;
		font-stretch: normal;
		letter-spacing: 0rpx;
		color: #666666;
		margin: 0 auto;
		line-height: 100rpx;
	}
	
	::-webkit-scrollbar {  
    display: none;  
    width: 0 !important;  
    height: 0 !important;  
    -webkit-appearance: none;  
    background: transparent;  
} 

	.bottomtar {
		width: 100%;
		height: 100rpx;
		background-color: #fff;
		display: flex;
		justify-content: space-between;
		position: fixed;
		bottom: 0;
	}



	@font-face {
	  font-family: 'iconfont';  /* project id 1372680 */
	  src: url('//at.alicdn.com/t/font_1372680_5ygiezxxg82.eot');
	  src: url('//at.alicdn.com/t/font_1372680_5ygiezxxg82.eot?#iefix') format('embedded-opentype'),
	  url('//at.alicdn.com/t/font_1372680_5ygiezxxg82.woff2') format('woff2'),
	  url('//at.alicdn.com/t/font_1372680_5ygiezxxg82.woff') format('woff'),
	  url('//at.alicdn.com/t/font_1372680_5ygiezxxg82.ttf') format('truetype'),
	  url('//at.alicdn.com/t/font_1372680_5ygiezxxg82.svg#iconfont') format('svg');
	}
	
	.iconfont {
	  font-family: "iconfont" !important;
	  font-size: 16px;
	  font-style: normal;
	  -webkit-font-smoothing: antialiased;
	  -moz-osx-font-smoothing: grayscale;
	}
	
	.icon-fangzi:before {
	  content: "\e625";
	}
	
	.icon-fenxiang:before {
	  content: "\e633";
	}
	
	.icon-xiangji:before {
	  content: "\e616";
	}
	
	.icon-chuang:before {
	  content: "\e604";
	}
	
	.icon-xingxing:before {
	  content: "\e642";
	}
	
	.icon-fenlei:before {
	  content: "\e614";
	}
	
	.icon-yijianfankui:before {
	  content: "\e673";
	}
	
	.icon-dianhua:before {
	  content: "\e627";
	}
	
	.icon-sousuo:before {
	  content: "\e600";
	}
	
	.icon-xiaoxi1:before {
	  content: "\e6e1";
	}
	
	.icon-laba:before {
	  content: "\e6a8";
	}
	
	.icon-waimai:before {
	  content: "\e62f";
	}
	
	.icon-zuji:before {
	  content: "\e61d";
	}
	
	.icon-kefu:before {
	  content: "\e603";
	}
	
	.icon-miaozhunjing2:before {
	  content: "\e601";
	}
	
	.icon-gouwuche:before {
	  content: "\e602";
	}
	
	.icon-tingche:before {
	  content: "\e63c";
	}
	
	.icon-caidan:before {
	  content: "\e605";
	}
	
	.icon-knife-fork:before {
	  content: "\e610";
	}
	
	.icon-xiaoxi:before {
	  content: "\e6ba";
	}
	
	.icon-daohang-:before {
	  content: "\e60e";
	}
	
	.icon-shijian:before {
	  content: "\e63b";
	}
	
	.icon-biaoqian:before {
	  content: "\e649";
	}
	
	.icon-canju:before {
	  content: "\e6a9";
	}
	
	.icon-yijianfankui1:before {
	  content: "\e619";
	}
	
	.icon-wifi:before {
	  content: "\e66a";
	}
	
	.icon-bianji:before {
	  content: "\e60c";
	}
	
	.icon-xiaoxi2:before {
	  content: "\e62d";
	}
	
	.icon-youhuiquan:before {
	  content: "\e611";
	}
	
	.icon-qianbao-gra:before {
	  content: "\e606";
	}
	
	.icon-xiala:before {
	  content: "\e613";
	}
	
	.icon-shang:before {
	  content: "\e6af";
	}
	
	.icon-xia:before {
	  content: "\e6b0";
	}
	
	.icon-you:before {
	  content: "\e6f3";
	}
	
	.icon-dizhi:before {
	  content: "\e646";
	}
	
	.icon-wode:before {
	  content: "\e65b";
	}
	
	.icon-lajitong:before {
	  content: "\e615";
	}
	
	.icon-jiu:before {
	  content: "\e680";
	}
	
	.icon-shouye:before {
	  content: "\e6b9";
	}
	
	.icon-dianpu:before {
	  content: "\e7d0";
	}
	
	.icon-jia:before {
	  content: "\e617";
	}
	
	.icon-emizhifeiji:before {
	  content: "\e60a";
	}


	/*每个页面公共css */
</style>
