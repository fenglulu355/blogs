var api = {
	data: {
		bashurl: 'http://jshop.com/api.html',
		code: '',
		homeclass:''
	},
	funts: {
		//登录小程序
		loginwx: (e, data) => {
			uni.request({
				url: api.data.bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: 'user.wxapplogin1',
					code: e
				},
				success: (res) => {
					if (res.data.status) {
						data.open_id = res.data.data;
						uni.request({
							url: api.data.bashurl, //仅为示例，并非真实接口地址。
							data: data,
							success: (res) => {
								if (res.data.status) {
									console.log(res.data.data.user_wx_id);
									// 判断是否返回了token，如果没有，就说明没有绑定账号，跳转到绑定页面
									if (typeof res.data.token == 'undefined') {
										uni.showToast({
											title: '请绑定手机号',
											duration: 1000,
											image: '../../static/images/pho.png'
										});
										setTimeout(() => {
											uni.navigateTo({
												url: `/pages/newChangeties/newChangeties?id=${res.data.data.user_wx_id}`
											});
										}, 1000);
									} else {
										//登陆成功，设置token，并返回上一页
										uni.setStorage({
											key: 'userToken',
											data: res.data.token,
											success: function() {
												// console.log('success');
											}
										});
										uni.switchTab({
											url: '/pages/shophome/shophome.vue'
										});
										return false;
									}
								} else {
									uni.showToast({
										title: '登录失败',
										duration: 2000,
										image: '../../static/images/cha.png'
									});
								}
								// console.log(res.data);
							}
						});
					} else {
						return false;
					}
					// console.log(data);
					// console.log(res.data);
				}
			});
			// console.log(api.data);
			// console.log(login);
		},
		//获取验证码
		getcode: (phone) => {
			var myreg = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(18[0-9]{1})|(17[0-9]{1})|(19[0-9]{1}))+\d{8})$/;
			if (!(myreg.test(phone))) {
				uni.request({
					url: api.data.bashurl, //仅为示例，并非真实接口地址。
					data: {
						code: "login",
						method: "user.sms",
						mobile: phone
					},
					success: (res) => {
						uni.showToast({
							title: res.data.msg,
							duration: 1000,
							image: '../../static/images/pho.png'
						});
						if (res.data.status) {

						} else {

						}
						console.log(res.data);
					}
				});
			} else {
				uni.showToast({
					title: '手机号不正确',
					duration: 1000,
					image: '../../static/images/pho.png'
				});
			}
		},
		//验证验证码
		isturecode: (code, phone, id) => {
			// console.log(code, phone);
			uni.request({
				url: api.data.bashurl, //仅为示例，并非真实接口地址。
				data: {
					code: code,
					method: "user.smslogin",
					mobile: phone,
					platform: 2,
					user_wx_id: id
				},
				success: (res) => {
					if (res.data.status) {
						uni.setStorage({
							key: 'token',
							data: res.data.data,
							success: function() {
								// console.log('success');
							}
						});
						uni.switchTab({
							url: '/pages/shophome/shophome'
						});
					} else {
						uni.showToast({
							title: '验证失败',
							duration: 1000,
							image: '../../static/images/cha.png'
						});
					}
					// console.log(res.data);
				}
			});
		},
		//手机快捷登录
		phonelogin:(code,phone)=>{
			uni.request({
				url: api.data.bashurl, //仅为示例，并非真实接口地址。
				data: {
					code: code,
					method: "user.smslogin",
					mobile: phone,
					platform: 2
				},
				success: (res) => {
					if(res.data.status){
						uni.setStorage({
							key: 'token',
							data: res.data.data,
							success: function() {
								// console.log('success');
							}
						});
						uni.switchTab({
							url: '/pages/shophome/shophome'
						});
					}else{
						uni.showToast({
							title: '验证失败',
							duration: 1000,
							image: '../../static/images/cha.png'
						});
					}
					// console.log(res.data);
				}
			});
		},
		//获取首页所有分类
		getclassification:()=>{
			uni.request({
				url: api.data.bashurl, //仅为示例，并非真实接口地址。
				data: {
					method: "categories.getallcat"
				},
				success: (res) => {
					api.data.homeclass = res.data.data
					console.log(res.data.data);
				}
			});
		}
	},
}


export default api
