<template>
  <div class="homenews clearFix">
    <div class="hncont">
      <ul class="hnleft">
        <li class="name">
          <p class="gs">成都市文春木业有限公司</p>
          <p class="py">Chengdu Wenchun Wood industry Co. Ltd.</p>
        </li>
        <li class="jhp">
          <p>九豪牌</p>
          <p
            class="intru"
          >成都市文春木业有限公司居于西部家具产业带、历史文化名镇新繁，紧邻成彭高速,交通便捷。公司以制造销售宾馆成套家具、办公家具、教学家具为主导的专业化公司...</p>
          <p class="more" @click="toAbout">MORE+</p>
        </li>
      </ul>
      <ul class="hncenter">
        <li class="clearFix hctop" v-if="newsinfo[0]">
          <div class="left" @click="todetails(newsinfo[0].article_id)">
            <div class="time">
              <div class="timebox">
                <span class="year">{{newsinfo[0].year}}</span>
                <span class="fgx"></span>
                <span class="moon">{{newsinfo[0].mouth}}</span>
              </div>
            </div>
            <p class="content" v-html="newsinfo[0].article_title"></p>
          </div>
          <div class="pic">
            <img src="../assets/fenge.png" alt />
          </div>
        </li>
        <li class="clearFix hcbot" v-if="newsinfo[1]">
          <div class="left" @click="todetails(newsinfo[0].article_id)">
            <p class="content" v-html="newsinfo[1].article_title"></p>
            <div class="time">
              <div class="timebox">
                <span class="year">{{newsinfo[1].year}}</span>
                <span class="fgx"></span>
                <span class="moon">{{newsinfo[1].mouth}}</span>
              </div>
            </div>
          </div>
          <div class="pic">
            <img src="../assets/fenge.png" alt />
          </div>
        </li>
      </ul>
    </div>
    <div class="bg">
      <div class="mainpic"
      :style="{backgroundImage: 'url(' + require('../assets/banyuan.png')+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"></div>
    </div>
  </div>
</template>

<script>
import httpUrl from "../api/url";
export default {
  name: "homenews",
  data() {
    return {
      newsinfo: []
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    requst() {
      this.$axios
        .post("/index/api/getNewsList", {
          page: this.setPage,
          limit: 2
        })
        .then(res => {
          this.newsinfo = res.data.data.data;
        });
    },
    toAbout() {
      this.$router.push({
        path: "/about"
      });
    },
    todetails(val) {
      let id = val;
      this.$router.push({
        path: "/details",
        query: { id: id, kind: "news" }
      });
    }
  }
};
</script>
 
<style lang="less" scoped>
.homenews {
  // background: pink;
  box-sizing: border-box;
  padding-top: 50px;
  width: 100%;
  min-width: 1200px;
  position: relative;
  .hncont {
    width: 80%;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 45% 50%;
    justify-content: space-between;
    .hnleft {
      width: 100%;
      .name {
        .gs {
          font-size: 1.8rem;
          color: #57585a;
        }
        .py {
          padding-top: 5px;
          color: #9d9ea1;
        }
      }
      .jhp {
        padding-top: 40px;
        p {
          width: 100%;
          font-size: 15px;
          color: #57585a;
          letter-spacing: 0.5px;
        }
        p:first-child {
          font-size: 30px;
          padding-bottom: 20px;
        }
        .intru {
          // background: pink;
          width: 70%;
          line-height: 24px;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 3;
          overflow: hidden;
        }
        .more {
          cursor: pointer;
          margin-top: 20px;
          width: 100px;
          height: 30px;
          line-height: 30px;
          font-size: 18px;
          text-align: center;
          color: white;
          border-radius: 8px;
          background: #ff9442;
        }
      }
    }
    .hncenter {
      // background: pink;
      display: grid;
      grid-template-rows: 45% 45%;
      li {
        position: relative;
        .time {
          cursor: pointer;
          width: 100%;
          height: 90px;
          color: #ff9442;
          .timebox {
            width: 50%;
            height: 90px;
            font-size: 3em;
            position: relative;
            .year {
              position: absolute;
              top: 30px;
              left: 10px;
            }
            .fgx {
              display: inline-block;
              width: 3px;
              height: 65px;
              background: #ff9442;
              position: absolute;
              top: 35px;
              font-size: 45px;
              transform: rotate(50deg);
              left: 150px;
            }
            .moon {
              position: absolute;
              top: 45px;
              left: 185px;
            }
          }
        }
        .content {
          cursor: pointer;
          box-sizing: border-box;
          width: 100%;
          line-height: 30px;
          padding-top: 40px;
          color: #57585a;
        }

        .pic {
          width: 100%;
          position: absolute;
          bottom: 0px;
          z-index: -1;
          img {
            width: 100%;
          }
        }
      }
      .hctop {
        .left {
          cursor: pointer;
          display: grid;
          grid-template-columns: 40% 60%;
          justify-content: space-between;
          .content {
            padding-left: 50px;
          }
        }
      }
      .hcbot {
        .left {
          cursor: pointer;
          display: grid;
          grid-template-columns: 45% 55%;
          justify-content: space-between;
        }
      }
    }
  }
  .bg {
    position: absolute;
    bottom: 30px;
    height: 750px;
    width: 345px;
    z-index: -1;
    .mainpic{
     width: 100%;
     height: 100%;
      transform: rotate(180deg);
   }
  }
}
</style>