<template>
  <div class="nav">
    <div class="top">
      <div class="title" @click="tohome">
        <p>成都市文春木业</p>
        <span>高端实木家具定制</span>
      </div>
      <ul class="navlist">
        <li v-for="(list,index) in navlist" :key="index">
          <div class="list" @click="toNav(index)" :class="activeClass ==index?'sel':''">
            <router-link :to="list.path">
              <p>{{list.chinese}}</p>
              <span>{{list.english}}</span>
            </router-link>
          </div>
        </li>
      </ul>
      <div class="tel">
        <div class="telpic">
          <div class="img">
            <img src="../assets/home/phone.png" alt />
          </div>
          <a href="tel:phone">{{phone}}</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import httpUrl from "../api/url";
export default {
  name: "navagetion",
  data() {
    return {
      phone: [],
      baseurl: "",
      activeClass: 0, // 0为默认选择第一个，-1为不选择
      navlist: [
        {
          path: "/",
          chinese: "首页",
          english: "HOME"
        },
        {
          path: "/about",
          chinese: "关于我们",
          english: "ABOUT US"
        },
        {
          path: "/product",
          chinese: "产品中心",
          english: "PRODUCT"
        },
        {
          path: "/production",
          chinese: "生产基地",
          english: "PRODUCTION"
        },
        {
          path: "/cases",
          chinese: "经典案例",
          english: "CASES"
        },
        {
          path: "/news",
          chinese: "新闻动态",
          english: "NEWS"
        },
        {
          path: "/contact",
          chinese: "联系我们",
          english: "CONTACT US"
        }
      ]
    };
  },
  created() {
   if (!sessionStorage.getItem("curindex")) {
      this.activeClass = 0;
    } else {
      this.activeClass = sessionStorage.getItem("curindex");
    }
    this.baseurl = httpUrl.httpUrl;
    this.$axios.post("/index/api/web_config").then(res => {
      let a = res.data.data.phone.split("");
      a.splice(3, 0, "-");
      a.splice(8, 0, "-");
      this.phone = a.join("");
    });
  },
  methods: {
    tohome() {
      this.$router.push({
        path: "/"
      });
      sessionStorage.setItem("curindex", 0);
      this.activeClass = sessionStorage.getItem("curindex");
    },
    toNav(index) {
      sessionStorage.setItem("curindex", index);
      this.activeClass = sessionStorage.getItem("curindex");
    }
  }
};
</script>

<style lang="less" scoped>
.nav {
  background: #1f222b;
  width: 100%;
  height: 110px;
  min-width: 1200px;
  .top {
    width: 80%;
    min-width: 1200px;
    height: 110px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 20% 55% 25%;
    .title {
      cursor: pointer;
      color: #ff9442;
      p {
        font-size: 30px;
        padding: 20px 0 2px 0px;
      }
      span {
        font-size: 16px;
      }
    }
    .navlist {
      display: flex;
      justify-content: space-around;
      li {
        display: inline-block;
        padding-top: 30px;
        text-align: center;
        a {
          color: white;
          p {
            font-size: 20px;
            font-weight: 400;
          }
          span {
            color: #d4d4d4;
            font-size: 14px;
          }
        }
        &:hover {
          a {
            color: #ff9442;
            p {
              font-weight: 400;
            }
            span {
              color: #ff9442;
            }
          }
        }
      }
      .sel {
        a {
          color: #ff9442;
          p {
            font-weight: 400;
          }
          span {
            color: #ff9442;
          }
        }
      }
    }
    .tel {
      width: 100%;
      padding: 35px 0 0 0px;
      .telpic {
        background: #ff9442;
        width: 240px;
        height: 36px;
        margin: 0 auto;
        text-align: center;
        .img {
          display: inline-block;
          width: 26px;
          height: 26px;
          position: relative;
          top: -4px;
          img {
            width: 100%;
            height: 100%;
          }
        }
        a {
          cursor: pointer;
          width: 100%;
          height: 36px;
          line-height: 36px;
          font-size: 1.3rem;
          color: white;
        }
      }
    }
  }
}
</style>
