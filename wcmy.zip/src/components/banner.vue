<template>
  <div class="banner">
    <img src="../assets/banner.png" alt />
  </div>
</template>
<script>
export default {
  name: "Banner"
};
</script>
<style lang="less" scoped>
.banner{
    width: 100%;
    min-width: 1200px;
    img{
        width: 100%;
    }
}
</style>