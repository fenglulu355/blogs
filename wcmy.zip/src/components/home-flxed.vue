<template>
  <div class="home-active">
    <div class="flash">
      <div class="prolist">
        <div class="pr-left">
          <div class="pl-box">
            <div class="fltop">
              <div class="picture">
                <img src="../assets/home/pro_tb_02.png" alt />
              </div>
              <p>02</p>
            </div>
            <div class="flcenter">
              <p class="cname">酒店固定家具</p>
              <p class="ename">HOTEL FLXED FURNITURE</p>
              <p class="bg"></p>
            </div>
            <div class="flbot">
              <p>文春木业</p>
            </div>
          </div>
          <div class="pl-proli">
            <div
              class="pic"
              v-if="homeflxedlist[0]"
              @click="toProActive(homeflxedlist[0].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeflxedlist[0].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                   <img class="yy" src="../assets/zhezhao.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>固定家具</span>
                <p class="text" v-html="homeflxedlist[0].article_title"></p>
              </div>
            </div>
          </div>
        </div>
        <div class="pr-right">
          <div class="prbox proli">
           <div
              class="pic"
              v-if="homeflxedlist[1]"
              @click="toProActive(homeflxedlist[1].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeflxedlist[1].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                   <img class="yy" src="../assets/zhezhao.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>固定家具</span>
                <p class="text" v-html="homeflxedlist[1].article_title"></p>
              </div>
            </div>
          </div>
          <div class="prbox proli" >
           <div
              class="pic"
              v-if="homeflxedlist[2]"
              @click="toProActive(homeflxedlist[2].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeflxedlist[2].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                   <img class="yy" src="../assets/zhezhao.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>固定家具</span>
                <p class="text" v-html="homeflxedlist[2].article_title"></p>
              </div>
            </div>
          </div>
          <div class="prbox proli wprbox">
            <div
              class="pic"
              v-if="homeflxedlist[3]"
              @click="toProActive(homeflxedlist[3].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeflxedlist[3].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                   <img class="yy" src="../assets/zhezhao.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>固定家具</span>
                <p class="text" v-html="homeflxedlist[3].article_title"></p>
              </div>
            </div>
          </div>
          <div class="prbox proli">
            <div
              class="pic"
              v-if="homeflxedlist[4]"
              @click="toProActive(homeflxedlist[4].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeflxedlist[4].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                   <img class="yy" src="../assets/zhezhao.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>固定家具</span>
                <p class="text" v-html="homeflxedlist[4].article_title"></p>
              </div>
            </div>
          </div>
          <div class="prbox proli" >
            <div
              class="pic"
              v-if="homeflxedlist[5]"
              @click="toProActive(homeflxedlist[5].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeflxedlist[5].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                   <img class="yy" src="../assets/zhezhao.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>固定家具</span>
                <p class="text" v-html="homeflxedlist[5].article_title"></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
export default {
  name: "hmactive",
  data() {
    return {
      homeflxedlist: [],
      baseurl: "",
      classid: ""
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    requst() {
      this.$axios.post("/index/api/getProductClass").then(res => {
        this.classid = res.data.data[1].class_id;
        this.requstClass(this.classid,1);
      });
    },
    requstClass(id,page) {
      this.$axios
        .post("/index/api/getProductList", {
          id: id,
          page: page,
          limit: 6
        })
        .then(res => {
          this.homeflxedlist = res.data.data.data;
        });
    },
    toProActive(val) {
      let id = val;
      this.$router.push({
        path: "/details",
        query: { id: id, kind: "product" }
      });
    }
  }
};
</script>

<style lang="less" scoped>
// 图片
.flash {
  padding-top: 200px;
  .prolist {
    width: 100%;
    display: flex;
    .pr-left {
      width: 35%;
      .pl-box {
        box-sizing: border-box;
        background: #171c22;
        width: 100%;
        height: 600px;
        padding: 40px 46px;
        .fltop {
          height: 4rem;
          display: flex;
          justify-content: space-between;
          .picture {
            width: 4rem;
            img {
              width: 100%;
              height: 100%;
            }
          }
          p {
            font-size: 4rem;
            font-weight: 300;
            color: rgba(241, 241, 241, 1);
            line-height: 4rem;
            opacity: 0.4;
          }
        }
        .flcenter {
          padding-top: 6rem;
          .cname {
            color: #ff9443;
            font-size: 2.5rem;
          }
          .ename {
            padding-top: .5rem;
            font-size: 1.5rem;
            font-weight: 300;
            color: rgba(241, 241, 241, 1);
            opacity: 0.4;
          }
          .bg {
            margin: 5.5rem 0;
            width: 36px;
            height: 2px;
            background: #dddddd;
          }
        }
        .flbot {
          font-size: 1.5rem;
          font-weight: 300;
          color: rgba(241, 241, 241, 1);
          opacity: 0.4;
        }
      }
      .pl-proli {
        cursor: pointer;
        width: 100%;
        height: 600px;
        .pic {
          width: 100%;
          height: 600px;
          position: relative;
          .mainpic {
            width: 100%;
            height: 100%;
         
          }
          .ts {
            width: 100%;
            display: none;
            img {
              position: absolute;
            }
            .yy {
              top: 0;
              width: 100%;
              height: 100%;
            }
            .pop {
              top: 20px;
              left: -8px;
            }
            span {
              position: absolute;
              top: 30px;
              left: 13px;
              color: white;
            }
            .text {
              box-sizing: border-box;
              position: absolute;
              bottom: 0;
              color: rgba(255, 255, 255, 0.8);
              line-height: 30px;
              width: 90%;
              height: 60px;
              padding-left: 20px;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
          &:hover .ts {
            display: block;
          }
        }
      }
    }
    .pr-right {
      width: 65%;
      display: flex;
      flex-wrap: wrap;
      .proli {
   cursor: pointer;
        width: 50%;
        height: 400px;
        .pic {
          width: 100%;
          height: 400px;
          position: relative;
          .mainpic {
            width: 100%;
            height: 100%;
          }
          .ts {
            width: 100%;
            display: none;
            img {
              position: absolute;
            }
            .yy {
              top: 0;
              width: 100%;
              height: 100%;
            }
            .pop {
              top: 20px;
              left: -8px;
            }
            span {
              position: absolute;
              top: 30px;
              left: 13px;
              color: white;
            }
            .text {
              box-sizing: border-box;
              position: absolute;
              bottom: 0;
              color: rgba(255, 255, 255, 0.8);
              line-height: 30px;
              width: 90%;
              height: 60px;
              padding-left: 20px;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
          &:hover .ts {
            display: block;
          }
        }
      }
      .wprbox {
        width: 100%;
        .pic {
          width: 100%;
        }
      }
    }
  }
}
</style>