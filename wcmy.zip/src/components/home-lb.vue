<template>
  <div class="home-lb" :style="backgroundImg">
    <!-- 轮播 -->
    <div class="warpper clearFix">
      <!-- 向左向右按钮 -->
      <ul class="slide-pages fr">
        <li class="bottom prev" @click="prevBtn">
          <img src="../assets/home/pro_left.png" alt />
        </li>
        <li class="pages">
          <div class="router-box" v-for="(item, index) in paths" :key="index" @click="addBg(index)">
            <router-link :to="item">
              <div class="pages-box" :class="activeClass ==index?'show':''"></div>
            </router-link>
          </div>
        </li>
        <li class="bottom next" @click="nextBtn">
          <img src="../assets/home/pro_right.png" alt />
        </li>
      </ul>
      <!-- 图片 -->
      <router-view></router-view>
    </div>
    <div class="toTel clearFix">
      <div class="toteltext fr">
        <p class="text">全国24小时服务热线</p>
        <p class="tel">138-8181-9315</p>
        <p class="bottom">
          <a href="tel:phone">立即咨询</a>
        </p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "homelb",
  data() {
    return {
      phone: [],
      activeClass: 0,
      paths: ["/", "/homeFlexd", "/homeRoom"],
      backgroundImg: {
        backgroundImage: "url(" + require("@/assets/bg-black.png") + ")",
        backgroundRepeat: "no-repeat",
        backgroundSize: "100% 100%"
      },
      nowIndex: 0,
      isShow: true
    };
  },
  created() {
    this.$axios.post("/index/api/web_config").then(res => {
      this.phone = res.data.data.phone;
    });
  },
  methods: {
    addBg(index) {
      this.activeClass = index;
    },
    prevBtn() {
      if (this.$route.path == "/homeRoom") {
        this.$router.push({ path: "/homeFlexd" });
        this.activeClass = 1;

        return;
      }
      if (this.$route.path == "/homeFlexd") {
        this.$router.push({ path: "/" });
        this.activeClass = 0;
        return;
      }
    },
    nextBtn() {
      if (this.$route.path == "/") {
        this.$router.push({ path: "/homeFlexd" });
        this.activeClass = 1;
        return;
      }
      if (this.$route.path == "/homeFlexd") {
        this.$router.push({ path: "/homeRoom" });
        this.activeClass = 2;
        return;
      }
    }
  }
};
</script>

<style lang="less" scoped>
img {
  vertical-align: middle;
}
.home-lb {
  width: 100%;
  min-width: 1200px;
  .warpper {
    width: 80%;
    margin: 0 auto;
    overflow: hidden;
    //图片
    .slide-img {
      height: 1000px;
      width: 100%;
      img {
        width: 100%;
        height: 100%;
      }
    }
    // 按钮
    .slide-pages {
      width: 400px;
      height: 170px;
      position: relative;
      .pages {
        width: 200px;
        height: 30px;
        margin: 112px auto;
        display: flex;
        justify-content: space-between;
        .pages-box {
          background: #f5f0f0;
          width: 55px;
          height: 5px;
          cursor: pointer;
        }
        .show {
          background:#ff9442;
        }
      }
      .bottom {
        position: absolute;
        bottom: 30px;
        cursor: pointer;
      }
      .next {
        right: 0;
      }
    }
  }
}
.toTel {
  width: 80%;
  margin: 0 auto;
  .toteltext {
    box-sizing: border-box;
    padding-top: 25px;
    width: 200px;
    height: 150px;
    color: white;
    text-align: right;
    .text {
      font-size: 13px;
    }
    .tel {
      padding: 5px 0;
      font-size: 20px;
      font-weight: bold;
    }
    .bottom {
      float: right;
      width: 80px;
      height: 25px;
      text-align: center;
      border-radius: 15px;
      background: #ff9442;
      a {
        color: white;
        line-height: 25px;
        font-size: 15px;
      }
    }
  }
}
</style>