<template>
  <div class="active">
    <div class="flash">
      <ul class="prolist">
        <li class="pl-box">
          <div class="fltop">
            <div class="picture">
              <img src="../assets/home/pro_tb_02.png" alt />
            </div>
            <p>01</p>
          </div>
          <div class="flcenter">
            <p class="cname">酒店活动家具</p>
            <p class="ename">HOTEL ACTIVITY FURNITURE</p>
            <p class="bg"></p>
          </div>
          <div class="flbot">
            <p>文春木业</p>
          </div>
        </li>
        <li class="proli" v-for="(item, index) in activelist" :key="index" @click="todetails(item)">
          <div class="pic">
            <div
              class="mainpic"
              :style="{backgroundImage: 'url(' +baseurl+`/public/`+item.image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
            ></div>
            <div class="ts">
              <img class="yy" src="../assets/pro-zhezhao.png" alt />
              <img class="pop" src="../assets/product/pop.png" alt />
              <span>酒店家具</span>
              <p class="text" v-html="item.article_title"></p>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div class="pagenation">
      <el-pagination
        background
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage1"
        :page-size="8"
        layout=" prev, pager, next"
        :total="totalPage"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
export default {
  name: "active",
  data() {
    return {
      activelist: [],
      baseurl: "",
      currentPage1: 1,
      totalPage: 1,
      setPage: 1,
      classid: ""
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    handleCurrentChange(val) {
      this.setPage = val;
      this.requstClass(this.classid, this.setPage);
    },
    requst() {
      this.$axios.post("/index/api/getProductClass").then(res => {
        this.classid = res.data.data[0].class_id;
        this.requstClass(this.classid, 1);
      });
    },
    requstClass(id, page) {
      this.$axios
        .post("/index/api/getProductList", {
          id: id,
          page: page
        })
        .then(res => {
          this.activelist = res.data.data.data;
          this.totalPage = res.data.data.total.length;
        });
    },
    todetails(item) {
      let id = item.article_id;
      this.$router.push({
        path: "/details",
        query: { id: id, kind: "product" }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.active {
  .pagenation {
    text-align: right;
    padding-top: 130px;
    width: 100%;
  }
}
// 图片
.flash {
  padding-top: 200px;
  .prolist {
    width: 100%;
    display: grid;
    grid-template-columns: 33% 33% 32%;
    grid-gap: 1%;
    .pl-box {
      box-sizing: border-box;
      background: #171c22;
      width: 100%;
      height: 400px;
      padding: 32px 37px;
      .fltop {
        height: 58px;
        display: flex;
        justify-content: space-between;
        .picture {
          width: 58px;
          img {
            width: 100%;
            height: 100%;
          }
        }
        p {
          font-size: 60px;
          font-weight: 300;
          color: rgba(241, 241, 241, 1);
          line-height: 60px;
          opacity: 0.4;
        }
      }
      .flcenter {
        padding-top: 50px;
        .cname {
          color: #ff9443;
          font-size: 36px;
        }
        .ename {
          padding-top: 5px;
          font-size: 20px;
          font-weight: 300;
          color: rgba(241, 241, 241, 1);
          opacity: 0.4;
        }
        .bg {
          margin: 50px 0;
          width: 36px;
          height: 2px;
          background: #dddddd;
        }
      }
      .flbot {
        font-size: 24px;
        font-weight: 300;
        color: rgba(241, 241, 241, 1);
        opacity: 0.4;
      }
    }
    .proli {
      box-shadow: 1px 1px 50px rgba(39, 41, 49, 0.2);

      display: inline-block;
      width: 100%;
      .pic {
        width: 100%;
        height: 100%;
        position: relative;
        .mainpic {
          width: 100%;
          height: 400px;
        }
        .ts {
          width: 100%;
          height: 100%;
          display: none;
          img {
            position: absolute;
          }
          .yy {
            top: 0;
            width: 100%;
            height: 100%;
          }
          .pop {
            top: 20px;
            left: -8px;
          }
          span {
            position: absolute;
            top: 30px;
            left: 13px;
            color: white;
          }
          .text {
            box-sizing: border-box;
            position: absolute;
            bottom: 0;
            color: rgba(255, 255, 255, 0.8);
            line-height: 30px;
            width: 90%;
            height: 60px;
            padding-left: 20px;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
          }
        }
        &:hover .ts {
          display: block;
        }
      }
    }
  }
}
</style>