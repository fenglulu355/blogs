<template>
  <div class="footer">
    <div class="footercont">
      <div class="left">
        <p class="gsname">成都市文春木业有限公司</p>
        <p class="py">Chengdu Wenchun Wood industry Co. Ltd.</p>
        <div class="box"></div>
      </div>
      <div class="center">
        <div class="bt">
          <p>联系我们</p>
          <span>CONBTACT US</span>
        </div>
        <ul class="contactlist">
          <li class="conli">
            <div class="icon">
              <img src="../assets/home/foot_02.png" alt />
            </div>
            <p class="text">联系人</p>
            <p class="cont">：{{footerinfo.name}}</p>
          </li>
          <li class="conli">
            <div class="icon">
              <img src="../assets/home/foot_01.png" alt />
            </div>
            <p class="text">电话</p>
            <p class="cont">：{{footerinfo.phone}}</p>
          </li>
          <li class="conli">
            <div class="icon">
              <img src="../assets/home/foot_03.png" alt />
            </div>
            <p class="text">邮箱</p>
            <p class="cont">：{{footerinfo.email}}</p>
          </li>
          <li class="conli">
            <div class="icon">
              <img src="../assets/home/foot_04.png" alt />
            </div>
            <p class="text">公司地址</p>
            <p class="cont">：{{footerinfo.address}}</p>
          </li>
        </ul>
      </div>
      <div class="right">
        <div class="bt">
          <p>关注我们</p>
          <span>FOCUS ON US</span>
        </div>
        <ul class="ewm">
          <li>
            <div class="pic" v-if="footerinfo.about_ewm">
              <img :src="baseurl+`/public/`+footerinfo.about_ewm" alt />
            </div>
            <p>关注我们</p>
          </li>
          <li>
            <div class="pic" v-if="footerinfo.zx_ewm">
              <img :src="baseurl+`/public/`+footerinfo.zx_ewm" alt />
            </div>
            <p>立即咨询</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="copy">
      <p>{{footerinfo.foot_content}}</p>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
export default {
  name: "wcfooter",
  data() {
    return {
      baseurl: "",
      footerinfo: []
    };
  }, 
  created() {
    this.baseurl = httpUrl.httpUrl;
    this.$axios.post("/index/api/web_config").then(res => {
      this.footerinfo = res.data.data;
    });
  }
};
</script>
<style lang="less" scoped>
.footer {
  height: 350px;
  min-width: 1200px;
  background: rgba(39, 41, 49, 1);
  position: relative;
  .footercont {
    box-sizing: border-box;
    padding-top: 80px;
    width: 80%;
    min-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 35% 35%;
    .left {
      padding-top: 40px;
      position: relative;
      .gsname {
        font-size: 26px;
        font-family: Microsoft YaHei;
        font-weight: bold;
        color: #ff9443;
      }
      .py {
        color: #ff9443;
      }
      &::after {
        content: "";
        width: 80px;
        height: 4px;
        background: #ff9443;
        position: absolute;
        bottom: 30px;
      }
    }
    .center {
      width: 100%;
      color: white;
      .conli {
        display: grid;
        grid-template-columns: 5% 17% 1fr;
        padding-bottom: 12px;
        .text {
          display: inline-block;
          text-align: justify;
          text-align-last: justify;
        }
      }
    }
    .right {
      color: white;
      .ewm {
        width: 257px;
        display: flex;
        justify-content: space-between;
        li {
          display: inline-block;
          .pic {
            width: 100px;
            height: 100px;
            img {
              width: 100%;
              height: 100%;
            }
          }
          p {
            text-align: center;
          }
        }
      }
    }
    .bt {
      width: 200px;
      font-size: 20px;
      display: flex;
      align-items: flex-end;
      position: relative;
      span {
        padding-left: 5px;
        font-size: 14px;
        color: #47484f;
      }
      &::after {
        content: "";
        width: 257px;
        height: 1px;
        background: white;
        position: absolute;
        bottom: -5px;
      }
    }
    ul {
      padding-top: 40px;
    }
  }
  .copy {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    color: white;
    font-size: 14px;
  }
}
</style>