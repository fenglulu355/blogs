<template>
  <div class="home-team">
    <div class="cont">
      <ul class="contpro contlist">
        <li class="name">
          <p>团队实力</p>
        </li>
        <li class="pic">
          <div
            class="bgpic"
            :style="{backgroundImage: 'url(' +require('@/assets/team-td.png') + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
          ></div>
        </li>
        <li class="intru">
          <div class="top">
            <p>制作团队</p>
            <p class="min">Production Team</p>
          </div>
          <div class="center">
            <p>熟悉原材料的种类、性能、规格及来源</p>
            <p>根据现有的材料去设计出优秀的产品，做到物尽其用</p>
          </div>
          <div class="toleft">
            <img src="../assets/home/jiantou.png" alt />
          </div>
        </li>
      </ul>
      <ul class="contbot contlist">
        <li class="intru">
          <div class="top">
            <p>设计团队</p>
            <p class="min">Design Team</p>
          </div>
          <div class="center">
            <p>家具设计-u家工厂，专注现代、北欧、新中式、轻美式、日式等风格，灰机行业精英，从研发到设计到采买，全称严格把控</p>
          </div>
          <div class="toleft">
            <img src="../assets/home/jiantou.png" alt />
          </div>
        </li>
        <li class="pic">
          <div
            class="bgpic"
            :style="{backgroundImage: 'url(' +require('@/assets/team-sj.png') + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
          ></div>
        </li>
        <li class="name">
          <p>Team Strength</p>
        </li>
      </ul>
    </div>
    <div class="teambg">
      <img src="../assets/banyuan.png" alt />
    </div>
  </div>
</template>

<script>
export default {
  name: "hometeam"
};
</script>
<style lang="less" scoped>
.home-team {
  padding-top: 150px;
  width: 100%;
  min-width: 1200px;
  position: relative;
  .cont {
    width: 80%;
    margin: 0 auto;
    .contpro {
      grid-template-columns: 26% 37% 37%;
      .name {
        &::after {
          top: -45px;
          left: 0;
        }
      }
    }
    .contbot {
      grid-template-columns: 35% 35% 30%;
      .name {
        &::after {
          right: 0;
          top: 45px;
        }
      }
    }
    .contlist {
      display: grid;
      .pic {
        width: 100%;
        height: 300px;
        .bgpic {
          width: 100%;
          height: 100%;
        }
      }
      .name {
        font-size: 40px;
        text-align: center;
        color: #272931;
        position: relative;
        box-sizing: border-box;
        &::after {
          content: "";
          width: 2px;
          height: 300px;
          background: #ff9443;
          position: absolute;
        }
        p {
          position: relative;
          box-sizing: border-box;
          padding-top: 25%;
          &::after {
            content: "";
            width: 44px;
            height: 4px;
            background: #ff9443;
            position: absolute;
            top: 165px;
            left: 50%;
            transform: translateX(-50%);
          }
        }
      }
      .intru {
        background: #272931;
        padding: 38px 20px 0px 40px;
        .top {
          color: #ff9443;
          p {
            font-size: 25px;
          }
          .min {
            padding: 10px 0 20px 0;
            font-size: 17px;
          }
        }
        .center {
          color: white;
          p {
            padding-bottom: 10px;
            line-height: 30px;
          }
        }
        .toleft {
          text-align: right;
          padding-right: 20px;
        }
      }
    }
  }
  .teambg {
    position: absolute;
    right: 0;
    top: 0px;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: -1;
    img {
      max-width: 100%;
      max-height: 100%;
    }
  }
}
</style>