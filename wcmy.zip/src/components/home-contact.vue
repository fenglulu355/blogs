<template>
  <div class="homecontact">
    <div class="mapbox">
      <div class="title">
        <p class="name">
          联系
          <span>我们</span>
        </p> 
        <div class="shadow">
          <p>CONTACT US</p>
        </div>
      </div>
      <div class="content">
        <div class="map">
          <homeMap></homeMap>
        </div>
        <div class="list">
          <div class="slogn">
            <p>
              文春木业专注定制家具
              <span>21</span>年
            </p>
            <img src="../assets/home/bg_02.png" alt />
          </div>
          <ul class="maplist">
            <li class="mapli" v-for="(item, index) in maplistcbox" :key="index">
              <div class="pic">
                <img :src="item.img" alt />
              </div>
              <div class="text">
                <p>{{item.chinese}}</p>
                <span>{{item.english}}</span>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="tocontact">
        <p>
          <a href="tel:phone">联系我们</a>
        </p>
        <div class="pic">
          <a href="tel:phone">
            <img src="../assets/home/pro_right.png" alt />
          </a>
        </div>
      </div>
    </div>
    <div class="bg">
      <img src="../assets/home/bg_12.jpg" alt />
    </div>
  </div>
</template>

<script>
import homeMap from "../components/home-map";
export default {
  name: "homecontact",
  data() {
    return {
      phone: [],
      maplistcbox: [
        {
          img: require("../assets/home/tb_01.png"),
          chinese: "家具设计",
          english: "FURNITURE DESIGN"
        },
        {
          img: require("../assets/home/tb_02.png"),
          chinese: "优质家具",
          english: "QUALITY FURNITURE"
        },
        {
          img: require("../assets/home/tb_03.png"),
          chinese: "艺术品位",
          english: "ARTISTIC TASTE"
        },
        {
          img: require("../assets/home/tb_04.png"),
          chinese: "创意独特",
          english: "UNIQUE CREATIVITY"
        }
      ]
    };
  },
  created() {
    this.$axios.post("/index/api/web_config").then(res => {
      this.phone = res.data.data.phone;
    });
  },
  components: { homeMap }
};
</script>

<style lang="less" scoped>
.title {
  text-align: center;
  position: relative;
  .name {
    font-size: 40px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: rgba(39, 41, 49, 1);
    span {
      color: #ff9443;
    }
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #ff9443;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .shadow {
    opacity: 0.25;
    font-size: 55px;
    color: #8b8e96;
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
  }
}
.homecontact {
  width: 100%;
  min-width: 1200px;
  position: relative;
  .mapbox {
    width: 80%;
    margin: 0 auto;
    padding: 100px 0;
    position: relative;
  
    .content {
          box-shadow: 1px 1px 50px rgba(39, 41, 49, 0.2);
      margin-top: 50px;
      display: grid;
      grid-template-columns: 1fr 365px;
      .map {
        width: 100%;
        img {
          width: 100%;
        }
      }
      .slogn {
        height: 68px;
        position: relative;
        img {
          position: absolute;
          top: 0;
          z-index: -1;
        }
        p {
          text-align: center;
          font-size: 20px;
          font-family: Microsoft YaHei;
          font-weight: 400;
          color: rgba(255, 255, 255, 1);
          line-height: 68px;
          text-shadow: 0px 2px 3px rgba(168, 109, 90, 1);
          span {
            font-size: 36px;
          }
        }
      }
      .maplist {
        box-sizing: border-box;
        height: 488px;
        padding: 60px 0 0 50px;
        .mapli {
          display: flex;
          justify-content: flex-start;
          align-items: center;
          margin-bottom: 45px;
          .text {
            padding-left: 30px;
            font-size: 20px;
            font-family: Microsoft YaHei;
            color: rgba(255, 148, 67, 1);
            p {
              font-weight: bold;
            }
          }
        }
      }
    }
    .tocontact {
      padding-top: 20px;
      float: right;
      display: flex;
      justify-content: space-between;
      width: 200px;
      p {
        padding-top: 5px;
        a {
          font-size: 22px;
          font-family: Microsoft YaHei;
          font-weight: 400;
          color: #ff9443;
        }
      }
      .pic {
        width: 75px;
        height: 43px;
        display: flex;
        align-items: center;
        justify-content: center;
        img {
          max-width: 100%;
          max-height: 100%;
        }
      }
    }
  }
  .bg {
    height: 600px;
    position: absolute;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: -1;
    img {
      max-width: 100%;
      max-height: 100%;
    }
  }
}
</style>