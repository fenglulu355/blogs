<script>
// const httpUrl='http://wcmy.public.5151fw.com/'
const httpUrl='http://www.cdswcmy.com'
export default {
httpUrl
}

</script>