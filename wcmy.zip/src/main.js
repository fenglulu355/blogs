import 'babel-polyfill'
import Vue from 'vue'
import router from './router'
import Axios from 'axios'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import httpUrl from "../src/api/url.vue"
import App from './App'
Vue.use(ElementUI);


Vue.prototype.$axios = Axios
Vue.prototype.httpUrl = httpUrl;
Axios.defaults.baseURL = "http://www.cdswcmy.com/";
Axios.defaults.headers["Content-type"] = "application/json";



// Axios.defaults.headers["Access-Control-Allow-Origin-type"] = "*";

// Axios.defaults.baseURL = "http://wcmy.public.5151fw.com/";

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: {
    App
  },
  template: '<App/>'
})
