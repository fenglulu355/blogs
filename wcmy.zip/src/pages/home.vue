<template>
  <div class="home pages">
    <!--轮播 -->
    <div class="carousel">
      <el-carousel height="790px" direction="vertical">
        <el-carousel-item v-for="(item,index) in banner" :key="index">
             <div class="mainpic" 
            :style="{backgroundImage: 'url(' +baseurl+`/public/`+item.image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center',
            }"></div>
        </el-carousel-item>
      </el-carousel>
    </div>
    <!-- 矩形 -->
    <div class="rec-box">
      <ul class="rec-list">
        <li class="rec-li" v-for="(recli, index) in recbox" :key="index">
          <div class="pic">
            <img :src="recli.img" alt />
          </div>
          <div class="text">
            <p>{{recli.chinese}}</p>
            <span>{{recli.english}}</span>
          </div>
        </li>
      </ul>
    </div>
    <!-- 主页轮播 -->
    <div class="index-wrap">
      <router-view ></router-view>
    </div>
    <!-- 主页新闻 -->
    <homenews></homenews>
    <!-- 主页团队 -->
    <hometeam></hometeam>
    <!-- 主页案例 -->
    <homecase></homecase>
    <!-- 主页联系我们 -->
    <homecontact></homecontact>
  </div>
</template>

<script>
import httpUrl from "../api/url";
import homelb from "../components/home-lb";
import homenews from "../components/home-news";
import hometeam from "../components/home-team";
import homecase from "../components/home-case";
import homecontact from "../components/home-contact";
export default {
  name: "home",
  data() {
    return {
       baseurl: "",
      banner: [],
      recbox: [
        {
          img: require("@/assets/sj.png"),
          chinese: "家具设计",
          english: "FURNITURE DESIGN"
        },
        {
          img: require("@/assets/dz.png"),
          chinese: "优质家具",
          english: "QUALITY FURNITURE"
        },
        {
          img: require("@/assets/zs.png"),
          chinese: "艺术品位",
          english: "ARTISTIC TASTE"
        },
        {
          img: require("@/assets/cy.png"),
          chinese: "创意独特",
          english: "UNIQUE CREATIVITY"
        }
      ]
    };
  },
  components: {
    homelb,
    homenews,
    hometeam,
    homecase,
    homecontact
  },
    created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
     requst() {
      this.$axios
        .post("/index/api/getBanner")
        .then(res => {
          this.banner=res.data.data
        });
    },
  }
};
</script>
<style lang="less" scoped>
// 轮播图
.carousel {
  min-width: 1200px;
}
.el-carousel__item {
  width: 100%;
  min-width: 1200px;
  .mainpic{
    width: 100%;
    height: 790px;
  }
}
.el-carousel__button {
  background-color: #ff9442;
}
// 矩形
.rec-box {
  background: #171c22;
  height: 120px;
  min-width: 1200px;
  .rec-list {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    .rec-li {
      height: 120px;
      display: inline-block;
      color: #ff9442;
      display: grid;
      grid-template-columns: 40% 60%;
      .pic {
        justify-self: flex-end;
        width: 55px;
        height: 55px;
        line-height: 120px;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .text {
        padding: 40px 15px;
        p {
          font-weight: bold;
          margin-bottom: 5px;
        }
      }
      &:hover {
        background: #ff9442;
        color: white;
      }
    }
  }
}

</style>