<template>
  <div class="contact pages">
    <Banner></Banner>
    <div class="content">
      <div class="title">
        <p class="name">
          联系
          <span>我们</span>
        </p>
        <div class="shadow">
          <p>CONTACT US</p>
        </div>
      </div>
      <div class="mapbox">
        <div class="left">
          <bdmap></bdmap>
        </div>
        <div class="right">
          <div class="rttop">
            <p class="tomine">给我们致电</p>
            <a class="tel" href="tel:phone">{{infos.phone}}</a>
          </div>
          <div class="lxfs">
            <div class="email lxfsbox">
              <div class="icon">
                <img src="../assets/contact/email.png" alt />
              </div>
              <p class="text">邮箱</p>
              <p class="cont">：{{infos.email}}</p>
            </div>
            <div class="location lxfsbox">
              <div class="icon dw">
                <img src="../assets/contact/dw.png" alt />
              </div>
              <p class="text">公司地址</p>
              <p class="cont diz">：{{infos.address}}</p>
            </div>
          </div>
          <form action>
            <div class="rtbd">
              <p class="tomine">给我们留言</p>
              <div class="info">
                <div class="nametel">
                  <input type="text" placeholder="姓名" v-model="name" />
                  <input type="text" placeholder="电话" v-model="tel" @blur="regTel(tel)" />
                </div>
                <div class="yx">
                  <input type="text" placeholder="邮箱" v-model="email" @blur="regEmail(email)" />
                </div>
                <div class="words">
                  <textarea
                    class="textarea"
                    v-model="words"
                    placeholder="想对我们说的话..."
                    @blur="regWords(words)"
                  ></textarea>
                </div>
              </div>
              <div class="sub">
                <p class="btn" @click="sendinfo">提交</p>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import Banner from "../components/banner";
import bdmap from "../components/map";
export default {
  name: "contact",
  data() {
    return {
      infos: [],
      name: "",
      tel: "",
      email: "",
      words: "",
      texts: ""
    };
  },
  components: { Banner, bdmap },
  created() {
    this.request();
  },
  methods: {
    sendinfo() {
      if (
        this.name == "" ||
        this.email == "" ||
        this.tel == "" ||
        this.words == ""
      ) {
        alert("您的留言信息还没有完善哦！");
      } else {
        this.$axios
          .post("/index/api/web_config", {
            name: this.name,
            phone: this.tel,
            email: this.email,
            content: this.texts
          })
          .then(res => {
            this.name = "";
            this.email = "";
            this.tel = "";
            this.words = "";
            alert("提交成功，感谢您的留言");
          });
      }
    },
    regTel(tel) {
      if (tel == "") {
        this.tel = "";
      } else {
        let reg = /^[1][3,4,5,7,8,9][0-9]{9}$/,
          telnum = reg.test(tel);
        if (telnum == false) {
          alert("手机格式不正确");
        }
      }
    },
    regEmail(email) {
      if (email == "") {
        this.email = "";
      } else {
        let reg = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/,
          emailnum = reg.test(email);
        if (emailnum == false) {
          alert("邮箱格式不正确");
        }
      }
    },
    regWords(words) {
      let regwords = words.replace(/<\/?[^>]*>/g, "");
      this.texts = regwords;
    },
    request() {
      this.$axios.post("/index/api/web_config").then(res => {
        this.infos = res.data.data;
      });
    }
  }
};
</script>

<style lang="less" scoped>
.title {
  text-align: center;
  position: relative;
  .name {
    font-size: 40px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: rgba(39, 41, 49, 1);
    span {
      color: #ff9443;
    }
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #ff9443;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .shadow {
    opacity: 0.25;
    font-size: 55px;
    color: #8b8e96;
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
  }
}
.contact {
  width: 100%;
  min-width: 1200px;
  background: #f5f5f5;
}
.content {
  padding: 100px 0 200px 0;
  width: 80%;
  margin: 0 auto;
  .mapbox {
    padding-top: 100px;
    height: 680px;
    display: grid;
    grid-template-columns: 70% 30%;
    .left {
      width: 100%;
      height: 680px;
    }
    .right {
      background: white;
      padding-left: 7%;
      color: #272931;
      .rttop {
        padding-top: 15%;
        .tomine {
          font-size: 22px;
          padding-bottom: 10px;
        }
        .tel {
          color: #272931;
          font-size: 40px;
        }
      }
      .lxfs {
        padding-top: 10%;
        width: 100%;
        .lxfsbox {
          display: grid;
          grid-template-columns: 8% 25% 1fr;
          padding-bottom: 12px;
          .text {
            display: inline-block;
            text-align: justify;
            text-align-last: justify;
            align-self: flex-end;
          }
          .cont {
            align-self: flex-end;
            width: 100%;
            // line-height: 24px;
          }
         
          .icon {
            align-self: flex-end;
          }
          .dw {
            box-sizing: border-box;
            padding-left: 2px;
          }
        }
        .location{
          position: relative;
          .diz{
            position: absolute;
            width: 67%;
            right: 0;
            top: 2px;
            line-height: 24px;
          }
        }
      }
      .rtbd {
        padding-top: 15%;
        .tomine {
          font-size: 22px;
        }
        .info {
          padding-top: 30px;
          width: 88%;
          input {
            outline: none;

            border-bottom: 1px solid #e6e6e6;
            padding-bottom: 5px;
            &::placeholder {
              color: #929396;
            }
          }
          .nametel {
            width: 100%;
            display: grid;
            grid-template-columns: 48% 48%;
            grid-gap: 4%;
            input {
              width: 100%;
            }
          }
          .yx {
            padding: 20px 0;
            width: 100%;
            input {
              width: 100%;
            }
          }
          .words {
            width: 100%;
            height: 120px;
            .textarea {
              border-bottom: 1px solid #e6e6e6;
              resize: none;
              width: 100%;
              height: 100%;
              color: #929396;
              &::placeholder {
                color: #929396;
                font-family: Microsoft YaHei;
              }
            }
          }
        }
        .sub {
          margin-top: 20px;
          width: 132px;
          height: 39px;
          background: #ff9443;
          border-radius: 6px;
          .btn {
            cursor: pointer;
            text-align: center;
            line-height: 39px;
            font-size: 20px;
            color: rgba(255, 255, 255, 1);
          }
        }
      }
    }
  }
}
</style>


