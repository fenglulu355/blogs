<template>
  <div class="news pages">
    <Banner></Banner>
    <div class="content">
      <div class="title">
        <p class="name">
          新闻
          <span>动态</span>
        </p>
        <div class="shadow">
          <p>NEWS DYNAMIC</p>
        </div>
      </div>
      <ul class="newslist">
        <li class="newsli clearFix" v-for="(item, index) in newslist" :key="index" @click="todetails(item)">
          <div class="pic">
            <div
              class="newspic"
              :style="{backgroundImage: 'url(' +baseurl+`/public/`+item.image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
            ></div>

            <img class="yy" src="../assets/news/newsyy.png" alt />
          </div>
          <p class="newtitle">{{item.article_title}}</p>
          <section v-html="item.desc"></section>
          <p class="more fr">MORE+</p>
        </li>
      </ul>
    </div>
    <div class="pagenation">
      <el-pagination
        background
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage1"
        :page-size="6"
        layout=" prev, pager, next"
        :total="totalPage"
      ></el-pagination>
    </div>
  </div>
</template>


<script>
import Banner from "../components/banner";
import httpUrl from "../api/url";
export default {
  name: "news",
  data() {
    return {
      newslist: [],
      baseurl: "",
      currentPage1: 1,
      totalPage: 1,
      setPage: 1
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    handleCurrentChange(val) {
      this.setPage = val;
      this.requst();
    },
    requst() {
      this.$axios
        .post("/index/api/getNewsList", {
          page: this.setPage,
          limit: 6
        })
        .then(res => {
          this.newslist = res.data.data.data;
          this.totalPage = res.data.data.total.length;
        });
    },
    todetails(item) {
      let id = item.article_id;
      this.$router.push({ path: "/details", query: { id: id, kind: "news" } });
    }
  },
  components: { Banner }
};
</script>

<style lang="less" scoped>
.title {
  text-align: center;
  position: relative;
  .name {
    font-size: 40px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: rgba(39, 41, 49, 1);
    span {
      color: #ff9443;
    }
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #ff9443;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .shadow {
    opacity: 0.25;
    font-size: 55px;
    color: #8b8e96;
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
  }
}
.news {
  width: 100%;
  min-width: 1200px;
  background: #f5f5f5;
}
.content {
  padding-top: 100px;
  min-width: 1200px;
  width: 80%;
  margin: 0 auto;
  .newslist {
    box-sizing: border-box;
    padding-top: 100px;
    display: grid;
    width: 100%;
    grid-template-columns: repeat(3, 30%);
    justify-content: space-between;
    grid-row-gap: 6%;
    .newsli {
      width: 100%;
      background: #ffffff;
      border-radius: 15px;
      .pic {
        width: 100%;
        height: 290px;
        position: relative;
        .newspic {
          width: 100%;
          height: 290px;
        }
        .yy {
          position: absolute;
          top: 0;
          width: 100%;
          height: 100%;
          display: none;
        }
        &:hover .yy {
          cursor: pointer;
          display: block;
        }
      }
      .newtitle {
        box-sizing: border-box;
        width: 90%;
        padding: 20px 0 40px 20px;
        font-size: 30px;
        line-height: 30px;
        color: #57585a;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        word-break: break-all;
      }
      section {
        color: #57585a;
        margin: 0 auto;
        width: 90%;
        text-indent: 2em;
        line-height: 25px;
        height: 70px;
        word-break: break-all;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
        overflow: hidden;
      }
      .more {
        cursor: pointer;
        margin: 30px;
        width: 140px;
        height: 40px;
        line-height: 40px;
        font-size: 24px;
        text-align: center;
        color: #f1f1f1;
        border-radius: 10px;
        background: #ff9443;
      }
    }
  }
}
.pagenation {
  text-align: center;
  width: 100%;
  padding: 100px 0;
}
</style>