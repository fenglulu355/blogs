<template>
	<view class="ordermain">
		<view class="order-top">
				<image class="img" src="../../static/top.png" mode="" style="height: 65rpx; width: 80rpx"></image>
			
			<view class="text">待物流取货</view>
			<view class="text-g">请尽快包装好货品，物流将上门取货</view>
			<view class="ot-btn">
				<view class="ot-btn-state btn">
					物流状态
				</view>
				<view class="tocall btn curbtn">
					联系物流
				</view>
			</view>
		</view>
		<view class="order-data">
			<view >成都 → 成都</view>
			<view class='time'>全程预计3天</view>
			
		</view>
		<view class="infos">
			<!-- 运输信息 -->
			<view class="intransit odbox">
				<view class="icon">
					<image src="../../static/car.png" mode=""  
					style="height: 40rpx; width: 40rpx"></image>
					<text>运输信息</text>
				</view>
				<view class="sendinfo ">
					<view class="line">
						<text class="left">发货信息</text>
						<text class="right">{{startinfo}}</text>
					</view>
					<view class="line">
						<text class="left">收货信息</text>
						<text class="right">{{endinfo}}</text>
					</view>
					<view class="line">
						<text class="left">发货时间</text>
						<text class="right">{{time}}</text>
					</view>
				</view>
			</view>
			<!-- 货物信息 -->
			<view class="intransit odbox">
				<view class="icon">
					<image src="../../static/send.png" mode="" style="height: 40rpx; width: 40rpx"
					></image>
					<text>货物信息</text>
				</view>
				<view class="sendinfo ">
					<view class="line">
						<text class="left">货品类型</text>
						<text class="right">{{type}}</text>
					</view>
					<view class="line">
						<text class="left">货品名称/数量</text>
						<text class="right">{{num}}</text>
					</view>
					<view class="line">
						<text class="left">封装规格</text>
						<text class="right">{{size}}</text>
					</view>
				</view>
			</view>
			<!-- 其他信息 -->
			<view class="intransit odbox">
				<view class="icon">
					<image src="../../static/other.png" mode="" style="height: 40rpx; width: 40rpx"></image>
					<text>其他信息</text>
				</view>
				<view class="sendinfo ">
					<view class="line">
						<text class="left">下单时间</text>
						<text class="right">{{creattime}}</text>
					</view>
					<view class="line">
						<text class="left">运单号</text>
						<text class="right">{{ordernum}}</text>
					</view>
					<view class="line">
						<text class="left">验证码</text>
						<text class="right">{{code}}</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				startinfo:'成都市武侯区新希望大厦7楼704室',
				endinfo:'成都市武侯区新希望大厦',
				time:'2019-08-07 11:30',
				type:'玻璃制品',
				num:'艺术品/50箱',
				size:'30*30*30cm',
				creattime:'2019-08-07 11:30',
				ordernum:'aeqweqwd484sd894',
				code:'1565sd'
			}
			
		
		},
		methods: {
			
		}
	}
</script>

<style scoped> 
.ordermain{
	width: 100%;
	background: #f5f5f5;
	box-sizing: border-box;
	padding: 40rpx 25rpx 80rpx 25rpx;
}
/* top */
.order-top{
	width: 100%;
	height: 350rpx;
	background: white;
	border-radius: 20rpx;
	text-align: center;
	box-sizing: border-box;
	padding-top: 55rpx;
}
.order-top .text{
	font-size: 32rpx;
	box-sizing: border-box;
	padding-top: 15rpx;
}
.order-top .text-g{
	font-size: 30rpx;
	color: #a1a1a1;
		box-sizing: border-box;
	padding-top: 15rpx;
}
.order-top .ot-btn{
	box-sizing: border-box;
	padding-top: 20rpx;
}
.order-top .btn{
	display: inline-block;
	box-sizing: border-box;
	margin: 0 10rpx;
	width: 160rpx;
	height: 65rpx;
	border:1rpx solid #999999;
	text-align: center;
	line-height: 65rpx;
	font-size: 30rpx;
	border-radius: 10rpx;
}
.order-top .curbtn{
	border-color:#f08519;
	background: #f08519;
	color: white;
}
/* order-data */
.order-data{
	width: 100%;
	height: 95rpx;
	background: white;
	border-radius: 20rpx;
	text-align: center;
	box-sizing: border-box;
	padding: 0rpx 25rpx;
	margin-top:20rpx ;
	display: flex;
	justify-content: space-between;
}
.order-data view{
	line-height: 95rpx;
	font-size: 32rpx;
}
.order-data .time{
	font-size: 28rpx;
}
/* infos */
.infos{
	box-sizing: border-box;
	margin-top: 20rpx;
}
.infos .odbox{
	width: 100%;
	/* height: 320rpx; */
	background: white;
	border-radius: 20rpx;
	box-sizing: border-box;
	padding: 25rpx 25rpx;
	margin-top: 20rpx;
}
.infos .odbox .icon{
	font-size: 30rpx
}
.infos .odbox .icon text{
	box-sizing: border-box;
	padding-left: 10rpx;
	position: relative;
	bottom: 6rpx;
}
.infos .odbox .sendinfo .line{
	/* background: #007AFF; */
	box-sizing: border-box;
	padding-top: 20rpx;
	font-size: 30rpx;
	display: flex;
	justify-content: space-between;
}
.infos .odbox .sendinfo .line .left{
	width: 35%;
	color: #d3d3d3;
}
.infos .odbox .sendinfo .line .right{
	width: 65%;
	text-align: right;
}
</style>
