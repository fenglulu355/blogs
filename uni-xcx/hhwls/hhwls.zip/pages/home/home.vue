<template>
	<view class="home">
		<view class="home-banner">
			<image class="img" src="../../static/home.png" mode=""
			></image>
		</view>
		<view class="searchbox">
			<input type="text" value="" placeholder="搜索姓名/电话/单号" />
			<image class="img" src="../../static/search.png" mode=""></image>
		</view>
		<view class="tel">
			查询、投诉电话：028-8308 7633
		</view>
		<view class="text">
			康定  色达  雅江  即将开通敬请期待
		</view>
		<view class="footer">
			<image class="img" src="../../static/logo.png" mode=""></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
.home{
	width: 100%;
	background: #f5f5f5;
	box-sizing: border-box;
	padding: 40rpx 25rpx 80rpx 25rpx;
	
}
.home .home-banner{
	width: 100%;
	height: 355rpx;
	border-radius: 20rpx;
	
}
.home .home-banner .img{
	width: 100%;
	height: 100%;
	border-radius: 20rpx;	
}
.home .searchbox{
	width: 100%;
	height: 100rpx;
	box-sizing: border-box;
	margin-top: 20rpx;	
	background: white;
	position: relative;
	border-radius: 20rpx;
}
.home .searchbox input{
	width: 90%;
	height: 100%;
	font-size: 30rpx;
	box-sizing: border-box;
	padding: 0 30rpx 0 10rpx;
}
.home .searchbox .img{
	position: absolute;
	width: 40rpx;
	height: 40rpx;
	right: 40rpx;
	top: 50%;
	transform: translateY(-50%)
	
}
.home .tel{
	box-sizing: border-box;
	padding: 65rpx 0 25rpx;
	font-size: 30rpx;
	text-align: center;
	color: #6a6a6a;
}
.home .text{
	font-size: 26rpx;
	text-align: center;
	color: #6a6a6a;
	background: #ececec;
	width: 70%;
	margin: 0 auto;
	line-height: 40rpx;
	border-radius: 20rpx;
}
.home .footer{
	box-sizing: border-box;
	padding-top: 390rpx;
	text-align: center;
}
.home .footer .img{
	width: 420rpx;
	height: 60rpx;
}
</style>
