<script>
const httpUrl='http://www.cdswcmy.com'
// const httpUrl='http://wcmy.public.5151fw.com/'
export default {
httpUrl
}

</script>