<template>
  <div class="product">
    <Banner></Banner>
    <div class="content">
      <div class="title">
        <p class="name">
          产品
          <span>详情</span>
        </p>
        <div class="shadow">
          <p>PRODUCT</p>
        </div>
      </div>
      <div class="details">
        <div class="de-head">
          <p class="de-title">{{infos.article_title}}</p>
          <p class="de-tinum">
            <span>浏览量：{{infos.article_num}}</span>
            <span>发布时间：{{infos.created_time}}</span>
          </p>
        </div>
        <div class="de-cont">
          <div class="de-info" id="deinfos" v-html="infos.article_content">
            <!-- <div id="deinfos"></div> -->
          </div>
        </div>
        <div class="page">
          <p class="prev" @click="toprev" v-if="prevtitle">上一篇：{{prevtitle}}</p>
          <p class="next" @click="tonext" v-if="nexttitle">下一篇：{{nexttitle}}</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Banner from "../components/banner";
import httpUrl from "../api/url";
export default {
  name: "prodetails",
  data() {
    return {
      baseurl: "",
      backgroundImg: {
        backgroundImage: "url(" + require("@/assets/bg-black.png") + ")",
        backgroundRepeat: "no-repeat",
        backgroundSize: "150% 150%"
      },
      infos: [],
      detailid: "",
      previd: "",
      nextid: "",
      prevtitle: "",
      nexttitle: "",
      kind: ""
    };
  },
  created() {
    this.baseurl = httpUrl.httpUrl;
    this.detailid = this.$route.query.id;
    this.kind = this.$route.query.kind;
    if (this.kind == "case") {
      this.requstCase(this.detailid);
    }
    if (this.kind == "news" || this.kind == "product") {
      this.requst(this.detailid);
    }
    if (this.kind == "base") {
      this.requstBase(this.detailid);
    }
  
  },
  updated() {
    let a=document.getElementById('deinfos')
    let imgs=a.getElementsByTagName('img')
    for(let i=0;i< imgs.length;i++){
      imgs[i].style.width='100%'
    }
  },
  methods: {
    requstnext() {
      this.$axios
        .post("/index/api/getNewsShow", { id: this.nextid })
        .then(res => {
          this.nexttitle = res.data.data.article_title;
        });
    },
    requstprev() {
      this.$axios
        .post("/index/api/getNewsShow", { id: this.previd })
        .then(res => {
          this.prevtitle = res.data.data.article_title;
        });
    },
    requst(val) {
      this.$axios.post("/index/api/getNewsShow", { id: val }).then(res => {
        this.infos = res.data.data;
        this.previd = res.data.data.prov;
        this.nextid = res.data.data.next;
        this.requstnext();
        this.requstprev();
      });
    },
    requstCase(val) {
      this.$axios.post("/index/api/getCaseShow", { id: val }).then(res => {
        this.infos = res.data.data;
        this.previd = res.data.data.prov;
        this.nextid = res.data.data.next;
        this.requstnext();
        this.requstprev();
      });
    },
    requstBase(val) {
      this.$axios.post("/index/api/getBaseShow", { id: val }).then(res => {
        this.infos = res.data.data;
        this.previd = res.data.data.prov;
        this.nextid = res.data.data.next;
        this.requstnext();
        this.requstprev();
      });
    },
    toprev() {
      this.requst(this.previd);
    },
    tonext() {
      this.requst(this.nextid);
    }
  },
  components: { Banner }
};
</script>

<style  scoped>
.title {
  text-align: center;
  position: relative;
}
.title .name {
  font-size: 40px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: rgba(39, 41, 49, 1);
}
.title .name span {
  color: #ff9443;
}
.title .name span::after {
  content: "";
  width: 44px;
  height: 4px;
  background: #ff9443;
  position: absolute;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
}
.title .shadow {
  width: 100%;
  opacity: 0.25;
  font-size: 55px;
  color: #8b8e96;
  position: absolute;
  top: -30px;
  left: 50%;
  transform: translateX(-50%);
}
.product {
  width: 100%;
  margin-bottom: 30px;
}
.content {
  padding: 100px 0 60px 0;
  width: 95%;
  margin: 0 auto;
}
.content .details {
  border-top: 1px solid rgba(0, 0, 0, 0.1);
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  margin-top: 70px;
}
.content .details .de-head {
  text-align: center;
}
.content .details .de-head .de-title {
  font-size: 36px;
  padding-top: 30px;
}
.content .details .de-head .de-tinum {
  color: #aaaaaa;
  font-size: 14px;
  padding: 30px 0;
}
.content .details .de-cont {
  border-top: 1px solid rgba(0, 0, 0, 0.1);
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  width: 95%;
  margin: 0 auto;
}
.content .details .de-cont .de-info {
  width: 100%;
  line-height: 35px;
  padding: 30px 0;
  white-space: pre-wrap;
  white-space: pre-line;
  word-break: break-all;
}
/* .content .details .de-cont .de-info p >>> img{
  width: 100%;
} */
.content .details .de-cont .de-pic {
  width: 100%;
  height: 380px;
  padding: 30px 0px;
  text-align: center;
}
.content .details .de-cont .de-pic .bg {
  width: 100%;
  height: 100%;
}
.content .details .page {
  width: 95%;
  margin: 0px auto;
  color: #5a5a5a;
  font-size: 14px;
  padding: 30px 0;
}
.content .details .page p {
  padding: 10px 0;
  cursor: pointer;
}
</style>