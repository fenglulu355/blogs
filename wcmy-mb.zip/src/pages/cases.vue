<template>
  <div class="cases">
    <Banner></Banner>
    <div class="content">
      <div class="title">
        <p class="name">
          经典
          <span>案例</span>
        </p>
        <div class="shadow">
          <p>CLASSIC CASE</p>
        </div>
      </div>
      <ul class="prolist">
        <li class="caseli" v-for="(item, index) in caselist" :key="index" @click="todetails(item)">
          <div class="pic">
            <div
              class="casepic"
              :style="{backgroundImage: 'url(' +baseurl+`/public/`+item.image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
            ></div>
          </div>
        </li>
      </ul>
    </div>
    <div class="pagenation">
      <el-pagination
        small
        background
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage1"
        :page-size="6"
        layout=" prev, pager, next"
        :total="totalPage"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import Banner from "../components/banner";
import httpUrl from "../api/url";
export default {
  name: "cases",
  data() {
    return {
      baseurl: "",
      caselist: [],
      currentPage1: 1,
      totalPage: 1,
      setPage: 1
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    todetails(item) {
      let id = item.article_id;
      this.$router.push({ path: "/details", query: { id: id, kind: "case" } });
    },
    handleCurrentChange(val) {
      this.setPage = val;
      this.requst();
    },
    requst() {
      this.$axios
        .post("/index/api/getCaseList", {
          page: this.setPage,
          limit: 6
        })
        .then(res => {
          this.caselist = res.data.data.data;
          this.totalPage = res.data.data.total.length;
        });
    }
  },
  components: { Banner }
};
</script>

<style lang="less" scoped>
.title {
  text-align: center;
  position: relative;
  .name {
    font-size: 40px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: rgba(39, 41, 49, 1);
    span {
      color: #ff9443;
    }
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #ff9443;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .shadow {
    width: 100%;
    opacity: 0.25;
    font-size: 55px;
    color: #8b8e96;
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
  }
}
.cases {
  width: 100%;
}
.content {
  width: 95%;
  margin: 100px auto;
  .prolist {
    margin-top: 100px;
    display: grid;
    width: 100%;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 2.5%;
    .caseli {
      width: 100%;
      .pic {
        width: 100%;
        height: 260px;
        position: relative;
        .casepic {
          cursor: pointer;
          width: 100%;
          height: 260px;
        }
        img {
          width: 100%;
          height: 100%;
          border-radius: 10px;
        }
      }
    }
  }
}
.pagenation {
  margin-bottom: 40px;
  width: 100%;
  height: 80px;
  text-align: center;
}
</style>

