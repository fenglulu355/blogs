<template>
  <div class="product">
    <Banner></Banner>
    <div class="content">
      <div class="title">
        <p class="name">
          产品
          <span>中心</span>
        </p>
        <div class="shadow">
          <p>PRODUCT</p>
        </div>
      </div>
      <div class="promain">
        <div class="warpper clearFix">
          <!-- 按钮 -->
          <ul class="slide-pages fr">
            <li class="bottom prev" @click="prevBtn">
              <img src="../assets/home/pro_left.png" alt />
            </li>
            <li class="pages">
              <div
                class="router-box"
                v-for="(item, index) in paths"
                :key="index"
                @click="addBg(index)"
              >
                <router-link :to="item">
                  <div class="pages-box" :class="activeClass ==index?'show':''"></div>
                </router-link>
              </div>
            </li>
            <li class="bottom next" @click="nextBtn">
              <img src="../assets/home/pro_right.png" alt />
            </li>
          </ul>
          <router-view></router-view>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Banner from "../components/banner";
export default {
  name: "product",
  data() {
    return {
      activeClass: 0,
      paths: ["/product", "/product/flxed", "/product/room"]
    };
  },
  methods: {
    addBg(index) {
      this.activeClass = index;
    },
    prevBtn() {
      if (this.$route.path == "/product/room") {
        this.$router.push({ path: "/product/flxed" });
        this.activeClass = 1;
        return;
      }
      if (this.$route.path == "/product/flxed") {
        this.$router.push({ path: "/product" });
             this.activeClass = 0;
        return;
      }
    },
    nextBtn() {
      if (this.$route.path == "/product") {
        this.$router.push({ path: "/product/flxed" });
        this.activeClass = 1;
        return;
      }
      if (this.$route.path == "/product/flxed") {
        this.$router.push({ path: "/product/room" });
        this.activeClass = 2;
        return;
      }
    }
  },
  components: { Banner }
};
</script>

<style lang="less" scoped>
.title {
  text-align: center;
  position: relative;
  .name {
    font-size: 40px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: #ff9443;
    span {
      color: white;
    }
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #ff9443;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .shadow {
    opacity: 0.25;
    font-size: 55px;
    color: #8b8e96;
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
  }
}
.product {
  width: 100%;
    background: #272931;
}
.content {

  padding: 100px 0 200px 0;
  width: 95%;
  margin: 0 auto;
  .warpper {
    margin: 0 auto;
    // overflow: hidden;
    // 按钮
    .slide-pages {
      width: 100%;
      height: 100px;
      position: relative;
      z-index: 1;
      .pages {
        width: 200px;
        height: 30px;
        margin: 52px auto;
        display: flex;
        justify-content: space-between;
        .pages-box {
          background: #f5f0f0;
          width: 55px;
          height: 5px;
          cursor: pointer;
          &:hover {
            background: #ff9443;
          }
        }
        .show {
          background:#ff9443;
        }
      }
      .bottom {
  
        position: absolute;
        bottom: 31px;
        cursor: pointer;
        width: 50px;
        img{
          width: 100%;

        }
      }
      .next {
        right: 25%;
      }
      .prev{
        left: 25%;
      }
    }
  }
}
</style>