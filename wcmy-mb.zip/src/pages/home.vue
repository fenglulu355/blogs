<template>
  <div class="home">
    <!--轮播 -->
    <div class="carousel">
      <van-swipe :autoplay="3000" indicator-color="#d29370">
        <van-swipe-item v-for="(item, index) in banner" :key="index">
          <div class="mainpic" 
            :style="{backgroundImage: 'url(' +baseurl+`/public/`+item.image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center',
            }"></div>
        </van-swipe-item>
       
      </van-swipe>
    </div>
    <!-- 矩形 -->
    <div class="rec-box">
      <ul class="rec-list">
        <li class="rec-li" v-for="(recli, index) in recbox" :key="index">
          <div class="pic">
            <img :src="recli.img" alt />
          </div>
          <div class="text">
            <p>{{recli.chinese}}</p>
            <span>{{recli.english}}</span>
          </div>
        </li>
      </ul>
    </div>
    <!-- 主页轮播 -->
    <div class="index-wrap">
      <router-view></router-view>
      <!-- <lbs :slides="slides"></lbs> -->
    </div>
    <!-- 主页新闻 -->
    <homenews></homenews>
    <!-- 主页团队 -->
    <hometeam></hometeam>
    <!-- 主页案例 -->
    <homecase></homecase>
    <!-- 主页联系我们 -->
    <homecontact></homecontact>
  </div>
</template>

<script>
import httpUrl from "../api/url";

import homelb from "../components/home-lb";
import homenews from "../components/home-news";
import hometeam from "../components/home-team";
import homecase from "../components/home-case";
import homecontact from "../components/home-contact";
export default {
  name: "home",
  data() {
    return {
      banner: [],
      recbox: [
        {
          img: require("@/assets/sj.png"),
          chinese: "家具设计",
          english: "FURNITURE DESIGN"
        },
        {
          img: require("@/assets/dz.png"),
          chinese: "优质家具",
          english: "QUALITY FURNITURE"
        },
        {
          img: require("@/assets/zs.png"),
          chinese: "艺术品位",
          english: "ARTISTIC TASTE"
        },
        {
          img: require("@/assets/cy.png"),
          chinese: "创意独特",
          english: "UNIQUE CREATIVITY"
        }
      ],
      slides: [
        { src: require("../assets/product.png") },
        { src: require("../assets/01.jpg") },
        { src: require("../assets/01.jpg") }
      ]
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    requst() {
      this.$axios.post("/index/api/getBanner").then(res => {
        this.banner = res.data.data;
      });
    }
  },
  components: {
    homelb,
    homenews,
    hometeam,
    homecase,
    homecontact
  }
};
</script>
<style lang="less" scoped>
.carousel {
  width: 100%;
  .van-swipe-item {
    width: 100%;
    height: 400px;
   .mainpic{
     width: 100%;
     height: 400px;
   }
  }
}
// 矩形
.rec-box {
  background: #171c22;
  height: 400px;
  // min-width: 1200px;
  .rec-list {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    .rec-li {
      height: 200px;
      display: inline-block;
      color: #ff9442;
      display: grid;
      grid-template-columns: 25% 70%;
      grid-gap: 5%;
      .pic {
        justify-self: flex-end;
        width: 60px;
        height: 60px;
        line-height: 200px;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .text {
        padding: 70px 0;
        p {
          font-weight: bold;
          margin-bottom: 5px;
        }
      }
      &:active {
        background: #ff9442;
        color: white;
      }
    }
  }
}

</style>