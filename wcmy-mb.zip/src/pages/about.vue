<template>
  <div class="about">
    <Banner></Banner>
    <div class="content">
      <div class="title">
        <p class="name">
          关于
          <span>我们</span>
        </p>
        <div class="shadow">
          <p>ABOUT US</p>
        </div>
      </div>
      <div class="introduce">
        <div class="left">
          <div class="lftop">
            <p>以人为本是文春家具设计、</p>
            <p>定做家具/制造家具的精髓所在</p>
          </div>
          <div class="lfbt">
            <section v-html="infos.desc"></section>
          </div>
        </div>
      </div>
      <div class="pic">
        <div
          class="mainpic"
          :style="{backgroundImage: 'url(' +baseurl+`/public/`+infos.image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
        ></div>
      </div>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
import Banner from "../components/banner";
export default {
  name: "about",

  data() {
    return {
        baseurl: "",
      infos: []
    };
  },
 created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    requst() {
      this.$axios.post("/index/api/about").then(res => {
        this.infos = res.data.data;
     
      });
    }
  },
  components: { Banner }
};
</script>

<style lang="less" scoped>
.title {
  text-align: center;
  position: relative;
  .name {
    font-size: 40px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: rgba(39, 41, 49, 1);
    span {
      color: #ff9443;
    }
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #ff9443;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .shadow {
    opacity: 0.25;
    font-size: 55px;
    color: #8b8e96;
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
  }
}
.content {
  padding: 100px 0;
  width: 95%;
  margin: 0 auto;
}
.content {
  .introduce {
    width: 100%;
    padding-top: 70px;
    .left {
      .lftop {
        padding: 10px 0;
        border-top: 2px solid #ff9443;
        border-bottom: 2px solid #ff9443;
        font-size: 36px;
        color: #4a4b4d;
        line-height: 45px;
      }
      .lfbt {
        color: #57585a;
        font-size: 16px;
        padding: 40px 0 100px 0;
        section {
          line-height: 40px;
            white-space: pre-wrap;
          white-space: pre-line;
          word-break: break-all;
        }
      }
    }
  }
  .pic {
    width: 100%;
    height: 530px;
    .mainpic {
      width: 100%;
      height: 100%;
    }
  }
}
</style>