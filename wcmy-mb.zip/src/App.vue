<template>
  <div id="app">
    <navagetion></navagetion>
    <router-view />
    <wcfooter></wcfooter>
  </div>
</template>

<script>
import navagetion from "./components/navagetion.vue";
import normalized from "./assets/normalized.css";
import wcfooter from "./components/wcfooter";
export default {
  name: "App",
  mounted() {
     let dz = window.location.href;
    if (dz.indexOf("wwww") == -1) {
      window.location.href = "http://www.cdswcmy.com/mindex.html#/";
    }
  },
  components: { navagetion, wcfooter }
};
</script>

<style lang="less">
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  width: 100%;
  position: relative;
    margin-top: 130px;
  .navgetion {
    position: fixed;
    top: 0;
    z-index: 111;
  
  }

}
.el-pagination.is-background .el-pager li:not(.disabled).active {
    background-color: #ff9443 !important;
    color: #FFF !important;
}
.el-pagination.is-background .el-pager li:not(.disabled):hover {
    color: #606266 !important;
}
</style>
