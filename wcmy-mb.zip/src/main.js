import Vue from 'vue'
import App from './App'
import router from './router'
import Axios from 'axios'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import httpUrl from "../src/api/url.vue"
import 'lib-flexible'

import VueTouch from 'vue-touch'
Vue.use(VueTouch, {name: 'v-touch'})
import Vant from 'vant';
import 'vant/lib/index.css';
Vue.use(Vant)

Vue.use(ElementUI);
Vue.prototype.$axios= Axios
Vue.prototype.httpUrl=httpUrl;
Axios.defaults.baseURL = "http://www.cdswcmy.com";
// Axios.defaults.baseURL = "http://wcmy.public.5151fw.com/";
Axios.defaults.headers["Content-type"] = "application/json";
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: {
    App
  },
  template: '<App/>'
})
