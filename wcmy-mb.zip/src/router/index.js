import Vue from 'vue'
import Router from 'vue-router'
import home from '../pages/home.vue'
import about from '../pages/about.vue'
import product from '../pages/product.vue'
import production from '../pages/production.vue'
import cases from '../pages/cases.vue'
import news from '../pages/news.vue'
import contact from '../pages/contact.vue'

import homes from '../components/home-lb.vue'
import active from '../components/product-active.vue'
import flxed from '../components/product-flexd.vue'
import room from '../components/product-room.vue'
import homeactive from '../components/home-active.vue'
import homeflxed from '../components/home-flxed.vue'
import homeroom from '../components/home-room.vue'
import details from '../pages/details.vue'
Vue.use(Router)

export default new Router({
  // mode: 'history', 去除路由的#
  routes: [{
    path: '/',
    // name: 'home',
    component: home,
    children:[
      {
        path:'/',
        component:homes,
        children:[ 
          {
            path:'/',
            name:'homeactive',
            component:homeactive
          },
          {
            path:'homeFlexd',
            name:'homeflxed',
            component:homeflxed
          },
          {
            path:'homeRoom',
            name:'homeroom',
            component:homeroom
          }
        ]
       }
    ]
  },
    {
      path: '/about',
      name: 'about',
      component: about
    }
    ,
    {
      path: '/details',
      name: 'details',
      component: details
    },
    {
      path: '/product',
      // name: 'product',
      component: product,
      children:[
        {
          path:'/',
          name:'active',
          component:active
        },
        {
          path:'flxed',
          name:'flxed',
          component:flxed
        },
        {
          path:'room',
          name:'room',
          component:room
        }
      ]
    }
    ,
    {
      path: '/production',
      name: 'production',
      component: production
    }
    ,
    {
      path: '/cases',
      name: 'cases',
      component: cases
    }
    ,
    {
      path: '/news',
      name: 'news',
      component: news
    }
    ,
    {
      path: '/contact',
      name: 'contact',
      component: contact
    }
    
    
  ]
})
