<template>
  <div class="home-active">
    <div class="flash">
      <div class="prolist">
        <div class="pr-left">
          <div class="pl-box">
            <div class="fltop">
              <div class="picture">
                <img src="../assets/home/pro_tb_02.png" alt />
              </div>
              <p>01</p>
            </div>
            <div class="flcenter">
              <p class="cname">酒店活动家具</p>
              <p class="ename">HOTEL ACTIVITY FURNITURE</p>
              <p class="bg"></p>
            </div>
            <div class="flbot">
              <p>文春木业</p>
            </div>
          </div>
          <div class="pl-proli">
            <div
              class="pic"
              v-if="homeActivelist[0]"
              @click="toProActive(homeActivelist[0].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeActivelist[0].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                <img class="yy" src="../assets/news/newsyy.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>酒店家具</span>
                <p class="text" v-html="homeActivelist[0].article_content"></p>
              </div>
            </div>
          </div>
        </div>
        <div class="pr-right">
          <div class="prbox proli">
            <div
              class="pic"
              v-if="homeActivelist[1]"
              @click="toProActive(homeActivelist[1].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeActivelist[1].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                <img class="yy" src="../assets/news/newsyy.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>酒店家具</span>
                <p class="text" v-html="homeActivelist[1].article_content"></p>
              </div>
            </div>
          </div>
          <div class="prbox proli">
            <div
              class="pic"
              v-if="homeActivelist[1]"
              @click="toProActive(homeActivelist[1].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeActivelist[1].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                <img class="yy" src="../assets/news/newsyy.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>酒店家具</span>
                <p class="text" v-html="homeActivelist[2].article_content"></p>
              </div>
            </div>
          </div>
          <div class="prbox proli">
            <div
              class="pic"
              v-if="homeActivelist[1]"
              @click="toProActive(homeActivelist[1].article_id)"
            >
              <div
                class="mainpic"
                :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeActivelist[1].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
              ></div>
              <div class="ts">
                <img class="yy" src="../assets/news/newsyy.png" alt />
                <img class="pop" src="../assets/product/pop.png" alt />
                <span>酒店家具</span>
                <p class="text" v-html="homeActivelist[3].article_content"></p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="probot">
        <div class="prbox proli wprbox">
          <div
            class="pic"
            v-if="homeActivelist[4]"
            @click="toProActive(homeActivelist[4].article_id)"
          >
            <div
              class="mainpic"
              :style="{backgroundImage: 'url(' +baseurl+`/public/`+homeActivelist[4].image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
            ></div>
            <div class="ts">
              <img class="yy" src="../assets/news/newsyy.png" alt />
              <img class="pop" src="../assets/product/pop.png" alt />
              <span>酒店家具</span>
              <p class="text" v-html="homeActivelist[4].article_content"></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
export default {
  name: "hmactive",
  data() {
    return {
      homeActivelist: [],
      baseurl: "",
      classid: ""
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
   toProActive(val) {
      let id = val;
      this.$router.push({
        path: "/details",
        query: { id: id, kind: "product" }
      });
    },
    requst() {
      this.$axios.post("/index/api/getProductClass").then(res => {
        this.classid = res.data.data[0].class_id;
        this.requstClass();
      });
    },
    requstClass() {
      this.$axios
        .post("/index/api/getProductList", {
          id: this.classid,
          page: this.setPage,
          limit: 5
        })
        .then(res => {
          this.homeActivelist = res.data.data.data;
        });
    }
  }
};
</script>

<style lang="less" scoped>
// 图片
.flash {
  .prolist {
    width: 100%;
    display: flex;
    .pr-left {
      width: 50%;
      .pl-box {
        box-sizing: border-box;
        background: #171c22;
        width: 100%;
        height: 405px;
        padding: 40px 46px;
        .fltop {
          height: 64px;
          display: flex;
          justify-content: space-between;
          .picture {
            width: 64px;
            img {
              width: 100%;
              height: 100%;
            }
          }
          p {
            font-size: 42px;
            font-weight: 300;
            color: rgba(241, 241, 241, 1);
            line-height: 90px;
            opacity: 0.4;
          }
        }
        .flcenter {
          padding-top: 50px;
          .cname {
            color: #ff9443;
            font-size: 34px;
          }
          .ename {
            padding-top: 5px;
            font-size: 21px;
            font-weight: 300;
            color: rgba(241, 241, 241, 1);
            opacity: 0.4;
          }
          .bg {
            margin: 30px 0;
            width: 36px;
            height: 2px;
            background: #dddddd;
          }
        }
        .flbot {
          font-size: 21px;
          font-weight: 300;
          color: rgba(241, 241, 241, 1);
          opacity: 0.4;
        }
      }
      .pl-proli {
       
        width: 100%;
        height: 405px;
        .pic {
          width: 100%;
          height: 405px;
          position: relative;
          .mainpic {
            width: 100%;
            height: 100%;
          }
          .ts {
            width: 100%;
            display: none;
            img {
              position: absolute;
            }
            .yy {
              top: 0;
              width: 100%;
              height: 100%;
            }
            .pop {
              width: 130px;
              top: 8%;
              left: -8px;
            }
            span {
              position: absolute;
              top: 11%;
              left: 1%;
              color: white;
              font-size: 18px;
            }
            .text {
              box-sizing: border-box;
              position: absolute;
              bottom: 10px;
              color: rgba(255, 255, 255, 0.8);
              line-height: 30px;
              width: 90%;
              height: 55px;
              padding-left: 20px;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
          &:active .ts {
            display: block;
          }
        }
      }
    }
    .pr-right {
      width: 50%;
      display: flex;
      flex-wrap: wrap;
      .proli {
       
        width: 100%;
        height: 270px;
        .pic {
          width: 100%;
          height: 270px;
          position: relative;
          .mainpic {
            width: 100%;
            height: 100%;
          }
          .ts {
            width: 100%;
            display: none;
            img {
              position: absolute;
            }
            .yy {
              top: 0;
              width: 100%;
              height: 100%;
            }
            .pop {
              width: 130px;
              top: 8%;
              left: -8px;
            }
            span {
              position: absolute;
              top: 13%;
              left: 1%;
              color: white;
              font-size: 18px;
            }
            .text {
              box-sizing: border-box;
              position: absolute;
              bottom: 10px;
              color: rgba(255, 255, 255, 0.8);
              line-height: 30px;
              width: 90%;
              height: 55px;
              padding-left: 20px;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
          &:active .ts {
            display: block;
          }
        }
      }
      .wprbox {
        width: 100%;
        .pic {
          width: 100%;
        }
      }
    }
  }
  .probot {
    width: 100%;
    .proli { 
      width: 100%;
      height: 270px;
      .pic {
        width: 100%;
        height: 270px;
        position: relative;
        .mainpic {
          width: 100%;
          height: 100%;
        }
        .ts {
          width: 100%;
          display: none;
          img {
            position: absolute;
          }
          .yy {
            top: 0;
            width: 100%;
            height: 100%;
          }
          .pop {
            width: 130px;
            top: 8%;
            left: -8px;
          }
          span {
            position: absolute;
            top: 13%;
            left: 1%;
            color: white;
            font-size: 18px;
          }
          .text {
            box-sizing: border-box;
            position: absolute;
            bottom: 10px;
            color: rgba(255, 255, 255, 0.8);
            line-height: 30px;
            width: 90%;
            height: 55px;
            padding-left: 20px;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
          }
        }
        &:active .ts {
          display: block;
        }
      }
    }
    .wprbox {
      width: 100%;
      .pic {
        width: 100%;
      }
    }
  }
}
</style>