<template>
  <div class="footer">
    <div class="footercont">
      <div class="fctop">
        <p class="gs">成都市文春木业有限公司</p>
        <p class="py">Chengdu Wenchun Wood industry Co. Ltd.</p>
        <div class="box"></div>
      </div>
      <div class="ftbt">
        <div class="lxmine">
          <div class="bt">
            <p>联系我们</p>
            <span>CONBTACT US</span>
          </div>
          <ul class="contactlist">
            <li class="conli">
              <div class="icon">
                <img src="../assets/home/foot_02.png" alt />
              </div>
              <p class="text">联系人：</p>
              <p class="cont">{{footerinfo.name}}</p>
            </li>
            <li class="conli">
              <div class="icon">
                <img src="../assets/home/foot_01.png" alt />
              </div>
              <p class="text">电话：</p>
              <p class="cont">{{footerinfo.phone}}</p>
            </li>
            <li class="conli">
              <div class="icon">
                <img src="../assets/home/foot_03.png" alt />
              </div>
              <p class="text">邮箱：</p>
              <p class="cont">{{footerinfo.email}}</p>
            </li>
            <li class="conli">
              <div class="icon">
                <img src="../assets/home/foot_04.png" alt />
              </div>
              <p class="text">公司地址：</p>
              <p class="cont">{{footerinfo.address}}</p>
            </li>
          </ul>
        </div>
        <div class="right">
          <div class="bt">
            <p>关注我们</p>
            <span>FOCUS ON US</span>
          </div>
          <ul class="ewm">
            <li>
              <div class="pic" v-if="footerinfo.about_ewm">
              <img :src="baseurl+`/public/`+footerinfo.about_ewm" alt />
            </div>
              <p>关注我们</p>
            </li>
            <li>
             <div class="pic" v-if="footerinfo.zx_ewm">
              <img :src="baseurl+`/public/`+footerinfo.zx_ewm" alt />
            </div>
              <p>立即咨询</p>
            </li>
          </ul>
        </div>
      </div>
    </div>
     <div class="copy">
      <p>{{footerinfo.foot_content}}</p>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
export default {
  name: "wcfooter",
  data() {
    return {
      baseurl: "",
      footerinfo: [],
      ewm: [
        { icon: require("../assets/gz.png"), text: "关注我们" },
        { icon: require("../assets/zx.png"), text: "立即咨询" }
      ]
    };
  },
  created() {
    this.baseurl = httpUrl.httpUrl;
    this.$axios.post("/index/api/web_config").then(res => {
      this.footerinfo = res.data.data;
    });
  }
};
</script>
<style lang="less" scoped>
.footer {
  background: rgba(39, 41, 49, 1);
  .footercont {
    padding-top: 8%;
    .fctop {
      text-align: center;
      color: #ff9443;
      font-family: Microsoft YaHei;
      position: relative;
      .gs {
        font-size: 26px;
        letter-spacing: 18px;
        font-weight: bold;
      }
      .py {
        font-size: 16px;
      }
      &::after {
        content: "";
        width: 80px;
        height: 4px;
        background: #ff9443;
        position: absolute;
        bottom: -30px;
        left: 50%;
        transform: translateX(-50%);
      }
    }
    .ftbt {
      padding-top: 10%;
      display: flex;
      justify-content: space-between;
      color: white;
      .bt {
        width: 100%;
        font-size: 20px;
        display: flex;
        align-items: flex-end;
        position: relative;
        span {
          padding-left: 5px;
          font-size: 14px;
          color: #47484f;
        }
        &::after {
          content: "";
          width: 257px;
          height: 2px;
          background: white;
          position: absolute;
          bottom: -10px;
        }
      }
      .lxmine {
        box-sizing: border-box;
        width: 58%;
        padding-left: 5px;
        .contactlist {
          //  background: pink;
          padding-top: 40px;
        }
        .conli {
          display: grid;
          grid-template-columns: 7% 33% 1fr;
          padding-bottom: 12px;
          .icon {
            width: 100%;
            img {
              width: 100%;
            }
          }
          .text {

            padding-left: 5px;
            width: 100%;
            display: inline-block;
            text-align: justify;
            text-align-last: justify;
          }
          .cont {
            align-self: flex-end;

            width: 100%;
          }
        }
        // background: orangered;
      }
      .right {
        width: 42%;
        .ewm {
          padding: 40px 0 0 10px;
          display: flex;
          li {
            padding-right: 30px;
            .pic {
              width: 100px;
              height: 100px;
              img {
                width: 100%;
                height: 100%;
              }
            }
          }
        }
      }
    }
  }
  .copy {
    width: 100%;
    text-align: center;
    color: white;
    font-size: 13px;
    padding: 15px 0;
  }
}
</style>