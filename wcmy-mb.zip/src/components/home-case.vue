<template>
  <div class="home-case">
    <div class="title">
      <p class="name">
        经典
        <span>案例</span>
      </p>
      <div class="shadow">
        <p>CLASSIC CASE</p>
      </div>
    </div>
    <div class="flash">
      <v-touch v-on:swipeleft="swiperleft" v-on:swiperight="swiperright">
        <ul class="warpper" :style="{'left':calleft + 'px'}">
          <li class="pic" v-for="(item, index) in caseinfo" :key="index" @click="todetails(item)">
            <div class="casepic">
              <img :src="baseurl+`/public/`+item.image_url" alt />
              <!-- <img :src="item.src" alt=""> -->
            </div>
          </li>
        </ul>
      </v-touch>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
export default {
  name: "home-case",
  data() {
    return {
      baseurl: "",
      caseinfo: [],
      calleft: 0
    };
  },
  created() {
    this.baseurl = httpUrl.httpUrl;
    this.requst();
    this.move();
  },
  methods: {
    //移动
    move() {
      this.timer = setInterval(this.starmove, 10);
    },
    //开始移动
    starmove() {
      this.calleft--;
      if (this.calleft < -2250) {
        this.calleft = 0;
      }
    },
    stopmove() {
      clearInterval(this.timer);
    },
    swiperleft: function() {
      clearInterval(this.timer);
      this.stopmove();
      this.timer = setInterval(this.starmove, 8);
      if (this.calleft < -2250) {
        this.calleft = 0;
      }
    },
    swiperright: function() {
      this.stopmove();
      this.timer = setInterval(this.rightadd, 10);
    },
    rightadd() {
      this.calleft++;
      if (this.calleft == 0) {
        this.calleft=-2250
      }
    },

    add() {
      this.calleft++;
      if (this.calleft == 0) {
        clearInterval(this.timer);
      }
    },
    requst() {
      this.$axios
        .post("/index/api/getCaseList", {
          page: 1,
          limit: 8
        })
        .then(res => {
          this.caseinfo = res.data.data.data;
        });
    },
    todetails(item) {
      let id = item.article_id;
      this.$router.push({ path: "/details", query: { id: id, kind: "case" } });
    }
  }
};
</script>

<style lang="less" scoped>
.title {
  width: 100%;
  text-align: center;
  position: relative;
  .name {
    font-size: 40px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: rgba(39, 41, 49, 1);
    span {
      color: #ff9443;
    }
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #ff9443;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .shadow {
    width: 100%;
    opacity: 0.25;
    font-size: 55px;
    color: #8b8e96;
    position: absolute;
    top: -20px;
    left: 50%;
    transform: translateX(-50%);
  }
}
.home-case {
  width: 95%;
  margin: 20px auto;
  .flash {
    margin: 50px auto;
    position: relative;
    width: 100%;
    height: 300px;
    overflow: hidden;
    .warpper {
      position: absolute;
      left: 0px;
      width: 3000px;
      height: 300px;
      margin: 0px auto;
      li {
        box-sizing: border-box;
        display: inline-block;
        padding: 0px 10px;
        width: 375px;
        height: 300px;
        .casepic {
          width: 100%;
          height: 100%;
          position: relative;
          img {
            width: 100%;
            height: 100%;
          }
        }
      }
    }
  }
}
</style>