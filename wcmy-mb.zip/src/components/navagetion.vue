<template>
  <div class="nav navgetion">
    <div class="top">
      <div class="title" @click="tohome">
        <p>成都市文春木业</p>
        <span>高端实木工厂定制</span>
      </div>
      <div class="menu" @click="navshow=!navshow">
        <img src="../assets/mb-home/menu.png" alt />
      </div>
    </div>
    <div class="navtab" v-show="navshow">
      <ul class="navlist">
        <li
          :class="activeClass ==index?'sel':''"
          v-for="(list,index) in navlist"
          :key="index"
          @click="toNav(index)"
        >
          <router-link :to="list.path">
            <p>{{list.chinese}}</p>
          </router-link>
        </li>
      </ul>
      <div class="navbox" @click="navshow=!navshow"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "navagetion",
  data() {
    return {
      navshow: false,
      activeClass: 0, // 0为默认选择第一个，-1为不选择
      navlist: [
        {
          path: "/",
          chinese: "首页",
          english: "HOME"
        },
        {
          path: "/about",
          chinese: "关于我们"
        },
        {
          path: "/product",
          chinese: "产品中心"
        },
        {
          path: "/production",
          chinese: "生产基地"
        },
        {
          path: "/cases",
          chinese: "经典案例"
        },
        {
          path: "/news",
          chinese: "新闻动态"
        },
        {
          path: "/contact",
          chinese: "联系我们"
        }
      ]
    };
  },
  methods: {
     tohome() {
      this.$router.push({
        path: "/"
      });
      sessionStorage.setItem("curindex", 0);
      this.activeClass = sessionStorage.getItem("curindex");
    },
    toNav(index) {
      this.activeClass = index;
      setTimeout(() => {
        this.navshow = false;
      }, 200);
    }
  }
};
</script>

<style lang="less" scoped>
.nav {
  box-sizing: border-box;
  background: #1f222b;
  box-sizing: border-box;
  width: 100%;
  height: 130px;
  padding: 0 15px;
  position: relative;
  .top {
    padding-top: 30px;
    display: flex;
    justify-content: space-between;
    .title {
      width: 250px;
      text-align: center;
      color: #ff9442;
      p {
        font-size: 30px;
        font-weight: bold;
      }
      span {
        font-size: 16px;
      }
    }
    .menu {
      line-height: 70px;
      width: 70px;
      height: 70px;
      img {
        width: 100%;
      }
    }
  }
  .navtab {
    width: 100%;
    position: absolute;
    top: 130px;
    left: 0;
    z-index: 11;
    .navlist {
      background: #1f222b;
      border-top: 1px solid rgba(255, 168, 66, 0.8);
      li {
        border-bottom: 1px solid rgba(255, 168, 66, 0.8);
        text-align: center;
        padding: 25px 0;
        a {
          color: rgb(255, 148, 66);
        }
        &:active {
          background: rgb(255, 148, 66);
          a {
            color: #1f222b;
          }
        }
      }
    }
    .navbox {
      background: rgba(255, 148, 67, 0);
      width: 100%;
      height: 700px;
      z-index: 111;
    }
  }
}
</style>
