<template>
  <div class="room">
    <div class="flash">
      <ul class="prolist">
        <li class="pl-box">
          <div class="fltop">
            <div class="picture">
              <img src="../assets/home/pro_tb_02.png" alt />
            </div>
            <p>03</p>
          </div>
          <div class="flcenter">
            <p class="cname">酒店房间家具</p>
            <p class="ename">HOTEL ROOM FURNITURE</p>
          </div>
        </li>
        <li class="proli" v-for="(item, index) in roomlist" :key="index"  @click="todetails(item)">
          <div class="pic">
          <div
              class="mainpic"
              :style="{backgroundImage: 'url(' +baseurl+`/public/`+item.image_url + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
            ></div>
            <div class="ts">
              <img class="yy" src="../assets/news/newsyy.png" alt />
              <img class="pop" src="../assets/product/pop.png" alt />
              <span>酒店家具</span>
              <p class="text" v-html="item.article_content"></p>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div class="pagenation">
      <el-pagination
        small
        background
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage1"
        :page-size="9"
        layout=" prev, pager, next"
        :total="totalPage"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import httpUrl from "../api/url";
export default {
  name: "active",
  data() {
    return {
      roomlist: [],
      baseurl: "",
      currentPage1: 1,
      totalPage: 1,
      setPage: 1,
      classid: ""
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
    todetails(item){
      let id=item.article_id;
      this.$router.push({path:'/details',query:{id:id,kind:'product'}})
    },
    handleCurrentChange(val) {
      this.setPage = val;
  this.requstClass(this.classid, this.setPage);
    },
    requst() {
      this.$axios.post("/index/api/getProductClass").then(res => {
        this.classid = res.data.data[2].class_id;
        this.requstClass(this.classid, 1);
      });
    },
    requstClass(id, page) {
      this.$axios
        .post("/index/api/getProductList", {
          id: id,
          page: page,
          limit: 9
        })
        .then(res => {
          this.roomlist = res.data.data.data;
          this.totalPage = res.data.data.total.length;
        });
    }
  }
};
</script>

<style lang="less" scoped>
.room {
  position: relative;
  .pagenation {
    position: absolute;
    background: white;
    border-radius: 45px;
    bottom: -160px;
    left: 50%;
    transform: translateX(-50%);
  }
}
// 图片
.flash {
  padding-top: 100px;
  .prolist {
    width: 100%;
    display: grid;
    justify-content: space-between;
    grid-template-columns: 49% 49%;
   grid-gap: 15px;
        .pl-box {
      box-sizing: border-box;
      background: #171c22;
      width: 100%;
      height: 265px;
      padding: 10% 10%;
      .fltop {
        height: 43px;
        display: flex;
        justify-content: space-between;
        .picture {
          width: 43px;
          display: flex;
          justify-content: center;
          align-items: center;
          img {
            max-width: 100%;
            max-height: 100%;
          }
        }
        p {
          font-size: 43px;
          font-weight: 300;
          color: rgba(241, 241, 241, 1);
          opacity: 0.4;
        }
      }
      .flcenter {
        padding-top: 10%;
        .cname {
          color: #ff9443;
          font-size: 34px;
        }
        .ename {
          padding-top: 1%;
          font-size: 21px;
          font-weight: 300;
          color: rgba(241, 241, 241, 1);
          opacity: 0.4;
        }
      }
    }
    .proli {
      display: inline-block;
      width: 100%;
      .pic {
        width: 100%;
        height: 265px;
        position: relative;
        .mainpic {
          width: 100%;
          height:265px;
        }
        .ts {
          width: 100%;
          display: none;
          img {
            position: absolute;
          }
          .yy {
            top: 0;
            width: 100%;
            height: 100%;
          }
          .pop {
            width: 130px;
            top: 8%;
            left: -8px;
          }
          span {
            position: absolute;
            top: 11%;
            left: 1%;
            color: white;
            font-size: 18px;
          }
          .text {
            box-sizing: border-box;
            position: absolute;
            bottom: 10px;
            color: rgba(255, 255, 255, 0.8);
            line-height: 30px;
            width: 90%;
            height: 55px;
            padding-left: 20px;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
          }
        }
        &:active .ts {
          display: block;
        }
      }
    }
  }
}
</style>