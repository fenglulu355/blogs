<template>
  <div class="banner">
    <!-- <img src="../assets/banner.png" alt /> -->
    <div class="pic" :style="banner"></div>
  </div>
</template>
<script>
export default {
  name: "Banner",
  data() {
    return {
      banner: {
        backgroundImage: "url(" + require("../assets/banner.png") + ")"
      }
    };
  }
};
</script>
<style lang="less" scoped>
.banner {
  width: 100%;
  .pic {
    width: 100%;
    height: 400px;
    background-size: cover;
     background-repeat: no-repeat;
    background-position: center;
  }
}
</style>