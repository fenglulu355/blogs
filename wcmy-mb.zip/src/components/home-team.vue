<template>
  <div class="home-team">
    <div class="name">
      <p>团队实力</p>
    </div>
    <div class="cont">
      <div class="intru clearFix">
        <div class="top">
          <p>制作团队</p>
          <p class="min">Production Team</p>
        </div>
        <div class="center">
          <p>熟悉原材料的种类、性能、规格及来源根据现有的材料去设计出优秀的产品，做到物尽其用，从研发到设计到采买，全程严格把控</p>
        </div>
        <div class="toleft fr">
          <img src="../assets/home/jiantou.png" alt />
        </div>
      </div>
      <div class="teampic">
        <div class="tp-img">
          <img src="../assets/mb-news/news1.png" alt />
        </div>
        <div class="tp-img">
          <img src="../assets/mb-news/news2.png" alt />
        </div>
      </div>
      <div class="intru clearFix">
        <div class="top">
          <p>设计团队</p>
          <p class="min">Design Team</p>
        </div>
        <div class="center">
          <p>家具设计-U家工场，专注现代,北欧,新中式,轻美式,日式,新中式风格,汇集行业精英,从研发到设计到采买，全程严格把控</p>
        </div>
        <div class="toleft fr">
          <img src="../assets/home/jiantou.png" alt />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "hometeam"
};
</script>
<style lang="less" scoped>
.home-team {
  padding-top: 40px;

  .name {
    text-align: center;
    font-size: 40px;
    position: relative;
    &::after {
      content: "";
      width: 44px;
      height: 4px;
      background: #e3a576;
      position: absolute;
      bottom: -20px;
      left: 50%;
      transform: translateX(-50%);
    }
  }
  .cont {
    background: #272931;
    width: 95%;
    margin: 50px auto;

    .intru {
      padding: 5%;
      // position: relative;
      .top {
        position: relative;
        p {
          font-size: 24px;
          color: #ff9443;
        }
        .min {
          font-size: 18px;
          padding: 20px 0 30px 0;
        }
        &::after {
          content: "TEAM";
          font-size: 122px;
          color: #696a71;
          opacity: 0.04;
          position: absolute;
          right: 0;
          top: -30px;
        }
      }
      .center {
        color: #f1f1f1;
        font-size: 14px;
        line-height: 40px;
      }
      .toleft {
        padding: 20px 0;
        float: right;
        width: 83px;
        height: 51px;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
    .teampic {
      width: 100%;
      display: flex;
      justify-content: space-between;
      .tp-img {
        width: 50%;
        height: 200px;
        max-height: 300px;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
  }
}
</style>