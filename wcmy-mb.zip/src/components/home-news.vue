<template>
  <div class="homenews">
    <div class="hncont">
      <div class="name">
        <p class="gs">成都市文春木业有限公司</p>
        <p class="py">Chengdu Wenchun Wood industry Co. Ltd.</p>
      </div>
      <div class="jhp">
        <p class="name">九豪牌</p>
        <p class="intru"> 成都市文春木业有限公司居于西部家具产业带、历史文化名镇新繁，</p>
        <p class="intru">紧邻成彭高速,交通便捷。</p>
        <p class="intru">公司以制造销售宾馆成套家具、办公家具、教学家具为主导的专业化公司...</p>
        <p class="more" @click="toAbout">MORE+</p>
      </div>
      <ul class="hncenter">
        <li v-if="newsinfo[0]" >
          <div class="left"     @click="todetails(newsinfo[0].article_id)">
            <div class="time">
              <span class="year">{{newsinfo[0].year}}</span>
              <span class="fgx"></span>
              <span class="moon">{{newsinfo[0].mouth}}</span>
            </div>
            <p class="content" v-html="newsinfo[0].article_title"></p>
          </div>
          <div class="pic">
            <img src="../assets/fenge.png" alt />
          </div>
        </li>
        <li v-if="newsinfo[1]">
          <div class="left"    @click="todetails(newsinfo[1].article_id)" >
            <p class="content" v-html="newsinfo[1].article_title" ></p>
            <div class="time">
              <span class="year">{{newsinfo[1].year}}</span>
              <span class="fgx"></span>
              <span class="moon">{{newsinfo[1].mouth}}</span>
            </div>
          </div>

          <div class="pic">
            <img src="../assets/fenge.png" alt />
          </div>
        </li>
      </ul>
    </div>
    <!-- <div class="sof-pic">
      <img src="../assets/home/sof.png" alt />
    </div> -->
  </div>
</template>

<script>
import httpUrl from "../api/url";
export default {
  name: "homenews",
  data() {
    return {
      newsinfo: []
    };
  },
  created() {
    this.requst();
    this.baseurl = httpUrl.httpUrl;
  },
  methods: {
     todetails(val){
       let id = val;
      this.$router.push({
        path: "/details",
        query: { id: id, kind: "news" }
      });
    },
    toAbout(){
      this.$router.push({path:'/about'})
    },
    requst() {
      this.$axios
        .post("/index/api/getNewsList", {
          page: this.setPage,
          limit: 2
        })
        .then(res => {
          this.newsinfo = res.data.data.data;
        });
    }
  }
};
</script>

<style lang="less" scoped>
.homenews {
  width: 100%;
  padding-top: 40px;
  .hncont {
    .name {
      text-align: center;
      .gs {
        font-size: 40px;
        color: #57585a;
      }
      .py {
        padding-top: 5px;
        font-size: 20px;
        color: #8b8c8f;
      }
    }
    .jhp {
      text-align: center;
      font-family: 微软雅黑;
      color: #171c22;
      .tit {
        font-size: 30px;
        color: #57585a;
        padding: 30px 0;
      }
      .intru {
        padding: 5px;
        font-size: 14px;
      }
      .more {
        margin: 30px auto;
        width: 120px;
        height: 35px;
        line-height: 35px;
        font-size: 18px;
        text-align: center;
        color: white;
        border-radius: 8px;
        background:#ff9442;
      }
    }
    .hncenter {
      // background: pink;
      width: 100%;
      li {
        width: 90%;
        // background: orangered;
        margin: 100px auto;
        position: relative;
        .left {
        
          display: flex;
          justify-content: space-between;
          .time {
            width: 38%;
            color: #ff9442;
            font-size: 60px;
            position: relative;
            .year {
              position: absolute;
              top: 10px;
              left: 10px;
            }
            .fgx {
              display: inline-block;
              width: 3px;
              height: 70px;
              background: #ff9442;
              position: absolute;
              top: 20px;
              font-size: 45px;
              transform: rotate(50deg);
              left: 155px;
            }
            .moon {
              position: absolute;
              top: 25px;
              left: 185px;
            }
          }
          .content { 
            width: 50%;
            line-height: 30px;
            padding-top: 40px;
            color: #57585a;
          }
        }
        .pic {
          position: absolute;
          bottom: -40px;
          width: 100%;
          z-index: -1;
          img {
            width: 100%;
          }
        }
      }
    }
  }
  .sof-pic {
    width: 100%;
    height: 300px;
    img {
      width: 100%;
      height: 100%;
    }
  }
}
</style>