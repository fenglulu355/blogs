<template>
  <div class="home-product">
    <div class="bg">
      <div
        class="topbg"
        :style="{backgroundImage: 'url(' + require('../assets/home/topbg.png')+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
      ></div>
      <div
        class="btbg"
        :style="{backgroundImage: 'url(' + require('../assets/home/btbg.png')+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
      ></div>
    </div>
    <div class="content">
      <div class="cont-left">
        <div class="icon" id="proicon">
          <transition name="trans-pro">
            <img v-if="trans" src="../assets/home/homeproduct/chcp.png" alt />
          </transition>
        </div>
        <transition name="trans-prolfli">
          <ul class="cllist" v-if="trans">
            <li
              class="clli"
              v-for="(item, index) in navlist"
              :key="index"
              @click="toNav(index)"
              :class="proClass ==index?'show':''"
            >
              <div class="cllibox">
                <p>{{item}}</p>
                <div class="arrow">
                  <img src="../assets/home/jt.png" alt />
                </div>
              </div>
            </li>
          </ul>
        </transition>
      </div>
      <div class="cont-right">
        <div class="crtop">
          <transition name="trans-rtpro">
            <ul class="prolist" v-if="trans">
              <li class="proli" v-for="(item, index) in prolista" :key="index">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' + item.src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{item.title}}</p>
                <div class="todetail">
                  <span>{{item.title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </li>
            </ul>
          </transition>
        </div>
        <div class="crcenter probox">
          <transition name="centera">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' + prolistb[0].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{prolistb[0].title}}</p>
                <div class="todetail">
                  <span>{{prolistb[0].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
          <transition name="centerb">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' + prolistb[1].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{prolistb[1].title}}</p>
                <div class="todetail">
                  <span>{{prolistb[1].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
          <transition name="centerc">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' + prolistb[2].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{ prolistb[2].title}}</p>
                <div class="todetail">
                  <span>{{ prolistb[2].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
          <transition name="centerd">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' +  prolistb[3].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{ prolistb[3].title}}</p>
                <div class="todetail">
                  <span>{{ prolistb[3].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
        </div>
        <div class="ctbt probox">
          <transition name="proarra">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' +  prolistc[0].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{prolistc[0].title}}</p>
                <div class="todetail">
                  <span>{{prolistc[0].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
          <transition name="proarrb">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' + prolistc[1].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{prolistc[1].title}}</p>
                <div class="todetail">
                  <span>{{prolistc[1].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
          <transition name="proarrc">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' + prolistc[2].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{prolistc[2].title}}</p>
                <div class="todetail">
                  <span>{{prolistc[2].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
          <transition name="proarrd">
            <div class="prolist" v-if="trans">
              <div class="proli">
                <div
                  class="mainpic"
                  :style="{backgroundImage: 'url(' + prolistc[3].src+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
                ></div>
                <p class="title">{{prolistc[3].title}}</p>
                <div class="todetail">
                  <span>{{prolistc[3].title}}</span>
                  <span>
                    <img src="../assets/home/lf.png" alt />
                  </span>
                </div>
              </div>
            </div>
          </transition>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "homeproduct",
  data() {
    return {
      trans: false,
      proClass: 0,
      navlist: [
        "规划设计",
        "水生态治理修复",
        "彩叶观赏草",
        "花镜花海造景",
        "房地产市政景观",
        "生态浮岛深水治理",
        "屋顶花园私人庭院",
        "商业综合体垂直绿化",
        "标准级草坪"
      ],
      prolista: [
        {
          src: require("../assets/home/homeproduct/pro1.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro2.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro3.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro4.png"),
          title: "金叶菖蒲"
        }
      ],
      prolistb: [
        {
          src: require("../assets/home/homeproduct/pro1.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro2.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro3.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro4.png"),
          title: "金叶菖蒲"
        }
      ],
      prolistc: [
        {
          src: require("../assets/home/homeproduct/pro1.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro2.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro3.png"),
          title: "金叶菖蒲"
        },
        {
          src: require("../assets/home/homeproduct/pro4.png"),
          title: "金叶菖蒲"
        }
      ]
    };
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
  },
  methods: {
    toNav(index) {
      this.proClass = index;
    },
    handleScroll: function() {
      let scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop <= 200) {
        this.trans = false;
      } else {
        this.trans = true;
      }
    }
  },
  destroyed: function() {
    window.removeEventListener("scroll", this.handleScroll);
  }
};
</script>
<style lang="less" scoped>