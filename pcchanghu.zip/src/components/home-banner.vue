<template>
  <div class="home-banner">
    <div class="warpper" @mouseover="clearInv" @mouseout="runInv">
      <!-- 按钮 -->
      <div class="pagenation prev" @click="goto(prevIndex)">
        <img src="../assets/home/homebanner/left.png" alt />
      </div>
      <div class="pagenation next" @click="goto(nextIndex)">
        <img src="../assets/home/homebanner/right.png" alt />
      </div>
      <!-- 指示器 -->
      <div class="pages">
        <div
          class="pages-box"
          :class="{show: index === nowIndex}"
          v-for="(item, index) in slides"
          :key="index"
          @click="goto(index)"
        ></div>
      </div>
      <!-- 图片 -->
      <div class="slide-img">
        <a :href="slides[nowIndex].href">
          <transition name="slide-trans">
            <div
              v-if="isShow"
              class="picbox"
              :style="{backgroundImage: 'url(' + slides[nowIndex].src + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
            ></div>
          </transition>
          <transition name="slide-trans-old">
            <div
              v-if="!isShow"
              class="picbox"
              :style="{backgroundImage: 'url(' + slides[nowIndex].src + ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
            ></div>
          </transition>
        </a>
      </div>
      <!-- 展示 -->
      <div class="guide">
        <ul class="guidelist">
          <li class="guideli" v-for="(item, index) in guidelist" :key="index">
            <div class="icon">
              <img :src="item.src" alt />
            </div>
            <div class="name">{{item.name}}</div>
            <div class="desc">{{item.des}}</div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "homebanner",
  data() {
    return {
      inv: 3000,
      nowIndex: 0,
      isShow: true,
      slides: [
        { src: require("../assets/home/homebanner/banner.png") },
        { src: require("../assets/home/homebanner/ban.png") },
        { src: require("../assets/home/homebanner/banner.png") }
      ],
      guidelist: [
        {
          src: require("../assets/home/homebanner/guide1.png"),
          name: "湿地水景",
          des: "水生生物与水生植物相互构成的动态平衡系统。"
        },
        {
          src: require("../assets/home/homebanner/guide2.png"),
          name: "花镜花海",
          des: "是一种植物多样化景观搭配的生态产物"
        },
        {
          src: require("../assets/home/homebanner/guide3.png"),
          name: "彩叶观赏草",
          des: "色彩柔和且着色均匀，色彩效果丰富"
        },
        {
          src: require("../assets/home/homebanner/guide4.png"),
          name: "水生态修复",
          des: "色彩柔和且着色均匀，色彩效果丰富"
        },
        {
          src: require("../assets/home/homebanner/guide5.png"),
          name: "深水浮岛",
          des: "色彩柔和且着色均匀，色彩效果丰富"
        },
        {
          src: require("../assets/home/homebanner/guide6.png"),
          name: "湿地水景",
          des: "色彩柔和且着色均匀，色彩效果丰富"
        }
      ]
    };
  },
  computed: {
    prevIndex() {
      if (this.nowIndex === 0) {
        return this.slides.length - 1;
      } else {
        return this.nowIndex - 1;
      }
    },
    nextIndex() {
      if (this.nowIndex === this.slides.length - 1) {
        return 0;
      } else {
        return this.nowIndex + 1;
      }
    }
  },
  methods: {
    goto(index) {
      this.isShow = false;
      setTimeout(() => {
        this.isShow = true;
        this.nowIndex = index;
      }, 10);
    },
    runInv() {
      this.invId = setInterval(() => {
        this.goto(this.nextIndex);
      }, this.inv);
    },
    clearInv() {
      clearInterval(this.invId);
    }
  },
  mounted() {
    this.runInv();
  }
};
</script>
<style lang="less" scoped>
// .slide-trans-enter-active {
//   transition: all 0.5s linear;
// }
// .slide-trans-enter {
//   transform: translateX(900px);
// }
// .slide-trans-old-leave-active {
//   transition: all 0.5s ease-in-out;
//   transform: translateX(-900px);
// }
.home-banner {
  width: 100%;
  height: 960px;
  .warpper {
    width: 100%;
    height: 100%;
    position: relative;
    // 图片
    .slide-img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -2;
      .picbox {
        width: 100%;
        height: 100%;
      }
    }
    // 指示器
    .pagenation {
     cursor: pointer;
      position: absolute;
      top: 390px;
      transform: translateY(-50%);
    }
    .next {
      right: 10%;
    }
    .prev {
      left: 10%;
    }
    // 圆点
    .pages {
      width: 100px;
      position: absolute;
      top: 660px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      justify-content: space-between;
      .pages-box {
        cursor: pointer;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: white;
      }
      .show {
        background: #82c41c;
        position: relative;
        &::after {
          position: absolute;
          top: -5px;
          left: -5px;
          content: "";
          width: 20px;
          height: 20px;
          background: white;
          border-radius: 50%;
          z-index: -1;
        }
      }
    }
    // 引导
    .guide {
      background: rgba(0, 0, 0, 0.5);
      width: 100%;
      height: 260px;
      position: absolute;
      bottom: 0;
      .guidelist {
        width: 100%;
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        justify-items: center;
        .guideli {
          display: inline-block;
          text-align: center;
          width: 100%;
          height: 100%;
          color: #888888;
          box-sizing: border-box;
          .icon {
            padding-top: 45px;
            //   width: 60px;
            //   height: 60px;
            //   margin: 0 auto;
            //   img{
            //       height: 100%;
            //   }
          }
          .name {
            padding: 30px 0;
            font-size: 18px;
            font-weight: 400;
          }
          .desc {
            //   background: pink;
            width: 130px;
            margin: 0 auto;
            font-size: 14px;
            font-family: Microsoft YaHei;
            font-weight: 400;
            line-height: 20px;
          }
          &:hover{
              cursor: pointer;
              color: white;
          }
        }
      }
    }
  }
}
</style>