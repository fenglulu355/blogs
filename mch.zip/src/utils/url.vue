<script>
const httpUrl='http://chst.com/'

export default {
httpUrl
}

</script>