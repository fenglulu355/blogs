<template>
  <div class="home-banner">
    <div class="warpper">
      <van-swipe :autoplay="3000"
       touchable
        indicator-color="#82C41C">
        <van-swipe-item  v-for="(item, index) in slides" :key="index">
          <img :src="item" alt />
          <p>{{index}}</p>
        </van-swipe-item>
      </van-swipe>
    </div>
    <!-- 展示 -->
    <div class="guide">
      <ul class="guidelist">
        <li class="guideli" v-for="(item, index) in guidelist" :key="index">
          <div class="icon">
            <img :src="item.src" alt />
          </div>
          <div class="name">{{item.name}}</div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: "homebanner",
  data() {
    return {
      inv: 3000,
      nowIndex: 0,
      isShow: true,
      slides: [
        require("../assets/home/homebanner/banner.png"),
        require("../assets/home/homebanner/ban.png"),
        require("../assets/home/homebanner/banner.png")
      ],
      guidelist: [
        {
          src: require("../assets/home/homebanner/1.png"),
          name: "湿地水景"
        },
        {
          src: require("../assets/home/homebanner/2.png"),
          name: "花镜花海"
        },
        {
          src: require("../assets/home/homebanner/3.png"),
          name: "彩叶观赏草"
        },
        {
          src: require("../assets/home/homebanner/4.png"),
          name: "水生态修复"
        },
        {
          src: require("../assets/home/homebanner/5.png"),
          name: "深水浮岛"
        },
        {
          src: require("../assets/home/homebanner/6.png"),
          name: "湿地水景"
        },
        {
          src: require("../assets/home/homebanner/7.png"),
          name: "湿地水景"
        },
        {
          src: require("../assets/home/homebanner/8.png"),
          name: "湿地水景"
        }
      ]
    };
  }
};
</script>
<style lang="less" scoped>
.home-banner {
  background: white;
  width: 100%;
  position: relative;
  box-sizing: border-box;
  padding: 0 25px;
  .warpper {
    // box-sizing: border-box;
    padding-top: 110px;
    width: 100%;
    height: 320px;
    .van-swipe {
      border-radius: 15px;
      width: 100%;
      height: 100%;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
  // 引导
  .guide {
    width: 100%;
    padding-bottom: 40px;
    .guidelist {
      width: 100%;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      justify-items: center;
      .guideli {
        display: inline-block;
        text-align: center;
        width: 100%;
        height: 100%;
        color: #333333;
        box-sizing: border-box;
        font-size: 23px;
        .icon {
          padding-top: 45px;
          width: 66px;
          height: 66px;
          margin: 0 auto;
          img {
            height: 100%;
          }
        }
        .name{
          padding-top: 20px;
        }
        // &:hover {
        //   cursor: pointer;
        //   color: white;
        // }
      }
    }
  }
}
</style>