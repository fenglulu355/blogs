<template>
    
</template>

<script>
export default {
    // data(){
    //     return{

    //     }
    // },
    
    // mounted:{
    //     backTop(){
    //         let top = document.documentElement.scrollTop || document.body.scrollTop
    //         top = 0
    // }
    // }
}   
</script>

<style>
/* .footer{
    background-color:#fff; 
    height: 184px;
    width: 100%;
}
.footer-top{
    height: 94px;
    text-align: center;
}
.footer-title{
    line-height: 84px;
    font-size: 22px;
    color: #666;
    font-weight:400;
}
.footer-top span{
    margin: 0 44px;
}
.footer-bottom{
    height: 90px;
    display: flex;
    justify-content: space-between;
}
.footer-bottom-box{
    width: 250px;
    padding-top: 25px;
    padding-left: 60px; 
    background: #9F2020;
}
.footer-bottom-box p{
    line-height: 45px;
    margin-left: 48px; 
    font-size: 22px;
    color: #fff;
}
.icon1{
    width: 36px;
    float: left;
}
.icon1 img{
    width: 36px;
}
.icon2{
    float: left;
}
.icon2 img{
    width: 40px;
}
.icon3{
    float: left;
}
.icon3 img{
    width: 38px;
}
#yellow{
    background: #F3B72F;
} */
</style>
